<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use App\Models\AiAgent;
use App\Models\AiAgentTool;

class AiAgentSeeder extends Seeder {
    public function run(): void {
        // Create AI tools first
        $tools = [
            ['name' => 'CRM Search Leads', 'slug' => 'crm_search_leads', 'description' => 'Search leads in CRM', 'handler_class' => 'AiExecutionEngine@crmSearchLeads', 'category' => 'crm', 'risk_level' => 'low'],
            ['name' => 'CRM Create Lead', 'slug' => 'crm_create_lead', 'description' => 'Create a new lead in CRM', 'handler_class' => 'AiExecutionEngine@crmCreateLead', 'category' => 'crm', 'risk_level' => 'medium'],
            ['name' => 'CRM Search Contacts', 'slug' => 'crm_search_contacts', 'description' => 'Search contacts in CRM', 'handler_class' => 'AiExecutionEngine@crmSearchContacts', 'category' => 'crm', 'risk_level' => 'low'],
            ['name' => 'CRM Create Activity', 'slug' => 'crm_create_activity', 'description' => 'Create activity record', 'handler_class' => 'AiExecutionEngine@crmCreateActivity', 'category' => 'crm', 'risk_level' => 'low'],
            ['name' => 'CRM Create Task', 'slug' => 'crm_create_task', 'description' => 'Create a CRM task', 'handler_class' => 'AiExecutionEngine@crmCreateTask', 'category' => 'crm', 'risk_level' => 'low'],
            ['name' => 'Get Pipeline Stats', 'slug' => 'get_pipeline_stats', 'description' => 'Get sales pipeline statistics', 'handler_class' => 'AiExecutionEngine@getPipelineStats', 'category' => 'reports', 'risk_level' => 'low'],
            ['name' => 'Email Draft', 'slug' => 'email_draft', 'description' => 'Draft an email response', 'handler_class' => 'CommunicationController@draftEmail', 'category' => 'communication', 'risk_level' => 'medium'],
            ['name' => 'System Health Check', 'slug' => 'system_health', 'description' => 'Check application health', 'handler_class' => 'AdminController@healthCheck', 'category' => 'system', 'risk_level' => 'low'],
        ];

        foreach ($tools as $tool) {
            AiAgentTool::firstOrCreate(['slug' => $tool['slug']], $tool);
        }

        // Create 11 AI agents
        $agents = [
            ['name' => 'AI Command Center Agent', 'instructions' => 'You coordinate other AI agents. Route requests to appropriate agents and summarize results.'],
            ['name' => 'Lead Management Agent', 'instructions' => 'You classify leads, score them, prioritize, create follow-ups, and update CRM records.'],
            ['name' => 'CRM Agent', 'instructions' => 'You search CRM records, summarize them, create permitted activities, and update permitted records.'],
            ['name' => 'Sales Agent', 'instructions' => 'You analyze the sales pipeline, find stale deals, identify opportunities, and prepare follow-ups.'],
            ['name' => 'Customer Communication Agent', 'instructions' => 'You summarize communications, draft replies, and prepare follow-ups. External communication requires approval.'],
            ['name' => 'Website Enquiry Agent', 'instructions' => 'You process website enquiries, create CRM leads, classify service requirements, and assign priority.'],
            ['name' => 'Support Agent', 'instructions' => 'You classify support issues, search knowledge base, prepare responses, and escalate issues.'],
            ['name' => 'Marketing Agent', 'instructions' => 'You prepare campaigns, analyze leads, and create marketing recommendations.'],
            ['name' => 'Reporting Agent', 'instructions' => 'You generate daily, weekly, and monthly reports including CRM and sales analysis.'],
            ['name' => 'Security Monitoring Agent', 'instructions' => 'You review audit logs, detect suspicious patterns, and create alerts. You must NOT perform destructive security actions.'],
            ['name' => 'System/Deployment Agent', 'instructions' => 'You check application health, review Laravel errors, and report configuration issues. You must NOT execute arbitrary shell commands.'],
        ];

        foreach ($agents as $i => $agent) {
            $count = $i + 1;
            AiAgent::firstOrCreate(
                ['slug' => Str::slug($agent['name'])],
                [
                    'agent_id' => 'AGENT-' . str_pad($count, 4, '0', STR_PAD_LEFT),
                    'name' => $agent['name'],
                    'description' => $agent['name'] . ' for TECH360 operations',
                    'instructions' => $agent['instructions'],
                    'provider' => env('AI_PROVIDER', 'openai'),
                    'model' => env('AI_MODEL', 'gpt-4o-mini'),
                    'mode' => 'approval',
                    'status' => 'active',
                ]
            );
        }

        // Seed knowledge documents
        $knowledge = [
            ['title' => 'TECH360 Services Overview', 'category' => 'company', 'content' => 'TECH360 provides website development, software development, CRM development, cloud services, AI solutions, automation, and digital transformation services.'],
            ['title' => 'Pricing Information', 'category' => 'pricing', 'content' => 'Starter: From $750. Professional: From $2,500. Business Systems: From $5,000. Custom Software: From $10,000. Enterprise: Custom estimate.'],
            ['title' => 'Refund Policy Summary', 'category' => 'policy', 'content' => 'After Scope of Work approval, project payments are non-refundable except where required by applicable law or otherwise agreed in writing.'],
            ['title' => 'Support Process', 'category' => 'support', 'content' => '30-day post-delivery bug-fix support included. New features are not bug fixes. Emergency support has separate pricing.'],
        ];

        foreach ($knowledge as $doc) {
            \App\Models\AiKnowledgeDocument::firstOrCreate(
                ['title' => $doc['title']],
                array_merge($doc, ['is_active' => true])
            );
        }

        echo "AI agents seeded: " . AiAgent::count() . " agents, " . AiAgentTool::count() . " tools, " . \App\Models\AiKnowledgeDocument::count() . " knowledge docs\n";
    }
}
