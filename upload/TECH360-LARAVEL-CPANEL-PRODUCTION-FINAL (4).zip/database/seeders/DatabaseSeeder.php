<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use App\Models\User;
use App\Models\Service;
use App\Models\Setting;

class DatabaseSeeder extends Seeder {
    public function run(): void {
        // Admin user with secure random password
        $password = Str::random(32);
        User::firstOrCreate(
            ['email' => 'admin@tech360.io'],
            [
                'name' => 'Super Admin',
                'password' => Hash::make($password),
                'role' => 'admin',
            ]
        );
        echo "Admin: admin@tech360.io (password: " . $password . ")\n";

        // AI Agents
        $this->call(AiAgentSeeder::class);

        // Services
        $services = [
            ['slug' => 'website-development', 'title' => 'Website Design & Development', 'icon' => 'fa-code', 'short_description' => 'Premium responsive websites with SEO optimization.'],
            ['slug' => 'software-development', 'title' => 'Software Development', 'icon' => 'fa-laptop-code', 'short_description' => 'Custom software, APIs, and enterprise applications.'],
            ['slug' => 'cloud-services', 'title' => 'Cloud Services', 'icon' => 'fa-cloud', 'short_description' => 'Cloud deployment, infrastructure, and monitoring.'],
            ['slug' => 'ai-solutions', 'title' => 'AI Solutions', 'icon' => 'fa-brain', 'short_description' => 'Intelligent automation and AI-powered systems.'],
            ['slug' => 'data-analytics', 'title' => 'Data & Analytics', 'icon' => 'fa-chart-line', 'short_description' => 'Dashboards, reporting, and business intelligence.'],
            ['slug' => 'crm-automation', 'title' => 'CRM & Automation', 'icon' => 'fa-users-cog', 'short_description' => 'Lead management, customer tracking, and automation.'],
            ['slug' => 'automation', 'title' => 'Business Automation', 'icon' => 'fa-cogs', 'short_description' => 'Workflow automation and process optimization.'],
            ['slug' => 'digital-solutions', 'title' => 'Digital Solutions', 'icon' => 'fa-lightbulb', 'short_description' => 'Complete digital transformation services.'],
        ];
        foreach ($services as $svc) {
            Service::firstOrCreate(['slug' => $svc['slug']], array_merge($svc, ['is_active' => true, 'sort_order' => 0]));
        }

        // Settings
        Setting::set('company_name', 'TECH360', 'general');
        Setting::set('contact_email', 'support@tech360.io', 'general');
        Setting::set('contact_phone', '+1 (800) 360-0199', 'general');
        Setting::set('website_url', 'https://tech360.io', 'general');
        Setting::set('slogan', 'CONNECT • INNOVATE • GROW', 'branding');

        echo "Seeding complete.\n";
    }
}
