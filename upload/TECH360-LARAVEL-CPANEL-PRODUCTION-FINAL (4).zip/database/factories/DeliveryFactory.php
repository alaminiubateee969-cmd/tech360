<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Delivery;

class DeliveryFactory extends Factory
{
    protected $model = Delivery::class;

    public function definition(): array
    {
        $count = Delivery::count();
        return [
            'delivery_id' => 'DEL-2026-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT),
            'project_id' => null,
            'client_id' => null,
            'payment_status' => 'pending',
            'qa_status' => 'pending',
            'admin_approval' => 'pending',
            'access_status' => 'TECH360_CONTROLLED',
            'password_rotation_complete' => false,
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }
}
