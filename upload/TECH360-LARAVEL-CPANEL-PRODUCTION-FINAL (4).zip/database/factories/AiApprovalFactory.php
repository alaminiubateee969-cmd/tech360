<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\AiApproval;

class AiApprovalFactory extends Factory
{
    protected $model = AiApproval::class;

    public function definition(): array
    {
        $count = AiApproval::count();
        return [
            'approval_id' => 'APR-' . date('Y') . '-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT),
            'ai_agent_id' => null,
            'ai_agent_execution_id' => null,
            'action' => 'execute_agent',
            'reason' => $this->faker->sentence(),
            'generated_content' => $this->faker->paragraph(),
            'risk_level' => 'medium',
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }
}
