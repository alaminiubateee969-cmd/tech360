<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Contact;

class ContactFactory extends Factory
{
    protected $model = Contact::class;

    public function definition(): array
    {
        $count = Contact::count();
        return [
            'contact_id' => 'TECH-CON-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT),
            'first_name' => $this->faker->firstName(),
            'last_name' => $this->faker->lastName(),
            'email' => $this->faker->unique()->safeEmail(),
            'phone' => $this->faker->optional()->phoneNumber(),
            'source' => $this->faker->randomElement(['website', 'manual', 'referral', 'ad']),
            'status' => $this->faker->randomElement(['lead', 'qualified', 'customer', 'inactive']),
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }
}
