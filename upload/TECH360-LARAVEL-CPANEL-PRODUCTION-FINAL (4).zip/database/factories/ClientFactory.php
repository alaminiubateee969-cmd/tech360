<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Client;

class ClientFactory extends Factory
{
    protected $model = Client::class;

    public function definition(): array
    {
        $count = Client::count();
        return [
            'client_id' => 'TECH-CL-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT),
            'user_id' => null,
            'company_name' => $this->faker->optional()->company(),
            'primary_email' => $this->faker->unique()->safeEmail(),
            'primary_phone' => $this->faker->optional()->phoneNumber(),
            'status' => 'active',
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }
}
