<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Payment;

class PaymentFactory extends Factory
{
    protected $model = Payment::class;

    public function definition(): array
    {
        return [
            'project_id' => null,
            'client_id' => null,
            'amount' => $this->faker->randomFloat(2, 500, 10000),
            'currency' => 'USD',
            'method' => 'stripe',
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }
}
