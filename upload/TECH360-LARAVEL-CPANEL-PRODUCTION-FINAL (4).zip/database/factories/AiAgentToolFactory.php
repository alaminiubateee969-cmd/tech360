<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\AiAgentTool;

class AiAgentToolFactory extends Factory
{
    protected $model = AiAgentTool::class;

    public function definition(): array
    {
        $name = $this->faker->words(3, true);
        return [
            'name' => $name,
            'slug' => \Illuminate\Support\Str::slug($name),
            'description' => $this->faker->sentence(),
            'handler_class' => 'AiExecutionEngine@' . $this->faker->word(),
            'category' => $this->faker->randomElement(['crm', 'reports', 'communication', 'system']),
            'risk_level' => $this->faker->randomElement(['low', 'medium', 'high']),
            'enabled' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }
}
