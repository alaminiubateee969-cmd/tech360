<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\LeadCrm;

class LeadCrmFactory extends Factory
{
    protected $model = LeadCrm::class;

    public function definition(): array
    {
        $count = LeadCrm::count();
        return [
            'lead_id' => 'TECH-LEAD-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT),
            'contact_id' => null,
            'source' => $this->faker->randomElement(['website', 'manual', 'ad', 'referral']),
            'service_interest' => $this->faker->randomElement(['Website Development', 'CRM', 'Software', 'Cloud']),
            'status' => 'new',
            'priority' => 'medium',
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }
}
