<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Deal;

class DealFactory extends Factory
{
    protected $model = Deal::class;

    public function definition(): array
    {
        return [
            'title' => $this->faker->words(3, true),
            'contact_id' => null,
            'value' => $this->faker->randomFloat(2, 1000, 50000),
            'currency' => 'USD',
            'stage' => $this->faker->randomElement(['lead', 'qualified', 'proposal', 'negotiation', 'won', 'lost']),
            'probability' => $this->faker->numberBetween(10, 90),
            'expected_close_date' => $this->faker->optional()->dateTimeBetween('+1 week', '+3 months')?->format('Y-m-d'),
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }
}
