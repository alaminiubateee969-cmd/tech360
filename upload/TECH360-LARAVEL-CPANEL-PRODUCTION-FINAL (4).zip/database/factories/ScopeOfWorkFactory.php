<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\ScopeOfWork;

class ScopeOfWorkFactory extends Factory
{
    protected $model = ScopeOfWork::class;

    public function definition(): array
    {
        $count = ScopeOfWork::count();
        return [
            'scope_id' => 'SOW-' . str_pad($count + 1, 5, '0', STR_PAD_LEFT),
            'project_id' => null,
            'version' => 1,
            'title' => $this->faker->sentence(),
            'objective' => $this->faker->paragraph(),
            'features_included' => json_encode(['feature1', 'feature2']),
            'features_excluded' => json_encode(['not_included']),
            'timeline' => '8 weeks',
            'payment_amount' => $this->faker->randomFloat(2, 1000, 20000),
            'payment_terms' => '100% upfront',
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }
}
