<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\AiKnowledgeDocument;

class AiKnowledgeDocumentFactory extends Factory
{
    protected $model = AiKnowledgeDocument::class;

    public function definition(): array
    {
        return [
            'title' => $this->faker->sentence(4),
            'category' => $this->faker->randomElement(['company', 'pricing', 'policy', 'support', 'services', 'technical', 'general']),
            'content' => $this->faker->paragraphs(3, true),
            'is_active' => true,
            'created_by' => null,
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }
}
