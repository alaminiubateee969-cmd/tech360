<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Project;

class ProjectFactory extends Factory
{
    protected $model = Project::class;

    public function definition(): array
    {
        $count = Project::count();
        return [
            'project_id' => 'PROJ-' . str_pad($count + 1, 5, '0', STR_PAD_LEFT),
            'client_id' => null, // must be set by test
            'name' => $this->faker->words(3, true),
            'slug' => $this->faker->slug(),
            'type' => $this->faker->randomElement(['website', 'software', 'crm', 'ecommerce']),
            'status' => 'active',
            'commercial_state' => 'INITIAL_INQUIRY',
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }
}
