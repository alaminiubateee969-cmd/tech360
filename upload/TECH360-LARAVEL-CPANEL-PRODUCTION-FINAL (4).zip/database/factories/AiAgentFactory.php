<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\AiAgent;

class AiAgentFactory extends Factory
{
    protected $model = AiAgent::class;

    public function definition(): array
    {
        $count = AiAgent::count();
        $name = $this->faker->words(3, true);
        return [
            'agent_id' => 'AGENT-' . str_pad($count + 1, 4, '0', STR_PAD_LEFT),
            'name' => $name,
            'slug' => \Illuminate\Support\Str::slug($name),
            'description' => $this->faker->sentence(),
            'instructions' => $this->faker->paragraph(),
            'provider' => 'openai',
            'model' => 'gpt-4o-mini',
            'mode' => 'approval',
            'status' => 'active',
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }
}
