<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\AiAgentExecution;

class AiAgentExecutionFactory extends Factory
{
    protected $model = AiAgentExecution::class;

    public function definition(): array
    {
        $count = AiAgentExecution::count();
        return [
            'execution_id' => 'EXEC-' . date('Y') . '-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT),
            'ai_agent_id' => null,
            'user_id' => null,
            'input' => $this->faker->sentence(),
            'status' => 'awaiting_approval',
            'provider' => 'openai',
            'model' => 'gpt-4o-mini',
            'started_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }
}
