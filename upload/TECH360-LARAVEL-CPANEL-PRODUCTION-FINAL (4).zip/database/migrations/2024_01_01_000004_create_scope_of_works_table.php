<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('scope_of_works', function (Blueprint $table) {
            $table->id();
            $table->string('scope_id')->unique(); // SOW-2026-000001
            $table->unsignedBigInteger('project_id');
            $table->foreign('project_id')->references('id')->on('projects')->onDelete('cascade');
            $table->string('version')->default('1.0');
            $table->string('title');
            $table->text('objective')->nullable();
            $table->json('features_included')->nullable();
            $table->json('features_excluded')->nullable();
            $table->string('timeline')->nullable();
            $table->decimal('payment_amount', 12, 2)->default(0);
            $table->string('payment_terms')->nullable();
            $table->json('deliverables')->nullable();
            $table->integer('revision_allowance')->default(2);
            $table->enum('status', ['draft', 'sent', 'pending_approval', 'approved', 'rejected'])->default('draft');
            $table->boolean('terms_accepted')->default(false);
            $table->boolean('refund_policy_accepted')->default(false);
            $table->boolean('preview_acknowledged')->default(false);
            $table->text('immutable_snapshot')->nullable();
            $table->unsignedBigInteger('approved_by')->nullable();
            $table->foreign('approved_by')->references('id')->on('users')->onDelete('set null');
            $table->timestamp('approved_at')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->index('project_id');
            $table->index('status');
        });
    }
    public function down(): void { Schema::dropIfExists('scope_of_works'); }
};
