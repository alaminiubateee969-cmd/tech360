<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('previews', function (Blueprint $table) {
            $table->id();
            $table->string('preview_id')->unique(); // PREV-2026-000001
            $table->unsignedBigInteger('project_id');
            $table->foreign('project_id')->references('id')->on('projects')->onDelete('cascade');
            $table->string('version');
            $table->string('url');
            $table->string('access_token')->nullable();
            $table->string('password_hash')->nullable();
            $table->timestamp('expires_at');
            $table->enum('status', ['active', 'expired', 'revoked', 'approved'])->default('active');
            $table->timestamp('viewed_at')->nullable();
            $table->integer('view_count')->default(0);
            $table->timestamps();
            $table->index('project_id');
            $table->index('status');
        });
    }
    public function down(): void { Schema::dropIfExists('previews'); }
};
