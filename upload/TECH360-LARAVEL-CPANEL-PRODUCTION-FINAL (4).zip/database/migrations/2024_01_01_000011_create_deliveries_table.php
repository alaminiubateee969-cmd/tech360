<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('deliveries', function (Blueprint $table) {
            $table->id();
            $table->string('delivery_id')->unique(); // DEL-2026-000001
            $table->unsignedBigInteger('project_id');
            $table->foreign('project_id')->references('id')->on('projects')->onDelete('cascade');
            $table->unsignedBigInteger('client_id');
            $table->foreign('client_id')->references('id')->on('clients')->onDelete('cascade');
            $table->string('payment_status')->default('pending');
            $table->string('qa_status')->default('pending');
            $table->string('admin_approval')->default('pending');
            $table->unsignedBigInteger('admin_approved_by')->nullable();
            $table->foreign('admin_approved_by')->references('id')->on('users')->onDelete('set null');
            $table->timestamp('admin_approved_at')->nullable();
            $table->string('package_hash')->nullable();
            $table->string('storage_path')->nullable();
            $table->string('signed_url')->nullable();
            $table->string('access_token')->nullable();
            $table->timestamp('signed_url_expiry')->nullable();
            $table->boolean('client_confirmed')->default(false);
            $table->timestamp('client_confirmed_at')->nullable();
            $table->boolean('password_rotation_complete')->default(false);
            $table->string('access_status')->default('TECH360_CONTROLLED');
            $table->timestamps();
            $table->index('project_id');
            $table->index('admin_approval');
        });
    }
    public function down(): void { Schema::dropIfExists('deliveries'); }
};
