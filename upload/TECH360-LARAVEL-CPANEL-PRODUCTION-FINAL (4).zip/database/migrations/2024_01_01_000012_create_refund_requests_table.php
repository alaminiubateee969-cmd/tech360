<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('refund_requests', function (Blueprint $table) {
            $table->id();
            $table->string('refund_id')->unique(); // REF-2026-000001
            $table->unsignedBigInteger('client_id');
            $table->foreign('client_id')->references('id')->on('clients')->onDelete('cascade');
            $table->unsignedBigInteger('project_id')->nullable();
            $table->foreign('project_id')->references('id')->on('projects')->onDelete('set null');
            $table->string('invoice_number')->nullable();
            $table->string('payment_reference')->nullable();
            $table->date('payment_date')->nullable();
            $table->string('reason');
            $table->text('description')->nullable();
            $table->string('status')->default('refund_requested'); // refund_requested, refund_review, approved, denied, refunded
            $table->unsignedBigInteger('reviewed_by')->nullable();
            $table->foreign('reviewed_by')->references('id')->on('users')->onDelete('set null');
            $table->timestamp('reviewed_at')->nullable();
            $table->string('decision')->nullable();
            $table->text('resolution')->nullable();
            $table->timestamps();
            $table->index('client_id');
            $table->index('status');
        });
    }
    public function down(): void { Schema::dropIfExists('refund_requests'); }
};
