<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('scope_versions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('scope_id');
            $table->foreign('scope_id')->references('id')->on('scope_of_works')->onDelete('cascade');
            $table->string('version');
            $table->text('content_snapshot');
            $table->string('changes')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->foreign('created_by')->references('id')->on('users')->onDelete('set null');
            $table->timestamps();
            $table->index('scope_id');
        });
    }
    public function down(): void { Schema::dropIfExists('scope_versions'); }
};
