<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('ai_agent_messages', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('ai_agent_execution_id');
            $table->foreign('ai_agent_execution_id')->references('id')->on('ai_agent_executions')->onDelete('cascade');
            $table->enum('role', ['system', 'user', 'assistant', 'tool']);
            $table->text('content');
            $table->string('tool_name')->nullable();
            $table->json('tool_input')->nullable();
            $table->json('tool_output')->nullable();
            $table->timestamps();
            $table->index('ai_agent_execution_id');
        });
    }
    public function down(): void { Schema::dropIfExists('ai_agent_messages'); }
};
