<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('ai_agent_memories', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('ai_agent_id');
            $table->foreign('ai_agent_id')->references('id')->on('ai_agents')->onDelete('cascade');
            $table->enum('type', ['short_term', 'long_term', 'context']);
            $table->string('key')->nullable();
            $table->text('value');
            $table->unsignedBigInteger('contact_id')->nullable();
            $table->foreign('contact_id')->references('id')->on('contacts')->onDelete('cascade');
            $table->timestamp('expires_at')->nullable();
            $table->timestamps();
            $table->index('ai_agent_id');
            $table->index('contact_id');
        });
    }
    public function down(): void { Schema::dropIfExists('ai_agent_memories'); }
};
