<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('ai_agent_workflows', function (Blueprint $table) {
            $table->id();
            $table->string('workflow_id')->unique();
            $table->string('name');
            $table->text('description')->nullable();
            $table->string('trigger_type')->nullable();
            $table->json('steps')->nullable();
            $table->enum('status', ['active', 'inactive'])->default('inactive');
            $table->string('schedule')->nullable();
            $table->timestamps();
            $table->index('status');
        });
    }
    public function down(): void { Schema::dropIfExists('ai_agent_workflows'); }
};
