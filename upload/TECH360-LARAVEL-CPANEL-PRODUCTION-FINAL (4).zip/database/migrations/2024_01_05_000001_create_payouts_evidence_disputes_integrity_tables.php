<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        // 1. PAYOUTS — separate from payment verification.
        // Payment verification confirms client paid. Payout tracking confirms TECH360 disbursed funds.
        Schema::create('payouts', function (Blueprint $table) {
            $table->id();
            $table->string('payout_id', 30)->unique(); // PAY-2026-000001
            $table->unsignedBigInteger('project_id')->nullable();
            $table->foreign('project_id')->references('id')->on('projects')->onDelete('set null');
            $table->unsignedBigInteger('client_id')->nullable();
            $table->foreign('client_id')->references('id')->on('clients')->onDelete('set null');
            $table->unsignedBigInteger('payment_id')->nullable();
            $table->foreign('payment_id')->references('id')->on('payments')->onDelete('set null');
            $table->decimal('amount', 12, 2);
            $table->string('currency', 3)->default('USD');
            $table->string('recipient_type'); // developer, vendor, contractor, partner
            $table->string('recipient_name')->nullable();
            $table->string('recipient_account_reference')->nullable(); // masked
            $table->string('method')->nullable(); // bank_transfer, paypal, wise, stripe_payout
            $table->string('provider_reference')->nullable();
            $table->string('status')->default('pending'); // pending, approved, processing, completed, failed, on_hold
            $table->boolean('instant_payout_eligible')->default(false);
            $table->boolean('high_value_review_required')->default(false);
            $table->decimal('risk_score', 5, 2)->default(0);
            $table->text('risk_flags')->nullable();
            $table->unsignedBigInteger('approved_by')->nullable();
            $table->timestamp('approved_at')->nullable();
            $table->unsignedBigInteger('processed_by')->nullable();
            $table->timestamp('processed_at')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->softDeletes(); // no-delete policy: payouts are soft-deleted only
            $table->index('project_id');
            $table->index('status');
            $table->index('instant_payout_eligible');
        });

        // 2. EVIDENCE VAULT — centralized immutable evidence storage.
        Schema::create('evidence_vault', function (Blueprint $table) {
            $table->id();
            $table->string('evidence_id', 30)->unique(); // EVD-2026-000001
            $table->string('type'); // communication, payment, contract, invoice, delivery, acceptance, payout, refund, dispute, audit, source_release, handover
            $table->unsignedBigInteger('project_id')->nullable();
            $table->foreign('project_id')->references('id')->on('projects')->onDelete('cascade');
            $table->unsignedBigInteger('client_id')->nullable();
            $table->foreign('client_id')->references('id')->on('clients')->onDelete('cascade');
            $table->string('title');
            $table->text('description')->nullable();
            $table->string('file_path')->nullable(); // private storage path
            $table->string('file_hash', 64)->nullable(); // SHA-256 hash of file
            $table->string('content_hash', 64)->nullable(); // SHA-256 hash of textual content
            $table->longText('metadata')->nullable(); // JSON
            $table->timestamp('event_at')->nullable(); // when the event actually occurred
            $table->unsignedBigInteger('uploaded_by')->nullable();
            $table->boolean('is_locked')->default(true); // locked = no modification
            $table->boolean('permanent_delete_blocked')->default(true); // no-delete policy
            $table->timestamps();
            $table->softDeletes();
            $table->index('type');
            $table->index('project_id');
            $table->index('client_id');
        });

        // 3. DISPUTES / CHARGEBACKS
        Schema::create('disputes', function (Blueprint $table) {
            $table->id();
            $table->string('dispute_id', 30)->unique(); // DSP-2026-000001
            $table->unsignedBigInteger('payment_id')->nullable();
            $table->foreign('payment_id')->references('id')->on('payments')->onDelete('set null');
            $table->unsignedBigInteger('project_id')->nullable();
            $table->foreign('project_id')->references('id')->on('projects')->onDelete('cascade');
            $table->unsignedBigInteger('client_id')->nullable();
            $table->foreign('client_id')->references('id')->on('clients')->onDelete('cascade');
            $table->string('case_number')->nullable(); // bank or Stripe case number
            $table->string('source'); // stripe, paypal, bank_chargeback, client_dispute
            $table->string('reason_code')->nullable();
            $table->text('reason')->nullable();
            $table->decimal('disputed_amount', 12, 2)->default(0);
            $table->string('status')->default('open'); // open, evidence_compiling, evidence_submitted, won, lost, expired
            $table->timestamp('respond_by')->nullable();
            $table->timestamp('submitted_at')->nullable();
            $table->text('evidence_package_path')->nullable(); // path to compiled ZIP
            $table->string('evidence_package_hash', 64)->nullable(); // SHA-256 of package
            $table->unsignedBigInteger('compiled_by')->nullable();
            $table->unsignedBigInteger('resolved_by')->nullable();
            $table->timestamp('resolved_at')->nullable();
            $table->text('resolution_notes')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->index('status');
            $table->index('project_id');
        });

        // 4. CRYPTOGRAPHIC INTEGRITY RECORDS — for contracts, invoices, deliveries, source releases
        Schema::create('integrity_records', function (Blueprint $table) {
            $table->id();
            $table->string('record_id', 30)->unique(); // INT-2026-000001
            $table->string('entity_type'); // contract, invoice, delivery, source_release, scope, handover, evidence
            $table->unsignedBigInteger('entity_id');
            $table->string('algorithm', 20)->default('sha256');
            $table->string('hash', 64);
            $table->longText('signed_payload')->nullable(); // canonical JSON that was hashed
            $table->string('salt', 64)->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->string('verification_status')->default('verified'); // verified, tampered, unknown
            $table->timestamp('verified_at')->nullable();
            $table->text('tamper_note')->nullable();
            $table->timestamps();
            $table->index(['entity_type', 'entity_id']);
            $table->index('hash');
        });

        // 5. CLIENT VERIFICATIONS — for client ID + email verification workflow
        Schema::create('client_verifications', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('client_id');
            $table->foreign('client_id')->references('id')->on('clients')->onDelete('cascade');
            $table->string('verification_type'); // email, phone, whatsapp, identity
            $table->string('status')->default('pending'); // pending, sent, verified, expired, failed
            $table->string('token', 64)->unique();
            $table->string('channel')->nullable(); // email, sms, whatsapp
            $table->string('destination')->nullable(); // masked email/phone
            $table->timestamp('sent_at')->nullable();
            $table->timestamp('verified_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->string('ip_address', 45)->nullable();
            $table->string('user_agent')->nullable();
            $table->timestamps();
            $table->index('client_id');
            $table->index('token');
        });

        // 6. COMMUNICATION CHANNEL — extends existing communications table for WhatsApp-first flow
        Schema::create('communication_channels', function (Blueprint $table) {
            $table->id();
            $table->string('channel_id', 30)->unique(); // CHN-2026-000001
            $table->unsignedBigInteger('client_id')->nullable();
            $table->foreign('client_id')->references('id')->on('clients')->onDelete('set null');
            $table->unsignedBigInteger('contact_id')->nullable();
            $table->foreign('contact_id')->references('id')->on('contacts')->onDelete('set null');
            $table->string('primary_channel')->default('whatsapp'); // whatsapp, email, phone, sms
            $table->string('whatsapp_number')->nullable();
            $table->string('email_address')->nullable();
            $table->string('phone_number')->nullable();
            $table->boolean('email_collected')->default(false);
            $table->boolean('email_verified')->default(false);
            $table->boolean('whatsapp_verified')->default(false);
            $table->unsignedBigInteger('bd_manager_id')->nullable(); // assigned BD manager
            $table->foreign('bd_manager_id')->references('id')->on('users')->onDelete('set null');
            $table->timestamp('first_contact_at')->nullable();
            $table->string('client_identifier', 20)->unique()->nullable(); // TECH-CL-000001 generated on first contact
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->index('client_id');
            $table->index('bd_manager_id');
        });
    }

    public function down(): void {
        Schema::dropIfExists('communication_channels');
        Schema::dropIfExists('client_verifications');
        Schema::dropIfExists('integrity_records');
        Schema::dropIfExists('disputes');
        Schema::dropIfExists('evidence_vault');
        Schema::dropIfExists('payouts');
    }
};
