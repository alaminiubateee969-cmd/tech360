<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('ai_agent_executions', function (Blueprint $table) {
            $table->id();
            $table->string('execution_id')->unique();
            $table->unsignedBigInteger('ai_agent_id');
            $table->foreign('ai_agent_id')->references('id')->on('ai_agents')->onDelete('cascade');
            $table->unsignedBigInteger('user_id')->nullable();
            $table->foreign('user_id')->references('id')->on('users')->onDelete('set null');
            $table->string('input');
            $table->text('output')->nullable();
            $table->enum('status', ['pending', 'running', 'completed', 'failed', 'awaiting_approval'])->default('pending');
            $table->string('provider')->nullable();
            $table->string('model')->nullable();
            $table->integer('tokens_input')->nullable();
            $table->integer('tokens_output')->nullable();
            $table->text('error')->nullable();
            $table->timestamp('started_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
            $table->index('ai_agent_id');
            $table->index('status');
        });
    }
    public function down(): void { Schema::dropIfExists('ai_agent_executions'); }
};
