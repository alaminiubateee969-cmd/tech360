<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('ai_agents', function (Blueprint $table) {
            $table->id();
            $table->string('agent_id')->unique();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->text('instructions')->nullable();
            $table->string('provider')->default('openai');
            $table->string('model')->default('gpt-4o-mini');
            $table->enum('mode', ['manual', 'approval', 'autonomous'])->default('approval');
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->json('config')->nullable();
            $table->timestamps();
            $table->index('status');
        });
    }
    public function down(): void { Schema::dropIfExists('ai_agents'); }
};
