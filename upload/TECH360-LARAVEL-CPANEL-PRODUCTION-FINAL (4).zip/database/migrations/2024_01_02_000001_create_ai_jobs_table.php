<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('ai_jobs', function (Blueprint $table) {
            $table->id();
            $table->string('job_id')->unique(); // JOB-2026-000001
            $table->string('job_type'); // lead.created, scope.requested, followup.requested, etc.
            $table->unsignedBigInteger('client_id')->nullable();
            $table->unsignedBigInteger('project_id')->nullable();
            $table->string('agent_name')->nullable();
            $table->string('status')->default('queued'); // queued, running, completed, failed
            $table->text('input')->nullable();
            $table->text('result')->nullable();
            $table->text('error')->nullable();
            $table->timestamp('started_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
            $table->index('status');
            $table->index('job_type');
            $table->index('client_id');
        });
    }
    public function down(): void { Schema::dropIfExists('ai_jobs'); }
};
