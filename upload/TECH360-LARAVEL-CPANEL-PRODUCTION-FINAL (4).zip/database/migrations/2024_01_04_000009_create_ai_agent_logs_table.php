<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('ai_agent_logs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('ai_agent_id')->nullable();
            $table->foreign('ai_agent_id')->references('id')->on('ai_agents')->onDelete('set null');
            $table->unsignedBigInteger('ai_agent_execution_id')->nullable();
            $table->foreign('ai_agent_execution_id')->references('id')->on('ai_agent_executions')->onDelete('set null');
            $table->string('level')->default('info');
            $table->string('action');
            $table->text('message');
            $table->json('metadata')->nullable();
            $table->unsignedBigInteger('user_id')->nullable();
            $table->foreign('user_id')->references('id')->on('users')->onDelete('set null');
            $table->timestamps();
            $table->index('ai_agent_id');
            $table->index('action');
        });
    }
    public function down(): void { Schema::dropIfExists('ai_agent_logs'); }
};
