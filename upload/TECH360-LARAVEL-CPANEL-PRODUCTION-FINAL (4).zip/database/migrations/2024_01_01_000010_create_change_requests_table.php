<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('change_requests', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('project_id');
            $table->foreign('project_id')->references('id')->on('projects')->onDelete('cascade');
            $table->string('description');
            $table->text('details')->nullable();
            $table->decimal('estimated_cost', 12, 2)->nullable();
            $table->string('estimated_time')->nullable();
            $table->enum('status', ['pending', 'quoted', 'approved', 'rejected', 'completed'])->default('pending');
            $table->unsignedBigInteger('requested_by')->nullable();
            $table->foreign('requested_by')->references('id')->on('users')->onDelete('set null');
            $table->timestamps();
            $table->index('project_id');
            $table->index('status');
        });
    }
    public function down(): void { Schema::dropIfExists('change_requests'); }
};
