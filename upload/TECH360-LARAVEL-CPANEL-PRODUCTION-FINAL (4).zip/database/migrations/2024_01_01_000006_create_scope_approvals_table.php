<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('scope_approvals', function (Blueprint $table) {
            $table->id();
            $table->string('approval_id')->unique(); // APR-2026-000001
            $table->unsignedBigInteger('client_id');
            $table->foreign('client_id')->references('id')->on('clients')->onDelete('cascade');
            $table->unsignedBigInteger('project_id');
            $table->foreign('project_id')->references('id')->on('projects')->onDelete('cascade');
            $table->unsignedBigInteger('scope_id');
            $table->foreign('scope_id')->references('id')->on('scope_of_works')->onDelete('cascade');
            $table->string('scope_version');
            $table->string('terms_version')->default('May 19, 2026');
            $table->string('refund_policy_version')->default('May 19, 2026');
            $table->string('approval_method')->default('web_form');
            $table->string('ip_address')->nullable();
            $table->text('user_agent')->nullable();
            $table->unsignedBigInteger('user_id');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->timestamp('approved_at');
            $table->text('immutable_snapshot')->nullable();
            $table->timestamps();
            $table->index('client_id');
            $table->index('project_id');
        });
    }
    public function down(): void { Schema::dropIfExists('scope_approvals'); }
};
