<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('ai_agent_tools', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->string('slug')->unique();
            $table->text('description');
            $table->json('input_schema')->nullable();
            $table->json('output_schema')->nullable();
            $table->string('handler_class');
            $table->string('category')->default('crm');
            $table->enum('risk_level', ['low', 'medium', 'high'])->default('medium');
            $table->boolean('enabled')->default(true);
            $table->timestamps();
            $table->index('slug');
        });
    }
    public function down(): void { Schema::dropIfExists('ai_agent_tools'); }
};
