<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('ai_approvals', function (Blueprint $table) {
            $table->id();
            $table->string('approval_id')->unique();
            $table->unsignedBigInteger('ai_agent_id')->nullable();
            $table->foreign('ai_agent_id')->references('id')->on('ai_agents')->onDelete('set null');
            $table->unsignedBigInteger('ai_agent_execution_id')->nullable();
            $table->foreign('ai_agent_execution_id')->references('id')->on('ai_agent_executions')->onDelete('set null');
            $table->unsignedBigInteger('user_id')->nullable();
            $table->foreign('user_id')->references('id')->on('users')->onDelete('set null');
            $table->string('action');
            $table->string('target_type')->nullable();
            $table->unsignedBigInteger('target_id')->nullable();
            $table->text('reason')->nullable();
            $table->text('generated_content')->nullable();
            $table->enum('risk_level', ['low', 'medium', 'high'])->default('medium');
            $table->enum('status', ['pending', 'approved', 'rejected', 'expired'])->default('pending');
            $table->unsignedBigInteger('reviewer_id')->nullable();
            $table->foreign('reviewer_id')->references('id')->on('users')->onDelete('set null');
            $table->timestamp('reviewed_at')->nullable();
            $table->text('review_note')->nullable();
            $table->text('execution_result')->nullable();
            $table->timestamps();
            $table->index('status');
            $table->index('ai_agent_id');
        });
    }
    public function down(): void { Schema::dropIfExists('ai_approvals'); }
};
