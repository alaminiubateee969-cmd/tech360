<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('ai_agent_skills', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('ai_agent_id');
            $table->foreign('ai_agent_id')->references('id')->on('ai_agents')->onDelete('cascade');
            $table->string('name');
            $table->text('description')->nullable();
            $table->boolean('enabled')->default(true);
            $table->timestamps();
            $table->index('ai_agent_id');
        });
    }
    public function down(): void { Schema::dropIfExists('ai_agent_skills'); }
};
