<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('portfolio', function (Blueprint $table) {
            $table->id();
            $table->string('slug')->unique();
            $table->string('title');
            $table->string('client_name')->nullable();
            $table->string('industry')->nullable();
            $table->string('image')->nullable();
            $table->string('screenshot')->nullable();
            $table->string('technology')->nullable();
            $table->json('services_delivered')->nullable();
            $table->text('description')->nullable();
            $table->text('results')->nullable();
            $table->string('seo_title')->nullable();
            $table->text('seo_description')->nullable();
            $table->boolean('is_featured')->default(false);
            $table->boolean('is_active')->default(true);
            $table->integer('sort_order')->default(0);
            $table->timestamps();
            $table->index('slug');
        });
    }
    public function down(): void { Schema::dropIfExists('portfolio'); }
};
