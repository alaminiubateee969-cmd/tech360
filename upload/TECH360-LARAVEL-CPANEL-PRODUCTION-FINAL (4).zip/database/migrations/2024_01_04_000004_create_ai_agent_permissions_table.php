<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('ai_agent_permissions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('ai_agent_id');
            $table->foreign('ai_agent_id')->references('id')->on('ai_agents')->onDelete('cascade');
            $table->unsignedBigInteger('ai_agent_tool_id');
            $table->foreign('ai_agent_tool_id')->references('id')->on('ai_agent_tools')->onDelete('cascade');
            $table->boolean('allowed')->default(true);
            $table->timestamps();
            $table->unique(['ai_agent_id', 'ai_agent_tool_id']);
        });
    }
    public function down(): void { Schema::dropIfExists('ai_agent_permissions'); }
};
