# TECH360 LLC — Database Setup

## Tables (18 total)
users, clients, projects, scope_of_works, scope_versions, scope_approvals,
previews, invoices, payments, change_requests, project_tasks,
project_milestones, qa_records, deliveries, refund_requests, audit_logs,
sessions, cache

## Migration
```bash
php artisan migrate --force
```

## Seed
```bash
php artisan db:seed --force
```

## Default Admin
Email: admin@bdtech360.com
Password: admin123
Role: admin

## Backup
```bash
mysqldump -u USER -p DB_NAME > backup.sql
```
