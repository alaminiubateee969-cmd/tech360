# SECURITY ADVISORY — Required Action

> ⚠️ Generated: 2026-08-26
> Severity: HIGH
> Status: REQUIRES IMMEDIATE ACTION

---

## Exposed Credential Detected

During the deployment preparation chat, the following credential was shared in plaintext:

```
DATABASE_URL="mysql://user_bdtech:Alo_BDT_2026!@127.0.0.1:3306/db_bdtech"
```

This exposed:

- **MySQL Username:** `user_bdtech`
- **MySQL Password:** `Alo_BDT_2026!`
- **MySQL Host:** `127.0.0.1:3306`
- **MySQL Database:** `db_bdtech`

The exposed password (`Alo_BDT_2026!`) is NOT included in any file in this ZIP. The `.env.example` ships with `DB_PASSWORD=` (empty). The actual password must be set on the production server only.

---

## Required Action — Rotate the Exposed Password

You MUST rotate the MySQL password immediately. Anyone who observed the chat (including AI infrastructure logs, support staff, or unintended recipients if the chat was forwarded) now has the credential.

### Rotation Steps

1. **SSH into the bdtech360.com server** as root or a MySQL admin user.

2. **Connect to MySQL:**
   ```bash
   mysql -u root -p
   ```

3. **Rotate the password** for `user_bdtech`:
   ```sql
   ALTER USER 'user_bdtech'@'localhost' IDENTIFIED BY 'NEW_STRONG_RANDOM_PASSWORD_HERE';
   FLUSH PRIVILEGES;
   EXIT;
   ```

4. **Generate a strong random password** (do NOT reuse `Alo_BDT_2026!`):
   ```bash
   openssl rand -base64 32
   ```

5. **Update Laravel's `.env`** on the server with the new password:
   ```env
   DB_PASSWORD=NEW_STRONG_RANDOM_PASSWORD_HERE
   ```

6. **Clear and rebuild Laravel cache** so the new password takes effect:
   ```bash
   cd /path/to/bdtech360.com
   php artisan config:clear
   php artisan config:cache
   ```

7. **Verify the application still connects to MySQL:**
   ```bash
   php artisan migrate:status
   ```
   If migrations list displays correctly, the new password works.

8. **Audit MySQL access logs** for any unauthorized access between the time of exposure and rotation:
   ```bash
   grep "user_bdtech" /var/log/mysql/mysql.log | tail -50
   ```

---

## Other Placeholder Secrets — Must Be Replaced Before Going Live

The following secrets were shared as placeholders (`change-this-32-char-random-string-now`). These are NOT real secrets. Replace them with actual random values before production:

| Placeholder In Shared Env | What It's For | Laravel Equivalent | Generate With |
|---|---|---|---|
| `NEXTAUTH_SECRET=change-this-...` | NextAuth.js session signing | `APP_KEY` (Laravel uses APP_KEY for encryption, not NEXTAUTH_SECRET) | `php artisan key:generate --force` |
| `JWT_SECRET=change-this-...` | JWT token signing | Laravel uses APP_KEY + Sanctum; no separate JWT_SECRET needed | (N/A — Laravel handles this) |
| `OPENAI_API_KEY=sk-your-NEW-key-here` | OpenAI API access | `AI_API_KEY` | Get real key from https://platform.openai.com/api-keys |
| `RESEND_API_KEY=re_your-key-here` | Resend email service | `RESEND_API_KEY` | Get real key from https://resend.com/api-keys |

---

## Stack Mismatch Notice

The env vars you shared are **Next.js environment variables**:

- `NODE_ENV=production` → Laravel uses `APP_ENV=production`
- `PORT=3021` → Laravel doesn't use a port; Apache serves on 80/443
- `NEXTAUTH_URL` → Laravel uses `APP_URL`
- `NEXTAUTH_SECRET` → Laravel uses `APP_KEY`
- `JWT_SECRET` → Laravel uses `APP_KEY` (no separate JWT secret needed)
- `DATABASE_URL` (single connection string) → Laravel uses separate `DB_HOST`, `DB_PORT`, `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD` vars
- `REDIS_URL` → Optional in Laravel; only needed if you switch `SESSION_DRIVER=redis` and `CACHE_STORE=redis`
- `UPLOAD_DIR` → Laravel uses `storage/app/` by default; configurable via `FILESYSTEM_DISK`
- `EMAIL_FROM` → Laravel uses `MAIL_FROM_ADDRESS`
- `RESEND_API_KEY` → Same in Laravel; Resend works via SMTP at `smtp.resend.com:587`

If your server is actually running a Next.js app on port 3021 AND you want the Laravel app to also serve bdtech360.com, that's a **conflict** — both can't serve the same domain. You must choose ONE:

**Option A — Use Laravel only (what this ZIP provides):**
- Disable or stop the Next.js server on port 3021
- Point Apache document root to `bdtech360.com/public`
- Laravel serves all routes directly on port 443 (HTTPS)

**Option B — Use Next.js only (NOT what this ZIP provides):**
- Discard this Laravel ZIP
- Continue with your existing Next.js deployment
- You would need to rebuild all features in Next.js (CRM, admin, AI agents, payment flow, etc.)

**Option C — Use Next.js frontend + Laravel API backend:**
- Next.js continues on port 3021 (or 3000)
- Laravel runs separately (e.g., on `api.bdtech360.com`)
- Next.js calls Laravel API routes
- This requires CORS configuration and is significantly more complex

This ZIP is built for **Option A**. If you need Option C, contact support@tech360.io.

---

## What I Did NOT Include In The ZIP

For your safety, I excluded:

- ❌ The actual MySQL password (`Alo_BDT_2026!`) — nowhere in the ZIP
- ❌ Any real APP_KEY — `.env.example` has `APP_KEY=` (empty)
- ❌ Any real webhook secrets — empty in `.env.example`
- ❌ Any real OpenAI/Stripe/Resend API keys — empty in `.env.example`
- ❌ Any `.env` file at all — only `.env.example` (template)

All secrets must be set on the production server's `.env` file directly. Never commit `.env` to Git or include it in any downloadable archive.

---

## Verification Checklist

Before going live, confirm:

- [ ] MySQL password `Alo_BDT_2026!` rotated to a new strong value
- [ ] New MySQL password set in `.env` on the server (`DB_PASSWORD=new_value`)
- [ ] `php artisan key:generate --force` run on the server (sets APP_KEY)
- [ ] `PAYMENT_WEBHOOK_SECRET` set to a 64-char random hex string
- [ ] `AI_WEBHOOK_SECRET` set to a 64-char random hex string
- [ ] `SECURE_DOWNLOAD_SALT` set to a 64-char random hex string
- [ ] `AI_API_KEY` set to a real OpenAI key (starts with `sk-`)
- [ ] `RESEND_API_KEY` set to a real Resend key (starts with `re_`)
- [ ] `MAIL_PASSWORD` set to the Resend API key (Resend SMTP uses the API key as password)
- [ ] `.env` file has permissions `chmod 644 .env` (or stricter: `chmod 600 .env`)
- [ ] `.env` is NOT publicly accessible (visit `https://bdtech360.com/.env` — should return 403 Forbidden)

---

## Questions / Support

If you are unsure how to rotate the password or have any questions about this advisory, contact:

- **Email:** support@tech360.io
- **Documentation:** See `TECH360-Operational-Book.pdf` (in ZIP)
- **Deployment Guide:** See `DEPLOYMENT_STACKCP.md` (in ZIP)

---

© TECH360 LLC — Connect • Innovate • Grow
