# TECH360 LLC — Security

- Password hashing (bcrypt)
- CSRF protection on all forms
- XSS protection via Blade escaping
- SQL injection protection via Eloquent
- Role-based access control (admin, staff, client)
- Payment-gated source code delivery
- Server-side payment verification only
- No plaintext password storage
- .env excluded from public access
- Storage directory protected
- Audit logging on all commercial actions
