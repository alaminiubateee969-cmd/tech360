<?php
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

$app = Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->alias([
            'admin' => App\Http\Middleware\AdminMiddleware::class,
            'client' => App\Http\Middleware\ClientMiddleware::class,
        ]);
        $middleware->validateCsrfTokens(except: [
            'webhook/*',
            'api/*',
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
    })->create();

$app->register(Illuminate\Auth\AuthServiceProvider::class);
$app->register(Illuminate\Session\SessionServiceProvider::class);
$app->register(Illuminate\Cookie\CookieServiceProvider::class);
$app->register(App\Providers\AuthServiceProvider::class);

return $app;
