<?php
return [
    'default' => env('MAIL_MAILER', 'smtp'),
    'mailers' => [
        'smtp' => [
            'transport' => 'smtp',
            'url' => env('MAIL_URL'),
            'host' => env('MAIL_HOST', 'smtp.resend.com'),
            'port' => env('MAIL_PORT', 587),
            'encryption' => env('MAIL_ENCRYPTION', 'tls'),
            'username' => env('MAIL_USERNAME'),
            'password' => env('MAIL_PASSWORD'),
            'timeout' => null,
            'local_domain' => env('MAIL_EHLO_DOMAIN'),
        ],
        // Resend via SMTP (recommended — uses RESEND_API_KEY as password)
        'resend' => [
            'transport' => 'smtp',
            'host' => 'smtp.resend.com',
            'port' => 587,
            'encryption' => 'tls',
            'username' => 'resend',
            'password' => env('RESEND_API_KEY'),
            'timeout' => null,
        ],
        'ses' => [
            'transport' => 'ses',
        ],
        'sendmail' => [
            'transport' => 'sendmail',
            'path' => env('MAIL_SENDMAIL_PATH', '/usr/sbin/sendmail -bs -i'),
        ],
        'log' => [
            'transport' => 'log',
            'channel' => env('MAIL_LOG_CHANNEL'),
        ],
        'array' => [
            'transport' => 'array',
        ],
        'failover' => [
            'transport' => 'failover',
            'mailers' => [
                'smtp',
                'log',
            ],
        ],
    ],
    'from' => [
        'address' => env('MAIL_FROM_ADDRESS', 'noreply@bdtech360.com'),
        'name' => env('MAIL_FROM_NAME', 'TECH360 LLC'),
    ],
    'reply_to' => [
        'address' => env('MAIL_REPLY_TO', 'support@bdtech360.com'),
        'name' => env('MAIL_FROM_NAME', 'TECH360 LLC'),
    ],
];
