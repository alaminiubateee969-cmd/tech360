<?php
return [
    'default' => env('DB_CONNECTION', 'mysql'),
    'connections' => [
        'mysql' => [
            'driver' => 'mysql',
            'host' => env('DB_HOST', '127.0.0.1'),
            'port' => env('DB_PORT', '3306'),
            'database' => env('DB_DATABASE', 'tech360'),
            'username' => env('DB_USERNAME', 'root'),
            'password' => env('DB_PASSWORD', ''),
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
            'prefix' => '',
            'strict' => true,
            'engine' => null,
            // SSL options for shared hosting (StackCP, AWS RDS, etc.)
            'sslmode' => env('DB_SSLMODE', 'preferred'),
            'sslcert' => env('DB_SSLCERT'),
            'sslkey' => env('DB_SSLKEY'),
            'sslca' => env('DB_SSLCA'),
            'options' => array_filter([
                // Only enable SSL CA when explicitly set — avoids PHP 8.5 deprecation warnings on hosts
                // that do not have a CA bundle configured.
                !empty(env('DB_SSLCA')) ? PDO::MYSQL_ATTR_SSL_CA => env('DB_SSLCA') : null,
            ]),
        ],
        // SQLite kept for testing only — never used in production
        'sqlite' => [
            'driver' => 'sqlite',
            'database' => env('DB_DATABASE', database_path('database.sqlite')),
            'prefix' => '',
        ],
    ],
];
