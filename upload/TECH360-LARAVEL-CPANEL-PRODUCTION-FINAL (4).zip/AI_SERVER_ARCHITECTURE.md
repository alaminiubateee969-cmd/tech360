# TECH360 LLC — Private AI Server Architecture

## Overview
The AI server is a SEPARATE private server that communicates with the Laravel cPanel application through secure server-to-server HTTPS API.

## Architecture
```
[Client Browser] → [cPanel Laravel App] → [Private AI Server]
                         ↓                          ↓
                    MySQL (source          AI Agents + Workers
                    of truth)              + Queue + Models
```

## AI Server Stack (NOT on cPanel)
- Ubuntu 22.04+ with private networking/firewall
- HTTPS (Let's Encrypt or internal CA)
- Node.js or Python (for AI workers)
- Queue (Redis or database-backed)
- AI model providers (configurable)

## Laravel → AI Server Communication
- POST to AI_API_URL/api/jobs (dispatch job)
- AI server processes and calls back to Laravel /webhook/ai

## Security Rules
1. AI_API_URL, AI_API_KEY, AI_WEBHOOK_SECRET are in Laravel .env — NEVER in Blade, HTML, JS
2. AI server webhook must verify HMAC signature
3. AI agents can RECOMMEND but NEVER:
   - Approve payment
   - Mark invoice paid
   - Approve refund
   - Release source code
   - Approve Scope of Work
   - Change financial records
4. All AI results stored in ai_jobs table with status tracking
5. Admin reviews recommendations in AI Command Center
6. Human/admin approval controls all sensitive commercial actions

## Supported AI Agents
- Lead Qualification Agent
- Scope Agent
- Project Planning Agent
- Follow-up Agent
- Communication Agent
- QA Agent
- Documentation Agent
- Support Agent
- Reporting Agent
- Sales Agent

## AI Job Types
- lead.created
- scope.requested
- scope.analysis.requested
- followup.requested
- project.task.requested
- qa.requested
- support.requested
- report.requested
