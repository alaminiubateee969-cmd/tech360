# TECH360 LLC — StackCP Production Deployment Guide

> Target: `bdtech360.com` on StackCP shared hosting
> Stack: Laravel 11.56.0 · PHP 8.3 · MySQL · Apache · No Node.js · No Docker · No Redis

---

## CRITICAL — Do Not Use PHP 8.5

The local audit environment reports PHP 8.5.5, which causes PDO::MYSQL_ATTR_SSL_CA deprecation warnings in Laravel.

**Production target: PHP 8.3**

In StackCP → **Select PHP Version**, choose **8.3** (or 8.2 if 8.3 is unavailable). Do NOT select 8.4 or 8.5 unless every dependency has been verified against it.

---

## Step 1 — Upload the ZIP

1. Log into StackCP at `https://stackcp.com`
2. File Manager → navigate to your site root:
   ```
   /home/sites/17b/7/77437ac4a4/bdtech360.com/
   ```
3. Upload `TECH360-LARAVEL-CPANEL-PRODUCTION-FINAL.zip`
4. Right-click → **Extract**
5. After extraction you should see:
   ```
   /home/sites/17b/7/77437ac4a4/bdtech360.com/
   ├── app/
   ├── bootstrap/
   ├── config/
   ├── database/
   ├── public/
   ├── resources/
   ├── routes/
   ├── storage/
   ├── vendor/
   ├── artisan
   ├── composer.json
   ├── composer.lock
   ├── .env.example
   └── DEPLOYMENT_STACKCP.md
   ```

---

## Step 2 — Set the Document Root

**This is the most critical step.**

1. StackCP → **Manage Domains** (or Sites → bdtech360.com → Manage)
2. Set **Document Root** to:
   ```
   bdtech360.com/public
   ```
3. NEVER set the document root to `bdtech360.com/` (project root). Doing so would expose `.env`, `vendor/`, `app/`, `database/`, `routes/`, `composer.json`, `composer.lock`, and `phpunit.xml` to public access.

The Laravel `public/` directory contains:
- `index.php` — the front controller
- `.htaccess` — Apache rewrite rules + security headers
- `images/` — TECH360 brand images
- `robots.txt` and `sitemap.xml`
- `storage/` (symlink, created in Step 6)

---

## Step 3 — Set PHP Version

1. StackCP → **Select PHP Version**
2. Choose **8.3** (or **8.2** if 8.3 unavailable)
3. Required extensions (verify all enabled):
   - `pdo_mysql`
   - `mbstring`
   - `openssl`
   - `tokenizer`
   - `xml`
   - `ctype`
   - `json`
   - `fileinfo`
   - `gd` (for image processing)
   - `bcmath` (for decimal math in payouts)

---

## Step 4 — Create the `.env` File

1. In StackCP File Manager, navigate to `bdtech360.com/`
2. Copy `.env.example` to `.env`
3. Right-click `.env` → **Edit**
4. Fill in real production values:

```env
APP_NAME="TECH360 LLC"
APP_ENV=production
APP_KEY=
APP_DEBUG=false
APP_URL=https://bdtech360.com

LOG_CHANNEL=stack
LOG_LEVEL=error

DB_CONNECTION=mysql
DB_HOST=sdb-l.hosting.stackcp.net
DB_PORT=3306
DB_DATABASE=alaminn_tech360
DB_USERNAME=bdtech360_alamin-313932a292
DB_PASSWORD=YOUR_ACTUAL_DB_PASSWORD

SESSION_DRIVER=database
SESSION_ENCRYPT=true
SESSION_SECURE_COOKIE=true

CACHE_STORE=database
QUEUE_CONNECTION=sync

MAIL_MAILER=smtp
MAIL_HOST=mail.bdtech360.com
MAIL_PORT=587
MAIL_USERNAME=support@bdtech360.com
MAIL_PASSWORD=YOUR_MAIL_PASSWORD
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=support@bdtech360.com
MAIL_FROM_NAME="TECH360 LLC"

AI_PROVIDER=openai
AI_MODEL=gpt-4o-mini
AI_API_KEY=sk-YOUR_OPENAI_KEY
AI_BASE_URL=https://api.openai.com/v1

PAYMENT_WEBHOOK_SECRET=GENERATE_RANDOM_64_CHAR_STRING
STRIPE_SECRET=sk_live_YOUR_STRIPE_KEY
STRIPE_WEBHOOK_SECRET=whsec_YOUR_STRIPE_WEBHOOK_SECRET
```

> ⚠️ **Never commit `.env` to Git. Never include real secrets in any ZIP that will be downloaded by anyone other than the deployment engineer.**

---

## Step 5 — Generate the APP_KEY

Use one of these methods (only once, on the server, for a new install):

**Method A — via StackCP Terminal** (preferred):
```bash
cd /home/sites/17b/7/77437ac4a4/bdtech360.com
php artisan key:generate --force
```

**Method B — via StackCP Cron Jobs** (if no Terminal):
1. Add a one-time cron job: `* * * * * cd /home/sites/17b/7/77437ac4a4/bdtech360.com && php artisan key:generate --force`
2. Wait one minute
3. Verify `.env` now has `APP_KEY=base64:...`
4. Delete the cron job

> If migrating an existing installation, **preserve the existing APP_KEY** — do not regenerate it (existing sessions and encrypted data would become unreadable).

---

## Step 6 — Create Storage Link

```bash
cd /home/sites/17b/7/77437ac4a4/bdtech360.com
php artisan storage:link
```

This creates the symlink `public/storage -> ../storage/app/public`.

Verify:
```bash
ls -la public/storage
# Should show: public/storage -> ../storage/app/public
```

---

## Step 7 — Set Permissions

```bash
cd /home/sites/17b/7/77437ac4a4/bdtech360.com
chmod -R 775 storage bootstrap/cache
chmod 644 .env
```

In StackCP File Manager, right-click `storage/` → Permissions → 775 (recursive).
Same for `bootstrap/cache/`.

---

## Step 8 — Run Migrations

```bash
cd /home/sites/17b/7/77437ac4a4/bdtech360.com
php artisan migrate --force
```

This creates all 44 database tables. Verify:
```bash
php artisan migrate:status
```

All migrations should show **Ran? = Yes**.

> ⚠️ Do NOT run `php artisan migrate:fresh` on production. It destroys all data.

---

## Step 9 — Run Seeders (First-time install only)

```bash
php artisan db:seed --force
```

This seeds:
- Admin user (`admin@tech360.io`) with a randomly-generated password (printed to console)
- 11 AI agents
- 8 AI tools
- 4 knowledge documents
- 8 services
- Application settings

> The admin password is printed to the console during seeding. Save it, then change it immediately after first login.

> Do NOT run seeders on an existing production database — they may overwrite data. Seeders use `firstOrCreate` so they are idempotent for the AI agents and tools.

---

## Step 10 — Cache Optimization

```bash
cd /home/sites/17b/7/77437ac4a4/bdtech360.com
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan event:cache
```

> ⚠️ After any change to `.env`, you MUST run `php artisan config:cache` again. Otherwise Laravel will use stale cached values.

---

## Step 11 — Configure Cron Job (Laravel Scheduler)

Laravel's task scheduler requires one cron entry running every minute. TECH360 has no scheduled tasks today, but the cron should still be set up so future scheduled tasks work automatically.

1. StackCP → **Cron Jobs**
2. Add new cron job:
   - **Minute:** `*`
   - **Hour:** `*`
   - **Day:** `*`
   - **Month:** `*`
   - **Weekday:** `*`
   - **Command:**
     ```
     /usr/local/bin/php /home/sites/17b/7/77437ac4a4/bdtech360.com/artisan schedule:run >> /dev/null 2>&1
     ```

> Replace `/usr/local/bin/php` with the actual PHP path shown in StackCP → Select PHP Version → "PHP Path" if different.

---

## Step 12 — SSL Certificate

1. StackCP → **Free SSL Certificates** (or **Let's Encrypt SSL**)
2. Select `bdtech360.com`
3. Issue certificate (free, auto-renews)
4. Verify HTTPS redirect works (the `.htaccess` includes `RewriteCond %{HTTPS} off` → `https://`)

---

## Step 13 — Verify Deployment

Visit each URL in a browser:

| URL | Expected Result |
|-----|-----------------|
| `https://bdtech360.com/` | Homepage loads, AI chat widget visible |
| `https://bdtech360.com/services` | Services page loads |
| `https://bdtech360.com/pricing` | Pricing page loads |
| `https://bdtech360.com/contact` | Contact form loads |
| `https://bdtech360.com/login` | Login page loads |
| `https://bdtech360.com/robots.txt` | Returns robots.txt text |
| `https://bdtech360.com/sitemap.xml` | Returns XML |
| `https://bdtech360.com/.env` | Returns 403 Forbidden (blocked by .htaccess) |
| `https://bdtech360.com/vendor/` | Returns 403 Forbidden |
| `https://bdtech360.com/storage/` | Returns 403 Forbidden |
| `https://bdtech360.com/artisan` | Returns 403 Forbidden |

---

## Step 14 — Login & Change Admin Password

1. Visit `https://bdtech360.com/login`
2. Login with `admin@tech360.io` + the password printed during seeding
3. Navigate to **AI Dashboard** → verify 11 AI agents appear
4. Navigate to **CRM Dashboard** → verify metrics load
5. Change the admin password immediately:
   ```bash
   php artisan tinker
   >>> User::where('email', 'admin@tech360.io')->update(['password' => bcrypt('NEW_SECURE_PASSWORD')]);
   >>> exit
   ```

---

## StackCP-Specific Notes

### No Queue Worker Required
TECH360 uses `QUEUE_CONNECTION=sync` — all jobs run inline. No Supervisor or cron-based queue worker is needed.

### No Redis Required
Session and cache use the `database` driver — no Redis dependency.

### No Node.js Required
All assets (CSS, JS, images) ship pre-built in `public/`. No `npm install` or `npm run build` is needed.

### No Docker Required
The application runs as standard PHP files served by Apache with mod_rewrite.

---

## Troubleshooting

### 500 Internal Server Error
1. Check `storage/logs/laravel.log`
2. Verify `.env` exists and has correct DB credentials
3. Run `php artisan config:clear && php artisan config:cache`
4. Verify `storage/` and `bootstrap/cache/` are writable (775)

### 404 on All Routes
1. Confirm document root is `bdtech360.com/public` (not `bdtech360.com/`)
2. Confirm `public/.htaccess` exists
3. Confirm `mod_rewrite` is enabled in StackCP

### Login Redirect Loop
1. Verify `SESSION_DRIVER=database` in `.env`
2. Confirm `sessions` table exists (`php artisan migrate`)
3. Clear cookies and retry

### "View path not found" Error
1. Run `php artisan view:clear`
2. Run `php artisan view:cache`
3. Verify `resources/views/` directory exists and contains Blade files

### "Database: sqlite" Appears in `php artisan about`
1. Run `php artisan config:clear`
2. Verify `.env` has `DB_CONNECTION=mysql`
3. Run `php artisan config:cache`
4. Run `php artisan about` again — should now show "mysql"

### AI Agent Execution Fails
1. Verify `AI_API_KEY` is set in `.env`
2. Check `storage/logs/laravel.log` for provider errors
3. AI agents in `approval` mode require admin approval — check `/admin/ai/approvals`

---

## Post-Deployment Verification Checklist

- [ ] Homepage loads at `https://bdtech360.com/`
- [ ] All public pages return 200 (services, pricing, contact, terms, refund-policy, privacy, cookie)
- [ ] Login page loads
- [ ] Admin login works
- [ ] CRM dashboard shows real metrics
- [ ] Admin can create contact/lead/deal/task
- [ ] AI dashboard shows 11 agents
- [ ] AI agent can be toggled active/inactive
- [ ] AI command executes (or creates approval in approval mode)
- [ ] Payment webhook accepts signed POST
- [ ] Source code download is blocked without verified payment
- [ ] Audit logs are being created for sensitive actions
- [ ] 404 page renders with TECH360 branding
- [ ] 403 page renders when unauthorized
- [ ] `robots.txt` accessible at `/robots.txt`
- [ ] `sitemap.xml` accessible at `/sitemap.xml`
- [ ] Cron job is running
- [ ] SSL certificate is active (HTTPS)
- [ ] `.env` is not publicly accessible (returns 403)
- [ ] `/vendor/` is not publicly accessible (returns 403)

---

## Support

- **Email:** support@tech360.io
- **Documentation:** See `TECH360-Operational-Book.pdf` (included in ZIP)
- **Architecture:** See `AI_SERVER_ARCHITECTURE.md`, `SECURITY.md`

---

© TECH360 LLC — Connect • Innovate • Grow
