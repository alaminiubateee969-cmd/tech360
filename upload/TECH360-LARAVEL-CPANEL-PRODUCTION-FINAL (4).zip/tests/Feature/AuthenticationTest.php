<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

class AuthenticationTest extends TestCase
{
    use RefreshDatabase;

    public function test_login_page_is_accessible(): void
    {
        $response = $this->get(route('login'));
        $response->assertStatus(200);
    }

    public function test_user_can_register_as_client(): void
    {
        $response = $this->post(route('register.post'), [
            'name' => 'Test Client',
            'email' => 'client@test.com',
            'password' => 'password123',
            'password_confirmation' => 'password123',
        ]);
        $response->assertRedirect(route('client.dashboard'));
        $this->assertDatabaseHas('users', ['email' => 'client@test.com', 'role' => 'client']);
    }

    public function test_admin_can_login(): void
    {
        $admin = User::factory()->create([
            'email' => 'admin@test.com',
            'password' => bcrypt('password123'),
            'role' => 'admin',
        ]);

        $response = $this->post(route('login.post'), [
            'email' => 'admin@test.com',
            'password' => 'password123',
        ]);
        $response->assertRedirect(route('admin.dashboard'));
        $this->assertAuthenticatedAs($admin);
    }

    public function test_invalid_credentials_rejected(): void
    {
        User::factory()->create([
            'email' => 'user@test.com',
            'password' => bcrypt('correct-password'),
            'role' => 'client',
        ]);

        $response = $this->post(route('login.post'), [
            'email' => 'user@test.com',
            'password' => 'wrong-password',
        ]);
        $response->assertSessionHasErrors('email');
        $this->assertGuest();
    }

    public function test_user_can_logout(): void
    {
        $user = User::factory()->create(['role' => 'client']);
        $this->actingAs($user);

        $response = $this->post(route('logout'));
        $response->assertRedirect(route('home'));
        $this->assertGuest();
    }

    public function test_login_is_rate_limited(): void
    {
        // 5 attempts per minute — 6th should be blocked
        for ($i = 0; $i < 5; $i++) {
            $this->post(route('login.post'), [
                'email' => 'nonexistent@test.com',
                'password' => 'wrong',
            ]);
        }
        $response = $this->post(route('login.post'), [
            'email' => 'nonexistent@test.com',
            'password' => 'wrong',
        ]);
        $response->assertStatus(429);
    }
}
