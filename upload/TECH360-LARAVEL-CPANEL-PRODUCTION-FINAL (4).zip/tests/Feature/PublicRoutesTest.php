<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;

class PublicRoutesTest extends TestCase
{
    /**
     * Verify every public route returns HTTP 200.
     */
    public function test_homepage_returns_200(): void
    {
        $response = $this->get(route('home'));
        $response->assertStatus(200);
    }

    public function test_about_returns_200(): void
    {
        $response = $this->get(route('about'));
        $response->assertStatus(200);
    }

    public function test_services_returns_200(): void
    {
        $response = $this->get(route('services'));
        $response->assertStatus(200);
    }

    public function test_pricing_returns_200(): void
    {
        $response = $this->get(route('pricing'));
        $response->assertStatus(200);
    }

    public function test_contact_returns_200(): void
    {
        $response = $this->get(route('contact'));
        $response->assertStatus(200);
    }

    public function test_portfolio_returns_200(): void
    {
        $response = $this->get(route('portfolio'));
        $response->assertStatus(200);
    }

    public function test_blog_returns_200(): void
    {
        $response = $this->get(route('blog'));
        $response->assertStatus(200);
    }

    public function test_terms_returns_200(): void
    {
        $response = $this->get(route('terms'));
        $response->assertStatus(200);
    }

    public function test_refund_policy_returns_200(): void
    {
        $response = $this->get(route('refund-policy'));
        $response->assertStatus(200);
    }

    public function test_privacy_policy_returns_200(): void
    {
        $response = $this->get(route('privacy-policy'));
        $response->assertStatus(200);
    }

    public function test_cookie_policy_returns_200(): void
    {
        $response = $this->get(route('cookie-policy'));
        $response->assertStatus(200);
    }

    public function test_case_studies_returns_200(): void
    {
        $response = $this->get(route('case-studies'));
        $response->assertStatus(200);
    }

    public function test_industries_returns_200(): void
    {
        $response = $this->get(route('industries'));
        $response->assertStatus(200);
    }

    public function test_login_returns_200(): void
    {
        $response = $this->get(route('login'));
        $response->assertStatus(200);
    }

    public function test_register_returns_200(): void
    {
        $response = $this->get(route('register'));
        $response->assertStatus(200);
    }

    public function test_unknown_route_returns_404(): void
    {
        $response = $this->get('/this-route-does-not-exist');
        $response->assertStatus(404);
    }

    public function test_robots_txt_returns_200(): void
    {
        $response = $this->get('/robots.txt');
        $response->assertStatus(200);
    }

    public function test_sitemap_xml_returns_200(): void
    {
        $response = $this->get('/sitemap.xml');
        $response->assertStatus(200);
    }
}
