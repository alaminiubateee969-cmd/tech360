<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\Client;
use App\Models\Project;
use App\Models\Payment;
use App\Models\ScopeOfWork;
use App\Models\Delivery;
use App\Models\AuditLog;
use Illuminate\Foundation\Testing\RefreshDatabase;

class CommercialWorkflowTest extends TestCase
{
    use RefreshDatabase;

    public function test_payment_cannot_be_verified_without_approved_scope(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $client = Client::factory()->create();
        $project = Project::factory()->create(['client_id' => $client->id]);
        $payment = Payment::factory()->create([
            'project_id' => $project->id,
            'client_id' => $client->id,
            'amount' => 5000,
            'status' => 'pending',
        ]);

        $response = $this->actingAs($admin)->post(route('admin.payment.verify', $payment->id));
        $response->assertSessionHasErrors();
    }

    public function test_payment_can_be_verified_after_scope_approval(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $client = Client::factory()->create();
        $project = Project::factory()->create(['client_id' => $client->id]);
        $scope = ScopeOfWork::factory()->create([
            'project_id' => $project->id,
            'status' => 'approved',
            'payment_amount' => 5000,
        ]);
        $payment = Payment::factory()->create([
            'project_id' => $project->id,
            'client_id' => $client->id,
            'amount' => 5000,
            'status' => 'pending',
        ]);

        $response = $this->actingAs($admin)->post(route('admin.payment.verify', $payment->id));
        $response->assertSessionHas('success');
        $payment->refresh();
        $this->assertEquals('paid', $payment->status);
        $this->assertEquals('PAYMENT_PAID', $project->refresh()->commercial_state);
    }

    public function test_already_verified_payment_cannot_be_reverified(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $client = Client::factory()->create();
        $project = Project::factory()->create(['client_id' => $client->id]);
        $scope = ScopeOfWork::factory()->create(['project_id' => $project->id, 'status' => 'approved']);
        $payment = Payment::factory()->create([
            'project_id' => $project->id, 'client_id' => $client->id, 'status' => 'paid',
        ]);

        $response = $this->actingAs($admin)->post(route('admin.payment.verify', $payment->id));
        $response->assertSessionHasErrors();
    }

    public function test_payment_verification_creates_audit_log(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $client = Client::factory()->create();
        $project = Project::factory()->create(['client_id' => $client->id]);
        ScopeOfWork::factory()->create(['project_id' => $project->id, 'status' => 'approved']);
        $payment = Payment::factory()->create([
            'project_id' => $project->id, 'client_id' => $client->id, 'status' => 'pending',
        ]);

        $this->actingAs($admin)->post(route('admin.payment.verify', $payment->id));
        $this->assertDatabaseHas('audit_logs', [
            'action' => 'payment_verified',
            'payment_id' => $payment->id,
        ]);
    }

    public function test_handover_cannot_release_without_verified_payment(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $client = Client::factory()->create();
        $project = Project::factory()->create(['client_id' => $client->id]);
        // No payment record at all

        $response = $this->actingAs($admin)->post(route('admin.handover.release', $project->id));
        $response->assertSessionHasErrors();
    }

    public function test_source_code_download_blocked_before_all_gates_pass(): void
    {
        $user = User::factory()->create(['role' => 'client']);
        $client = Client::factory()->create(['user_id' => $user->id]);
        $project = Project::factory()->create(['client_id' => $client->id]);
        // No payment, no delivery, no QA — should be blocked
        $response = $this->actingAs($user)->get(route('client.download', $project));
        $response->assertStatus(403);
    }
}
