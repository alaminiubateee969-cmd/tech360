<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\AiAgent;
use App\Models\AiAgentTool;
use App\Models\AiApproval;
use App\Models\AiKnowledgeDocument;
use App\Models\AiAgentExecution;
use Illuminate\Foundation\Testing\RefreshDatabase;

class AiAgentTest extends TestCase
{
    use RefreshDatabase;

    public function test_ai_dashboard_loads_with_real_metrics(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        AiAgent::factory()->count(3)->create(['status' => 'active']);
        AiAgentTool::factory()->count(5)->create(['enabled' => true]);

        $response = $this->actingAs($admin)->get(route('admin.ai.dashboard'));
        $response->assertStatus(200);
        $response->assertSee('3'); // active agents
    }

    public function test_ai_agents_index_loads(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        AiAgent::factory()->count(5)->create();

        $response = $this->actingAs($admin)->get(route('admin.ai.agents'));
        $response->assertStatus(200);
    }

    public function test_ai_agent_detail_page_loads(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $agent = AiAgent::factory()->create();

        $response = $this->actingAs($admin)->get(route('admin.ai.agents.show', $agent));
        $response->assertStatus(200);
        $response->assertSee($agent->name);
    }

    public function test_admin_can_create_ai_agent(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $response = $this->actingAs($admin)->post(route('admin.ai.agents.store'), [
            'name' => 'Test Agent',
            'description' => 'Test description',
            'instructions' => 'You are a test agent.',
            'provider' => 'openai',
            'model' => 'gpt-4o-mini',
            'mode' => 'approval',
        ]);
        $response->assertSessionHas('success');
        $this->assertDatabaseHas('ai_agents', ['name' => 'Test Agent']);
    }

    public function test_admin_can_toggle_agent_status(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $agent = AiAgent::factory()->create(['status' => 'active']);

        $response = $this->actingAs($admin)->post(route('admin.ai.agents.toggle', $agent));
        $agent->refresh();
        $this->assertEquals('inactive', $agent->status);
    }

    public function test_ai_approval_center_loads(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $response = $this->actingAs($admin)->get(route('admin.ai.approvals'));
        $response->assertStatus(200);
    }

    public function test_ai_knowledge_base_loads(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        AiKnowledgeDocument::factory()->count(3)->create();

        $response = $this->actingAs($admin)->get(route('admin.ai.knowledge'));
        $response->assertStatus(200);
    }

    public function test_ai_workflows_page_loads(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $response = $this->actingAs($admin)->get(route('admin.ai.workflows'));
        $response->assertStatus(200);
    }

    public function test_ai_logs_page_loads(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $response = $this->actingAs($admin)->get(route('admin.ai.logs'));
        $response->assertStatus(200);
    }

    public function test_ai_command_requires_input(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $response = $this->actingAs($admin)->post(route('admin.ai.command'), []);
        $response->assertSessionHasErrors('command');
    }

    public function test_ai_command_routes_to_correct_agent(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        AiAgent::factory()->create(['slug' => 'lead-management-agent', 'mode' => 'approval']);

        $response = $this->actingAs($admin)->post(route('admin.ai.command'), [
            'command' => 'find high priority leads',
        ]);
        $response->assertSessionHas('success');
        $this->assertDatabaseHas('ai_agent_executions', ['input' => 'find high priority leads']);
    }

    public function test_approval_mode_creates_pending_approval(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $agent = AiAgent::factory()->create(['mode' => 'approval', 'status' => 'active']);

        $response = $this->actingAs($admin)->post(route('admin.ai.agents.execute', $agent), [
            'input' => 'test prompt',
        ]);
        $this->assertDatabaseHas('ai_approvals', [
            'ai_agent_id' => $agent->id,
            'status' => 'pending',
        ]);
    }

    public function test_admin_can_approve_pending_approval(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $agent = AiAgent::factory()->create(['mode' => 'approval']);
        $execution = AiAgentExecution::factory()->create([
            'ai_agent_id' => $agent->id, 'status' => 'awaiting_approval',
        ]);
        $approval = AiApproval::factory()->create([
            'ai_agent_id' => $agent->id,
            'ai_agent_execution_id' => $execution->id,
            'status' => 'pending',
        ]);

        $response = $this->actingAs($admin)->post(route('admin.ai.approvals.approve', $approval));
        $approval->refresh();
        $this->assertEquals('approved', $approval->status);
    }

    public function test_admin_can_reject_pending_approval(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $agent = AiAgent::factory()->create();
        $approval = AiApproval::factory()->create([
            'ai_agent_id' => $agent->id,
            'status' => 'pending',
        ]);

        $response = $this->actingAs($admin)->post(route('admin.ai.approvals.reject', $approval), [
            'review_note' => 'Not relevant',
        ]);
        $approval->refresh();
        $this->assertEquals('rejected', $approval->status);
    }
}
