<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

class AuthorizationTest extends TestCase
{
    use RefreshDatabase;

    public function test_admin_routes_redirect_unauthenticated_to_login(): void
    {
        $response = $this->get(route('admin.dashboard'));
        $response->assertRedirect(route('login'));
    }

    public function test_admin_routes_block_client_role(): void
    {
        $client = User::factory()->create(['role' => 'client']);
        $response = $this->actingAs($client)->get(route('admin.dashboard'));
        $response->assertStatus(403);
    }

    public function test_crm_routes_block_client_role(): void
    {
        $client = User::factory()->create(['role' => 'client']);
        $response = $this->actingAs($client)->get(route('crm.dashboard'));
        $response->assertStatus(403);
    }

    public function test_admin_can_access_admin_dashboard(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $response = $this->actingAs($admin)->get(route('admin.dashboard'));
        $response->assertStatus(200);
    }

    public function test_admin_can_access_crm_dashboard(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $response = $this->actingAs($admin)->get(route('crm.dashboard'));
        $response->assertStatus(200);
    }

    public function test_staff_can_access_crm_dashboard(): void
    {
        $staff = User::factory()->create(['role' => 'staff']);
        $response = $this->actingAs($staff)->get(route('crm.dashboard'));
        $response->assertStatus(200);
    }

    public function test_staff_can_access_admin_dashboard(): void
    {
        $staff = User::factory()->create(['role' => 'staff']);
        $response = $this->actingAs($staff)->get(route('admin.dashboard'));
        $response->assertStatus(200);
    }

    public function test_client_routes_block_unauthenticated(): void
    {
        $response = $this->get(route('client.dashboard'));
        $response->assertRedirect(route('login'));
    }

    public function test_ai_agent_routes_require_admin(): void
    {
        $client = User::factory()->create(['role' => 'client']);
        $response = $this->actingAs($client)->get(route('admin.ai.agents'));
        $response->assertStatus(403);
    }

    public function test_ai_command_route_requires_admin(): void
    {
        $client = User::factory()->create(['role' => 'client']);
        $response = $this->actingAs($client)->post(route('admin.ai.command'), ['command' => 'test']);
        $response->assertStatus(403);
    }

    public function test_admin_can_view_ai_dashboard(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $response = $this->actingAs($admin)->get(route('admin.ai.dashboard'));
        $response->assertStatus(200);
    }
}
