<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\Payment;
use App\Models\Project;
use App\Models\Client;
use App\Models\ScopeOfWork;
use Illuminate\Foundation\Testing\RefreshDatabase;

class WebhookSecurityTest extends TestCase
{
    use RefreshDatabase;

    public function test_payment_webhook_rejects_missing_signature_when_secret_set(): void
    {
        config(['app.key' => 'base64:2fl+KtvkqMf7pW8sJ5k3yN1u3o1uJ5pM6dZ8v5k1w1c=']);
        putenv('PAYMENT_WEBHOOK_SECRET=test-secret-key');

        $response = $this->postJson('/webhook/payment', [
            'transaction_id' => 'TXN-123',
            'amount' => 100,
        ]);

        $response->assertStatus(401);
    }

    public function test_payment_webhook_validates_amount(): void
    {
        // Disable HMAC for this test (no secret)
        putenv('PAYMENT_WEBHOOK_SECRET=');

        $client = Client::factory()->create();
        $project = Project::factory()->create(['client_id' => $client->id]);
        ScopeOfWork::factory()->create(['project_id' => $project->id, 'status' => 'approved']);
        $payment = Payment::factory()->create([
            'project_id' => $project->id,
            'client_id' => $client->id,
            'amount' => 5000,
            'status' => 'pending',
        ]);

        $response = $this->postJson('/webhook/payment', [
            'transaction_id' => 'TXN-MISMATCH-001',
            'invoice_id' => $payment->id,
            'amount' => 100, // wrong amount
        ]);

        $response->assertStatus(400);
    }

    public function test_payment_webhook_idempotent(): void
    {
        putenv('PAYMENT_WEBHOOK_SECRET=');

        $client = Client::factory()->create();
        $project = Project::factory()->create(['client_id' => $client->id]);
        ScopeOfWork::factory()->create(['project_id' => $project->id, 'status' => 'approved']);
        $payment = Payment::factory()->create([
            'project_id' => $project->id,
            'client_id' => $client->id,
            'amount' => 5000,
            'status' => 'paid',
            'provider_transaction_id' => 'TXN-DUP-001',
        ]);

        // Second webhook call should be processed but marked as already_processed
        $response = $this->postJson('/webhook/payment', [
            'transaction_id' => 'TXN-DUP-001',
            'invoice_id' => $payment->id,
            'amount' => 5000,
        ]);

        $response->assertStatus(200);
        $response->assertJson(['status' => 'already_processed']);
    }

    public function test_payment_webhook_requires_scope_approval(): void
    {
        putenv('PAYMENT_WEBHOOK_SECRET=');

        $client = Client::factory()->create();
        $project = Project::factory()->create(['client_id' => $client->id]);
        // No scope approved
        $payment = Payment::factory()->create([
            'project_id' => $project->id,
            'client_id' => $client->id,
            'amount' => 5000,
            'status' => 'pending',
        ]);

        $response = $this->postJson('/webhook/payment', [
            'transaction_id' => 'TXN-NOSCOPE-001',
            'invoice_id' => $payment->id,
            'amount' => 5000,
        ]);

        $response->assertStatus(403);
    }
}
