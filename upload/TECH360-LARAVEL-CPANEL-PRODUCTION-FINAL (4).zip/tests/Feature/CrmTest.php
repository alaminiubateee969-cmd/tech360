<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\Contact;
use App\Models\LeadCrm;
use App\Models\Deal;
use App\Models\CrmTask;
use Illuminate\Foundation\Testing\RefreshDatabase;

class CrmTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;

    protected function setUp(): void
    {
        parent::setUp();
        $this->admin = User::factory()->create(['role' => 'admin']);
    }

    public function test_crm_dashboard_shows_real_database_metrics(): void
    {
        Contact::factory()->count(3)->create();
        LeadCrm::factory()->count(2)->create(['status' => 'new']);
        Deal::factory()->create(['value' => 5000, 'stage' => 'qualified']);

        $response = $this->actingAs($this->admin)->get(route('crm.dashboard'));
        $response->assertStatus(200);
        $response->assertSee('3'); // total contacts
        $response->assertSee('$5,000'); // pipeline value
    }

    public function test_admin_can_create_contact(): void
    {
        $response = $this->actingAs($this->admin)->post(route('crm.contacts.store'), [
            'first_name' => 'John',
            'last_name' => 'Doe',
            'email' => 'john@example.com',
            'phone' => '+1-555-0100',
            'source' => 'manual',
            'status' => 'lead',
        ]);

        $response->assertRedirect();
        $this->assertDatabaseHas('contacts', ['email' => 'john@example.com']);
    }

    public function test_contact_id_is_auto_generated(): void
    {
        $contact = Contact::factory()->create();
        $this->assertStringStartsWith('TECH-CON-', $contact->contact_id);
    }

    public function test_contacts_search_works(): void
    {
        Contact::factory()->create(['first_name' => 'Alice', 'email' => 'alice@x.com']);
        Contact::factory()->create(['first_name' => 'Bob', 'email' => 'bob@x.com']);

        $response = $this->actingAs($this->admin)->get(route('crm.contacts', ['search' => 'Alice']));
        $response->assertStatus(200);
        $response->assertSee('Alice');
        $response->assertDontSee('Bob');
    }

    public function test_contacts_pagination_works(): void
    {
        Contact::factory()->count(25)->create();
        $response = $this->actingAs($this->admin)->get(route('crm.contacts'));
        $response->assertStatus(200);
        // Default pagination is 20 per page
        $response->assertSee('Next');
    }

    public function test_admin_can_create_lead(): void
    {
        $contact = Contact::factory()->create();
        $response = $this->actingAs($this->admin)->post(route('crm.leads.store'), [
            'contact_id' => $contact->id,
            'service_interest' => 'Website Development',
            'source' => 'manual',
            'status' => 'new',
        ]);
        $response->assertRedirect();
        $this->assertDatabaseHas('leads_crm', ['contact_id' => $contact->id]);
    }

    public function test_admin_can_create_deal(): void
    {
        $contact = Contact::factory()->create();
        $response = $this->actingAs($this->admin)->post(route('crm.deals.store'), [
            'title' => 'Custom CRM Project',
            'contact_id' => $contact->id,
            'value' => 12000,
            'probability' => 75,
            'stage' => 'proposal',
        ]);
        $response->assertRedirect();
        $this->assertDatabaseHas('deals', ['title' => 'Custom CRM Project', 'value' => 12000]);
    }

    public function test_admin_can_create_task(): void
    {
        $response = $this->actingAs($this->admin)->post(route('crm.tasks.store'), [
            'title' => 'Follow up with lead',
            'priority' => 'high',
        ]);
        $response->assertRedirect();
        $this->assertDatabaseHas('crm_tasks', ['title' => 'Follow up with lead']);
    }

    public function test_contact_detail_page_shows_communications(): void
    {
        $contact = Contact::factory()->create();
        $response = $this->actingAs($this->admin)->get(route('crm.contacts.show', $contact->id));
        $response->assertStatus(200);
        $response->assertSee($contact->first_name);
    }
}
