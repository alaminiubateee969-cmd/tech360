<?php
namespace App\Services;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Models\AiJob;
use App\Models\AuditLog;

class AiService
{
    private ?string $apiUrl;
    private ?string $apiKey;

    public function __construct()
    {
        $this->apiUrl = env('AI_API_URL');
        $this->apiKey = env('AI_API_KEY');
    }

    /**
     * Send a job to the AI server.
     * AI can RECOMMEND but never make commercial decisions.
     * Returns job_id for tracking.
     */
    public function dispatch(string $jobType, array $data, ?int $clientId = null, ?int $projectId = null): ?string
    {
        // Create job record
        $count = AiJob::count();
        $jobId = 'JOB-2026-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT);

        $job = AiJob::create([
            'job_id' => $jobId,
            'job_type' => $jobType,
            'client_id' => $clientId,
            'project_id' => $projectId,
            'agent_name' => $this->getAgentForJobType($jobType),
            'status' => 'queued',
            'input' => json_encode($data),
        ]);

        // If AI server is configured, send the job
        if ($this->apiUrl && $this->apiKey) {
            try {
                $response = Http::withHeaders([
                    'Authorization' => 'Bearer ' . $this->apiKey,
                    'Content-Type' => 'application/json',
                ])->post($this->apiUrl . '/api/jobs', [
                    'job_id' => $jobId,
                    'job_type' => $jobType,
                    'data' => $data,
                ]);

                if ($response->successful()) {
                    $job->update(['status' => 'running', 'started_at' => now()]);
                } else {
                    $job->update(['status' => 'failed', 'error' => 'AI server returned: ' . $response->status()]);
                    Log::error('AI job dispatch failed', ['job_id' => $jobId, 'status' => $response->status()]);
                }
            } catch (\Exception $e) {
                $job->update(['status' => 'failed', 'error' => $e->getMessage()]);
                Log::error('AI server connection failed', ['job_id' => $jobId, 'error' => $e->getMessage()]);
            }
        } else {
            // AI server not configured — mark as pending
            $job->update(['status' => 'queued']);
        }

        return $jobId;
    }

    /**
     * Receive AI job result via webhook from AI server.
     * AI results are stored but do NOT auto-execute commercial actions.
     */
    public function receiveResult(string $jobId, string $result, ?string $error = null): bool
    {
        $job = AiJob::where('job_id', $jobId)->first();
        if (!$job) return false;

        // Prevent double-processing
        if ($job->status === 'completed') return false;

        $job->update([
            'status' => $error ? 'failed' : 'completed',
            'result' => $result,
            'error' => $error,
            'completed_at' => now(),
        ]);

        AuditLog::create([
            'client_id' => $job->client_id,
            'project_id' => $job->project_id,
            'action' => 'ai_job_' . ($error ? 'failed' : 'completed'),
            'actor_type' => 'system',
            'details' => json_encode(['job_id' => $jobId, 'job_type' => $job->job_type]),
        ]);

        return true;
    }

    /**
     * Get agent name for a job type.
     * AI agents can RECOMMEND but never:
     * - approve payment
     * - mark invoice paid
     * - approve refund
     * - release source code
     * - approve Scope of Work
     * - change financial records
     */
    private function getAgentForJobType(string $jobType): string
    {
        return match($jobType) {
            'lead.created' => 'Lead Qualification Agent',
            'scope.requested' => 'Scope Agent',
            'scope.analysis.requested' => 'Scope Agent',
            'followup.requested' => 'Follow-up Agent',
            'project.task.requested' => 'Project Planning Agent',
            'qa.requested' => 'QA Agent',
            'support.requested' => 'Support Agent',
            'report.requested' => 'Reporting Agent',
            'communication.requested' => 'Communication Agent',
            default => 'General Agent',
        };
    }

    /**
     * Get AI job recommendations for admin review.
     * Recommendations are NEVER auto-executed.
     */
    public function getRecommendations(?int $projectId = null): array
    {
        $query = AiJob::where('status', 'completed')->whereNotNull('result');
        if ($projectId) $query->where('project_id', $projectId);
        return $query->latest()->limit(20)->get()->toArray();
    }
}
