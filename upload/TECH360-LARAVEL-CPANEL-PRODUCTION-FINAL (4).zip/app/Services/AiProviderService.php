<?php
namespace App\Services;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class AiProviderService {
    private ?string $provider;
    private ?string $model;
    private ?string $apiKey;
    private ?string $baseUrl;

    public function __construct() {
        $this->provider = env('AI_PROVIDER', 'openai');
        $this->model = env('AI_MODEL', 'gpt-4o-mini');
        $this->apiKey = env('AI_API_KEY');
        $this->baseUrl = env('AI_BASE_URL', 'https://api.openai.com/v1');
    }

    public function isAvailable(): bool {
        return !empty($this->apiKey) || $this->provider === 'ollama';
    }

    public function chat(array $messages, ?string $model = null, array $tools = []): array {
        if (!$this->isAvailable()) {
            return [
                'success' => false,
                'error' => 'AI provider not configured',
                'fallback' => true,
            ];
        }

        $useModel = $model ?? $this->model;
        $url = $this->baseUrl . '/chat/completions';

        try {
            $headers = ['Content-Type' => 'application/json'];
            if ($this->provider !== 'ollama' && $this->apiKey) {
                $headers['Authorization'] = 'Bearer ' . $this->apiKey;
            }

            $payload = [
                'model' => $useModel,
                'messages' => $messages,
                'temperature' => 0.4,
            ];

            if (!empty($tools)) {
                $payload['tools'] = $tools;
                $payload['tool_choice'] = 'auto';
            }

            $response = Http::withHeaders($headers)->timeout(120)->post($url, $payload);

            if ($response->successful()) {
                $data = $response->json();
                return [
                    'success' => true,
                    'content' => $data['choices'][0]['message']['content'] ?? '',
                    'tool_calls' => $data['choices'][0]['message']['tool_calls'] ?? [],
                    'tokens_input' => $data['usage']['prompt_tokens'] ?? 0,
                    'tokens_output' => $data['usage']['completion_tokens'] ?? 0,
                    'model' => $useModel,
                    'provider' => $this->provider,
                ];
            }

            return [
                'success' => false,
                'error' => 'API returned ' . $response->status() . ': ' . $response->body(),
            ];
        } catch (\Exception $e) {
            Log::error('AI Provider error: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }
}
