<?php
namespace App\Services;
use App\Models\AiAgent;
use App\Models\AiAgentExecution;
use App\Models\AiAgentMessage;
use App\Models\AiAgentLog;
use App\Models\AiApproval;
use App\Models\Contact;
use App\Models\LeadCrm;
use App\Models\Deal;
use App\Models\Activity;
use App\Models\Communication;
use App\Models\CrmTask;

class AiExecutionEngine {
    private AiProviderService $provider;

    public function __construct(AiProviderService $provider) {
        $this->provider = $provider;
    }

    public function execute(AiAgent $agent, string $input, ?int $userId = null): AiAgentExecution {
        $count = AiAgentExecution::count();
        $executionId = 'EXEC-' . date('Y') . '-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT);

        $execution = AiAgentExecution::create([
            'execution_id' => $executionId,
            'ai_agent_id' => $agent->id,
            'user_id' => $userId,
            'input' => $input,
            'status' => 'running',
            'provider' => $agent->provider,
            'model' => $agent->model,
            'started_at' => now(),
        ]);

        // Build messages
        $messages = [
            ['role' => 'system', 'content' => $agent->instructions ?? 'You are ' . $agent->name . '. ' . ($agent->description ?? '')],
            ['role' => 'user', 'content' => $input],
        ];

        // Add context from memory
        $memories = $agent->memories()->where('type', 'context')->latest()->limit(5)->get();
        foreach ($memories as $mem) {
            $messages[] = ['role' => 'system', 'content' => 'Context: ' . $mem->value];
        }

        // Add knowledge
        $knowledge = \App\Models\AiKnowledgeDocument::where('is_active', true)->limit(3)->get();
        foreach ($knowledge as $doc) {
            $messages[] = ['role' => 'system', 'content' => 'Knowledge: ' . $doc->title . ' - ' . substr($doc->content, 0, 500)];
        }

        // Save messages
        foreach ($messages as $msg) {
            AiAgentMessage::create([
                'ai_agent_execution_id' => $execution->id,
                'role' => $msg['role'],
                'content' => $msg['content'],
            ]);
        }

        // Check if approval is required
        if ($agent->mode === 'approval' || $agent->mode === 'manual') {
            $approvalCount = AiApproval::count();
            $approval = AiApproval::create([
                'approval_id' => 'APR-' . date('Y') . '-' . str_pad($approvalCount + 1, 6, '0', STR_PAD_LEFT),
                'ai_agent_id' => $agent->id,
                'ai_agent_execution_id' => $execution->id,
                'user_id' => $userId,
                'action' => 'execute_agent',
                'reason' => 'Agent mode requires approval',
                'generated_content' => $input,
                'risk_level' => 'medium',
                'status' => 'pending',
            ]);

            $execution->update(['status' => 'awaiting_approval']);

            AiAgentLog::create([
                'ai_agent_id' => $agent->id,
                'ai_agent_execution_id' => $execution->id,
                'level' => 'info',
                'action' => 'approval_required',
                'message' => 'Execution awaiting approval: ' . $approval->approval_id,
                'user_id' => $userId,
            ]);

            return $execution;
        }

        // Autonomous mode — execute directly
        return $this->runExecution($execution, $agent, $messages);
    }

    private function runExecution(AiAgentExecution $execution, AiAgent $agent, array $messages): AiAgentExecution {
        $result = $this->provider->chat($messages, $agent->model);

        if (!$result['success']) {
            $execution->update([
                'status' => 'failed',
                'error' => $result['error'] ?? 'Unknown error',
                'completed_at' => now(),
            ]);

            AiAgentLog::create([
                'ai_agent_id' => $agent->id,
                'ai_agent_execution_id' => $execution->id,
                'level' => 'error',
                'action' => 'execution_failed',
                'message' => $result['error'] ?? 'Unknown error',
            ]);

            return $execution;
        }

        $execution->update([
            'status' => 'completed',
            'output' => $result['content'],
            'tokens_input' => $result['tokens_input'] ?? 0,
            'tokens_output' => $result['tokens_output'] ?? 0,
            'completed_at' => now(),
        ]);

        AiAgentMessage::create([
            'ai_agent_execution_id' => $execution->id,
            'role' => 'assistant',
            'content' => $result['content'],
        ]);

        AiAgentLog::create([
            'ai_agent_id' => $agent->id,
            'ai_agent_execution_id' => $execution->id,
            'level' => 'info',
            'action' => 'execution_completed',
            'message' => 'Execution completed successfully. Tokens: ' . ($result['tokens_input'] ?? 0) . ' in / ' . ($result['tokens_output'] ?? 0) . ' out',
        ]);

        return $execution;
    }

    public function approveAndExecute(AiApproval $approval): AiAgentExecution {
        $execution = $approval->execution;
        $agent = $approval->agent;

        $messages = $execution->messages()->orderBy('id')->get()->map(function($m) {
            return ['role' => $m->role, 'content' => $m->content];
        })->toArray();

        $approval->update([
            'status' => 'approved',
            'reviewed_at' => now(),
        ]);

        $execution->update(['status' => 'running']);

        $result = $this->runExecution($execution, $agent, $messages);

        $approval->update(['execution_result' => $execution->output]);

        return $execution;
    }

    // AI Tools — all controlled, validated, audited
    public function crmSearchLeads(array $params): array {
        $query = LeadCrm::with('contact');
        if (!empty($params['status'])) $query->where('status', $params['status']);
        if (!empty($params['source'])) $query->where('source', $params['source']);
        $leads = $query->latest()->limit(20)->get();
        return ['success' => true, 'data' => $leads->toArray(), 'count' => $leads->count()];
    }

    public function crmCreateLead(array $params): array {
        $count = LeadCrm::count();
        $lead = LeadCrm::create([
            'lead_id' => 'TECH-LEAD-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT),
            'contact_id' => $params['contact_id'],
            'source' => $params['source'] ?? 'ai_agent',
            'status' => 'new',
            'service_interest' => $params['service_interest'] ?? null,
        ]);
        return ['success' => true, 'data' => $lead->toArray()];
    }

    public function crmSearchContacts(array $params): array {
        $query = Contact::query();
        if (!empty($params['search'])) {
            $search = $params['search'];
            $query->where(function($q) use ($search) {
                $q->where('first_name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%");
            });
        }
        $contacts = $query->latest()->limit(20)->get();
        return ['success' => true, 'data' => $contacts->toArray(), 'count' => $contacts->count()];
    }

    public function crmCreateActivity(array $params): array {
        $activity = Activity::create([
            'entity_type' => $params['entity_type'] ?? 'contact',
            'entity_id' => $params['entity_id'] ?? 0,
            'contact_id' => $params['contact_id'] ?? null,
            'type' => $params['type'] ?? 'ai_generated',
            'description' => $params['description'],
            'user_id' => null,
        ]);
        return ['success' => true, 'data' => $activity->toArray()];
    }

    public function crmCreateTask(array $params): array {
        $task = CrmTask::create([
            'title' => $params['title'],
            'description' => $params['description'] ?? null,
            'contact_id' => $params['contact_id'] ?? null,
            'priority' => $params['priority'] ?? 'medium',
            'status' => 'pending',
        ]);
        return ['success' => true, 'data' => $task->toArray()];
    }

    public function getPipelineStats(): array {
        return [
            'total_leads' => LeadCrm::count(),
            'new_leads' => LeadCrm::where('status', 'new')->count(),
            'qualified' => LeadCrm::where('status', 'qualified')->count(),
            'open_deals' => Deal::whereNotIn('stage', ['won', 'lost'])->count(),
            'won_deals' => Deal::where('stage', 'won')->count(),
            'pipeline_value' => Deal::whereNotIn('stage', ['won', 'lost'])->sum('value'),
        ];
    }
}
