<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Dispute;
use App\Models\AuditLog;

class DisputeController extends Controller {
    public function index(Request $request) {
        $query = Dispute::with('payment', 'project', 'client');
        if ($request->filled('status')) $query->where('status', $request->status);
        $disputes = $query->latest()->paginate(20);
        return view('admin.disputes.index', compact('disputes'));
    }

    public function create() {
        $projects = \App\Models\Project::orderBy('name')->get();
        $clients = \App\Models\Client::orderBy('name')->get();
        $payments = \App\Models\Payment::orderBy('id', 'desc')->limit(50)->get();
        return view('admin.disputes.create', compact('projects', 'clients', 'payments'));
    }

    public function show(Dispute $dispute) {
        $dispute->load('payment', 'project', 'client', 'compiler', 'resolver');
        return view('admin.disputes.show', compact('dispute'));
    }

    public function store(Request $request) {
        $validated = $request->validate([
            'payment_id' => 'nullable|exists:payments,id',
            'project_id' => 'nullable|exists:projects,id',
            'client_id' => 'nullable|exists:clients,id',
            'case_number' => 'nullable|string|max:100',
            'source' => 'required|in:stripe,paypal,bank_chargeback,client_dispute',
            'reason_code' => 'nullable|string|max:100',
            'reason' => 'nullable|string|max:5000',
            'disputed_amount' => 'required|numeric|min:0',
        ]);
        $count = Dispute::count();
        $validated['dispute_id'] = 'DSP-' . date('Y') . '-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT);
        $validated['status'] = 'open';
        $validated['respond_by'] = now()->addDays(7); // 7-day response window typical

        $dispute = Dispute::create($validated);

        AuditLog::create([
            'client_id' => $validated['client_id'] ?? null,
            'project_id' => $validated['project_id'] ?? null,
            'action' => 'dispute_opened',
            'actor_type' => 'admin',
            'actor_id' => auth()->id(),
            'details' => json_encode([
                'dispute_id' => $dispute->dispute_id, 'case_number' => $dispute->case_number,
                'disputed_amount' => $dispute->disputed_amount,
            ]),
            'ip_address' => $request->ip(),
        ]);

        return redirect()->route('admin.disputes.show', $dispute)->with('success', 'Dispute opened: ' . $dispute->dispute_id);
    }

    /**
     * AUTO-COMPILE evidence package for the dispute.
     * Pulls from evidence_vault, payments, scope_of_works, deliveries, audit_logs.
     */
    public function compileEvidence(Dispute $dispute) {
        $items = $dispute->compileEvidencePackage();

        AuditLog::create([
            'client_id' => $dispute->client_id,
            'project_id' => $dispute->project_id,
            'action' => 'dispute_evidence_compiled',
            'actor_type' => 'admin',
            'actor_id' => auth()->id(),
            'details' => json_encode([
                'dispute_id' => $dispute->dispute_id, 'items_count' => count($items),
                'package_hash' => $dispute->evidence_package_hash,
            ]),
            'ip_address' => request()->ip(),
        ]);

        return back()->with('success', count($items) . ' evidence items compiled. Hash: ' . substr($dispute->evidence_package_hash, 0, 16) . '...');
    }

    public function resolve(Request $request, Dispute $dispute) {
        $validated = $request->validate([
            'status' => 'required|in:won,lost,expired',
            'resolution_notes' => 'nullable|string|max:5000',
        ]);
        $dispute->update([
            'status' => $validated['status'],
            'resolved_by' => auth()->id(),
            'resolved_at' => now(),
            'resolution_notes' => $validated['resolution_notes'],
        ]);
        AuditLog::create([
            'client_id' => $dispute->client_id,
            'project_id' => $dispute->project_id,
            'action' => 'dispute_resolved_' . $validated['status'],
            'actor_type' => 'admin', 'actor_id' => auth()->id(),
            'details' => json_encode(['dispute_id' => $dispute->dispute_id, 'notes' => $validated['resolution_notes']]),
            'ip_address' => $request->ip(),
        ]);
        return back()->with('success', 'Dispute resolved: ' . $validated['status']);
    }
}
