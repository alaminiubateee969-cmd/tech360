<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Project;
use App\Models\Payment;
use App\Models\AuditLog;
class PaymentController extends Controller {
    public function show(Project $project) {
        $this->authorizeClient($project);
        $scope = $project->scopes()->where('status', 'approved')->latest()->first();
        if (!$scope) return redirect()->route('client.scope', $project)->withErrors(['error' => 'Please approve the Scope of Work first.']);
        $payment = $project->payments()->latest()->first();
        return view('client.payment', compact('project', 'scope', 'payment'));
    }
    public function process(Request $request, Project $project) {
        $this->authorizeClient($project);
        $validated = $request->validate(['terms_acknowledged' => 'required|accepted']);
        $scope = $project->scopes()->where('status', 'approved')->latest()->first();
        if (!$scope) return back()->withErrors(['error' => 'Scope not approved.']);
        
        // Create payment record — status = pending (NOT paid)
        $payment = Payment::create([
            'project_id' => $project->id,
            'client_id' => $project->client_id,
            'amount' => $scope->payment_amount,
            'currency' => 'USD',
            'status' => 'pending',
        ]);
        
        // In production: redirect to payment gateway
        // For now: return payment instructions
        $project->update(['commercial_state' => 'PAYMENT_PENDING']);
        
        AuditLog::create([
            'client_id' => $project->client_id,
            'project_id' => $project->id,
            'payment_id' => $payment->id,
            'action' => 'payment_initiated',
            'actor_type' => 'client',
            'actor_id' => auth()->id(),
            'details' => json_encode(['amount' => $payment->amount, 'currency' => $payment->currency]),
            'ip_address' => $request->ip(),
        ]);
        
        return view('client.payment-instructions', compact('project', 'payment'));
    }
    public function webhook(Request $request) {
        // HMAC signature verification (REQUIRED — never process unverified webhooks)
        $signature = $request->header('X-TECH360-Signature') ?? $request->header('Stripe-Signature') ?? '';
        $secret = env('PAYMENT_WEBHOOK_SECRET') ?? env('STRIPE_WEBHOOK_SECRET');
        if ($secret) {
            $payload = $request->getContent();
            $expected = hash_hmac('sha256', $payload, $secret);
            if (!hash_equals($expected, $signature)) {
                return response()->json(['error' => 'Invalid signature'], 401);
            }
        }

        // Replay protection: reject if timestamp older than 5 minutes
        $timestamp = $request->header('X-TECH360-Timestamp');
        if ($timestamp && abs(time() - (int)$timestamp) > 300) {
            return response()->json(['error' => 'Stale webhook'], 401);
        }

        $data = $request->all();
        $transactionId = $data['transaction_id'] ?? null;
        $invoiceId = $data['invoice_id'] ?? $data['payment_id'] ?? null;
        $amount = $data['amount'] ?? null;

        if (!$transactionId) return response()->json(['error' => 'Missing transaction_id'], 400);

        $payment = Payment::where('provider_transaction_id', $transactionId)->first();
        if ($payment) {
            // Idempotency: already processed
            if ($payment->status === 'paid') return response()->json(['status' => 'already_processed']);
        } else {
            $payment = Payment::find($invoiceId);
            if (!$payment) return response()->json(['error' => 'Payment not found'], 404);
        }

        // Verify amount
        if ($amount !== null && (float)$amount !== (float)$payment->amount) {
            return response()->json(['error' => 'Amount mismatch'], 400);
        }

        // Verify scope is approved
        $scope = $payment->project->scopes()->where('status', 'approved')->latest()->first();
        if (!$scope) return response()->json(['error' => 'Scope not approved'], 403);

        // Mark as paid (server-side only)
        $payment->update([
            'status' => 'paid',
            'provider_transaction_id' => $transactionId,
            'verified_by' => null, // webhook
            'verified_at' => now(),
        ]);

        // Update project
        $payment->project->update(['commercial_state' => 'PAYMENT_PAID']);

        AuditLog::create([
            'client_id' => $payment->client_id,
            'project_id' => $payment->project_id,
            'payment_id' => $payment->id,
            'action' => 'payment_verified',
            'actor_type' => 'system',
            'details' => json_encode(['transaction_id' => $transactionId, 'amount' => $payment->amount, 'source' => 'webhook']),
        ]);

        return response()->json(['status' => 'verified', 'project_state' => 'PAYMENT_PAID']);
    }
    private function authorizeClient($project) {
        $user = auth()->user();
        $client = $user->client;
        if (!$client || $project->client_id !== $client->id) abort(403, 'Unauthorized.');
    }
}
