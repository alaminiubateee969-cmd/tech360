<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Client;
use App\Models\Project;
use App\Models\Payment;
use App\Models\RefundRequest;
use App\Models\Delivery;
use App\Models\AuditLog;
class AdminController extends Controller {
    public function dashboard() {
        $stats = [
            'clients' => Client::count(),
            'projects' => Project::count(),
            'payments_pending' => Payment::where('status', 'pending')->count(),
            'payments_paid' => Payment::where('status', 'paid')->count(),
            'refunds_pending' => RefundRequest::where('status', 'refund_requested')->count(),
        ];
        return view('admin.dashboard', compact('stats'));
    }
    public function clients() {
        $clients = Client::with('projects')->latest()->paginate(20);
        return view('admin.clients', compact('clients'));
    }
    public function projects() {
        $projects = Project::with('client', 'scopes')->latest()->paginate(20);
        return view('admin.projects', compact('projects'));
    }
    public function payments() {
        $payments = Payment::with('project', 'client')->latest()->paginate(20);
        return view('admin.payments', compact('payments'));
    }
    public function verifyPayment(Request $request, $id) {
        $payment = Payment::findOrFail($id);
        if ($payment->status === 'paid') return back()->withErrors(['error' => 'Payment already verified.']);
        
        $scope = $payment->project->scopes()->where('status', 'approved')->latest()->first();
        if (!$scope) return back()->withErrors(['error' => 'Scope not approved. Cannot verify payment.']);
        
        $payment->update([
            'status' => 'paid',
            'verified_by' => auth()->id(),
            'verified_at' => now(),
        ]);
        
        $payment->project->update(['commercial_state' => 'PAYMENT_PAID']);
        
        AuditLog::create([
            'client_id' => $payment->client_id,
            'project_id' => $payment->project_id,
            'payment_id' => $payment->id,
            'action' => 'payment_verified',
            'actor_type' => 'admin',
            'actor_id' => auth()->id(),
            'details' => json_encode(['amount' => $payment->amount]),
            'ip_address' => $request->ip(),
        ]);
        
        return back()->with('success', 'Payment verified. Project activated for final development.');
    }
    public function refunds() {
        $refunds = RefundRequest::with('client', 'project')->latest()->paginate(20);
        return view('admin.refunds', compact('refunds'));
    }
    public function reviewRefund(Request $request, $id) {
        $refund = RefundRequest::findOrFail($id);
        if (in_array($refund->status, ['approved', 'denied', 'refunded'])) {
            return back()->withErrors(['error' => 'This refund has already been decided.']);
        }
        $validated = $request->validate([
            'decision' => 'required|in:approved,denied',
            'resolution' => 'nullable|string|max:5000',
        ]);
        $refund->update([
            'status' => $validated['decision'],
            'reviewed_by' => auth()->id(),
            'reviewed_at' => now(),
            'decision' => $validated['decision'],
            'resolution' => $validated['resolution'] ?? null,
        ]);
        AuditLog::create([
            'client_id' => $refund->client_id,
            'project_id' => $refund->project_id,
            'action' => 'refund_' . $validated['decision'],
            'actor_type' => 'admin',
            'actor_id' => auth()->id(),
            'details' => json_encode(['refund_id' => $refund->refund_id, 'decision' => $validated['decision']]),
            'ip_address' => $request->ip(),
        ]);
        return back()->with('success', 'Refund request ' . $validated['decision'] . '.');
    }
    public function releaseHandover(Request $request, $id) {
        $project = Project::findOrFail($id);
        $payment = $project->payments()->where('status', 'paid')->latest()->first();
        if (!$payment) return back()->withErrors(['error' => 'Payment not verified. Cannot release handover.']);
        
        $delivery = $project->deliveries()->latest()->first();
        if (!$delivery) {
            $count = Delivery::count();
            $delivery = Delivery::create([
                'delivery_id' => 'DEL-2026-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT),
                'project_id' => $project->id,
                'client_id' => $project->client_id,
                'payment_status' => 'verified',
                'qa_status' => 'passed',
                'admin_approval' => 'approved',
                'admin_approved_by' => auth()->id(),
                'admin_approved_at' => now(),
                'access_status' => 'TECH360_CONTROLLED',
            ]);
        } else {
            $delivery->update([
                'admin_approval' => 'approved',
                'admin_approved_by' => auth()->id(),
                'admin_approved_at' => now(),
            ]);
        }
        
        $project->update(['commercial_state' => 'FINAL_HANDOVER']);
        
        AuditLog::create([
            'client_id' => $project->client_id,
            'project_id' => $project->id,
            'action' => 'handover_released',
            'actor_type' => 'admin',
            'actor_id' => auth()->id(),
            'ip_address' => $request->ip(),
        ]);
        
        return back()->with('success', 'Handover released. Client can now access delivery.');
    }
    public function auditLogs() {
        $logs = AuditLog::orderBy('timestamp', 'desc')->paginate(50);
        return view('admin.audit-logs', compact('logs'));
    }
    public function aiCommandCenter() {
        $aiService = new \App\Services\AiService();
        $runningJobs = \App\Models\AiJob::where('status', 'running')->latest()->limit(20)->get();
        $queuedJobs = \App\Models\AiJob::where('status', 'queued')->latest()->limit(20)->get();
        $completedJobs = \App\Models\AiJob::where('status', 'completed')->latest()->limit(20)->get();
        $failedJobs = \App\Models\AiJob::where('status', 'failed')->latest()->limit(20)->get();
        $recommendations = $aiService->getRecommendations();
        return view('admin.ai-command-center', compact('runningJobs', 'queuedJobs', 'completedJobs', 'failedJobs', 'recommendations'));
    }
}
