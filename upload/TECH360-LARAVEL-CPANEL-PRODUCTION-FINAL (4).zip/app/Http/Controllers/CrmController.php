<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Contact;
use App\Models\LeadCrm;
use App\Models\Deal;
use App\Models\Activity;
use App\Models\Communication;
use App\Models\CrmTask;
use App\Models\FormSubmission;

class CrmController extends Controller {
    public function dashboard() {
        $stats = [
            'total_contacts' => Contact::count(),
            'new_leads' => LeadCrm::where('status', 'new')->count(),
            'qualified_leads' => LeadCrm::where('status', 'qualified')->count(),
            'customers' => Contact::where('status', 'customer')->count(),
            'open_deals' => Deal::whereNotIn('stage', ['won', 'lost'])->count(),
            'won_deals' => Deal::where('stage', 'won')->count(),
            'pipeline_value' => Deal::whereNotIn('stage', ['won', 'lost'])->sum('value'),
            'won_value' => Deal::where('stage', 'won')->sum('value'),
            'pending_tasks' => CrmTask::where('status', 'pending')->count(),
            'recent_leads' => LeadCrm::with('contact')->latest()->limit(5)->get(),
            'recent_activities' => Activity::with('contact')->latest()->limit(10)->get(),
        ];
        $leads_by_source = LeadCrm::selectRaw('source, count(*) as count')->groupBy('source')->pluck('count', 'source');
        $deals_by_stage = Deal::selectRaw('stage, count(*) as count, sum(value) as total')->groupBy('stage')->get();
        return view('crm.dashboard', compact('stats', 'leads_by_source', 'deals_by_stage'));
    }

    public function contacts(Request $request) {
        $query = Contact::with('company', 'assignedTo');
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('first_name', 'like', "%{$search}%")
                  ->orWhere('last_name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%");
            });
        }
        if ($request->filled('status')) $query->where('status', $request->status);
        $contacts = $query->latest()->paginate(20);
        return view('crm.contacts', compact('contacts'));
    }

    public function showContact($id) {
        $contact = Contact::with('company', 'assignedTo', 'leads', 'deals', 'activities', 'communications', 'tasks')->findOrFail($id);
        return view('crm.contact-detail', compact('contact'));
    }

    public function leads(Request $request) {
        $query = LeadCrm::with('contact', 'assignedTo');
        if ($request->filled('status')) $query->where('status', $request->status);
        $leads = $query->latest()->paginate(20);
        return view('crm.leads', compact('leads'));
    }

    public function deals(Request $request) {
        $query = Deal::with('contact', 'company', 'assignedTo');
        if ($request->filled('stage')) $query->where('stage', $request->stage);
        $deals = $query->latest()->paginate(20);
        return view('crm.deals', compact('deals'));
    }

    public function tasks() {
        $tasks = CrmTask::with('contact', 'assignedTo')->latest()->paginate(20);
        return view('crm.tasks', compact('tasks'));
    }

    public function storeContact(Request $request) {
        $validated = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'nullable|string|max:255',
            'email' => 'nullable|email|max:255',
            'phone' => 'nullable|string|max:50',
            'company_id' => 'nullable|exists:companies,id',
            'source' => 'nullable|string|max:255',
            'status' => 'in:lead,qualified,customer,inactive',
        ]);
        $count = Contact::count();
        $validated['contact_id'] = 'TECH-CON-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT);
        $validated['status'] = $validated['status'] ?? 'lead';
        $contact = Contact::create($validated);
        Activity::create([
            'entity_type' => 'contact', 'entity_id' => $contact->id, 'contact_id' => $contact->id,
            'type' => 'created', 'description' => 'Contact created', 'user_id' => auth()->id(),
        ]);
        return redirect()->route('crm.contacts.show', $contact->id)->with('success', 'Contact created.');
    }

    public function storeLead(Request $request) {
        $validated = $request->validate([
            'contact_id' => 'required|exists:contacts,id',
            'service_interest' => 'nullable|string',
            'source' => 'nullable|string',
            'status' => 'in:new,contacted,qualified,proposal,negotiation,won,lost',
        ]);
        $count = LeadCrm::count();
        $validated['lead_id'] = 'TECH-LEAD-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT);
        $validated['status'] = $validated['status'] ?? 'new';
        $lead = LeadCrm::create($validated);
        Activity::create([
            'entity_type' => 'lead', 'entity_id' => $lead->id, 'contact_id' => $lead->contact_id,
            'type' => 'created', 'description' => 'Lead created', 'user_id' => auth()->id(),
        ]);
        return back()->with('success', 'Lead created.');
    }

    public function storeDeal(Request $request) {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'contact_id' => 'nullable|exists:contacts,id',
            'company_id' => 'nullable|exists:companies,id',
            'value' => 'numeric|min:0',
            'stage' => 'in:prospecting,qualification,proposal,negotiation,won,lost',
        ]);
        $count = Deal::count();
        $validated['deal_id'] = 'TECH-DEAL-' . str_pad($count + 1, '0', STR_PAD_LEFT);
        $deal = Deal::create($validated);
        Activity::create([
            'entity_type' => 'deal', 'entity_id' => $deal->id, 'contact_id' => $deal->contact_id,
            'type' => 'created', 'description' => 'Deal created', 'user_id' => auth()->id(),
        ]);
        return back()->with('success', 'Deal created.');
    }

    public function storeTask(Request $request) {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'contact_id' => 'nullable|exists:contacts,id',
            'assigned_to' => 'nullable|exists:users,id',
            'priority' => 'in:low,medium,high,urgent',
            'due_date' => 'nullable|date',
        ]);
        $validated['status'] = 'pending';
        CrmTask::create($validated);
        return back()->with('success', 'Task created.');
    }

    public function addCommunication(Request $request, $contactId) {
        $validated = $request->validate([
            'channel' => 'required|in:email,whatsapp,phone,meeting,sms,note',
            'direction' => 'in:inbound,outbound',
            'subject' => 'nullable|string|max:255',
            'body' => 'required|string',
        ]);
        $validated['contact_id'] = $contactId;
        $validated['direction'] = $validated['direction'] ?? 'outbound';
        $validated['user_id'] = auth()->id();
        Communication::create($validated);
        Activity::create([
            'entity_type' => 'communication', 'entity_id' => 0, 'contact_id' => $contactId,
            'type' => $validated['channel'], 'description' => $validated['subject'] ?? $validated['channel'],
            'user_id' => auth()->id(),
        ]);
        return back()->with('success', 'Communication logged.');
    }
}
