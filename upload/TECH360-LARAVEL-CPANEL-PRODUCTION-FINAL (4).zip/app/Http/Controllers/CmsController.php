<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Service;
use App\Models\Portfolio;
use App\Models\BlogPost;
use App\Models\Testimonial;
use App\Models\Setting;

class CmsController extends Controller {
    public function services() { $services = Service::orderBy('sort_order')->paginate(20); return view('admin.cms.services', compact('services')); }
    public function storeService(Request $request) {
        $validated = $request->validate([
            'title' => 'required|string|max:255', 'slug' => 'required|string|max:255|unique:services,slug',
            'icon' => 'nullable|string', 'image' => 'nullable|string', 'short_description' => 'required|string',
            'description' => 'nullable|string', 'features' => 'nullable|string', 'benefits' => 'nullable|string',
            'seo_title' => 'nullable|string', 'seo_description' => 'nullable|string', 'is_active' => 'boolean',
        ]);
        if (isset($validated['features'])) $validated['features'] = json_decode($validated['features'], true) ?? [];
        if (isset($validated['benefits'])) $validated['benefits'] = json_decode($validated['benefits'], true) ?? [];
        Service::create($validated);
        return back()->with('success', 'Service created.');
    }
    public function portfolio() { $items = Portfolio::orderBy('sort_order')->paginate(20); return view('admin.cms.portfolio', compact('items')); }
    public function storePortfolio(Request $request) {
        $validated = $request->validate([
            'title' => 'required|string|max:255', 'slug' => 'required|string|max:255|unique:portfolio,slug',
            'client_name' => 'nullable|string', 'industry' => 'nullable|string', 'image' => 'nullable|string',
            'screenshot' => 'nullable|string', 'technology' => 'nullable|string', 'description' => 'nullable|string',
            'results' => 'nullable|string', 'is_featured' => 'boolean', 'is_active' => 'boolean',
        ]);
        Portfolio::create($validated);
        return back()->with('success', 'Portfolio item created.');
    }
    public function blog() { $posts = BlogPost::latest()->paginate(20); return view('admin.cms.blog', compact('posts')); }
    public function storeBlog(Request $request) {
        $validated = $request->validate([
            'title' => 'required|string|max:255', 'slug' => 'required|string|max:255|unique:blog_posts,slug',
            'excerpt' => 'nullable|string', 'content' => 'required|string', 'featured_image' => 'nullable|string',
            'category' => 'nullable|string', 'tags' => 'nullable|string', 'author' => 'nullable|string',
            'status' => 'in:draft,published,archived',
        ]);
        if ($validated['status'] === 'published') $validated['published_at'] = now();
        BlogPost::create($validated);
        return back()->with('success', 'Blog post created.');
    }
    public function testimonials() { $items = Testimonial::orderBy('sort_order')->paginate(20); return view('admin.cms.testimonials', compact('items')); }
    public function storeTestimonial(Request $request) {
        $validated = $request->validate([
            'author_name' => 'required|string', 'author_role' => 'nullable|string', 'author_company' => 'nullable|string',
            'content' => 'required|string', 'rating' => 'integer|min:1|max:5', 'is_featured' => 'boolean', 'is_active' => 'boolean',
        ]);
        Testimonial::create($validated);
        return back()->with('success', 'Testimonial created.');
    }
    public function settings() { $settings = Setting::orderBy('category')->get(); return view('admin.cms.settings', compact('settings')); }
    public function storeSetting(Request $request) {
        $validated = $request->validate(['key' => 'required|string', 'value' => 'nullable|string', 'category' => 'nullable|string']);
        Setting::set($validated['key'], $validated['value'] ?? '', $validated['category'] ?? 'general');
        return back()->with('success', 'Setting saved.');
    }
    public function formSubmissions() { $submissions = \App\Models\FormSubmission::latest()->paginate(20); return view('admin.cms.form-submissions', compact('submissions')); }
}
