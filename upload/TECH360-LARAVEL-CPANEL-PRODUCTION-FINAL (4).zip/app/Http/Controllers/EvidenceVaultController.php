<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\EvidenceVault;
use App\Models\AuditLog;
use Illuminate\Support\Facades\Storage;

class EvidenceVaultController extends Controller {
    public function index(Request $request) {
        $query = EvidenceVault::with('project', 'client', 'uploader');
        if ($request->filled('type')) $query->where('type', $request->type);
        if ($request->filled('project_id')) $query->where('project_id', $request->project_id);
        if ($request->filled('client_id')) $query->where('client_id', $request->client_id);
        $evidence = $query->latest()->paginate(25);
        $types = [
            'communication' => 'Communication', 'payment' => 'Payment', 'contract' => 'Contract',
            'invoice' => 'Invoice', 'delivery' => 'Delivery', 'acceptance' => 'Acceptance',
            'payout' => 'Payout', 'refund' => 'Refund', 'dispute' => 'Dispute',
            'audit' => 'Audit', 'source_release' => 'Source Release', 'handover' => 'Handover',
        ];
        return view('admin.evidence.index', compact('evidence', 'types'));
    }

    public function show(EvidenceVault $evidence) {
        $evidence->load('project', 'client', 'uploader');
        return view('admin.evidence.show', compact('evidence'));
    }

    public function store(Request $request) {
        $validated = $request->validate([
            'type' => 'required|in:communication,payment,contract,invoice,delivery,acceptance,payout,refund,dispute,audit,source_release,handover',
            'project_id' => 'nullable|exists:projects,id',
            'client_id' => 'nullable|exists:clients,id',
            'title' => 'required|string|max:255',
            'description' => 'nullable|string|max:5000',
            'event_at' => 'nullable|date',
            'file' => 'nullable|file|max:10240', // 10 MB max
        ]);

        $count = EvidenceVault::count();
        $validated['evidence_id'] = 'EVD-' . date('Y') . '-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT);
        $validated['uploaded_by'] = auth()->id();
        $validated['is_locked'] = true;
        $validated['permanent_delete_blocked'] = true;

        // Handle file upload
        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $safeExt = strtolower($file->getClientOriginalExtension());
            // MIME validation
            $allowed = ['pdf', 'png', 'jpg', 'jpeg', 'gif', 'txt', 'csv', 'json', 'zip'];
            if (!in_array($safeExt, $allowed)) {
                return back()->withErrors(['error' => 'File type not allowed.']);
            }
            // Generate safe filename
            $safeName = bin2hex(random_bytes(16)) . '.' . $safeExt;
            $path = $file->storeAs('evidence/' . date('Y/m'), $safeName, 'private');
            $validated['file_path'] = $path;
            $validated['file_hash'] = hash_file('sha256', $file->getRealPath());
        }

        $evidence = EvidenceVault::create($validated);
        $evidence->content_hash = hash('sha256', $validated['title'] . '|' . ($validated['description'] ?? ''));
        $evidence->save();

        AuditLog::create([
            'client_id' => $validated['client_id'] ?? null,
            'project_id' => $validated['project_id'] ?? null,
            'action' => 'evidence_uploaded',
            'actor_type' => 'admin',
            'actor_id' => auth()->id(),
            'details' => json_encode([
                'evidence_id' => $evidence->evidence_id, 'type' => $evidence->type,
                'file_hash' => $evidence->file_hash,
            ]),
            'ip_address' => $request->ip(),
        ]);

        return back()->with('success', 'Evidence stored: ' . $evidence->evidence_id);
    }

    public function verify(EvidenceVault $evidence) {
        $status = $evidence->verifyIntegrity();
        return back()->with('success', "Integrity check: {$status}");
    }

    /**
     * NO-DELETE POLICY: EvidenceVault records can only be soft-deleted,
     * never hard-deleted. The model's delete() method enforces this.
     */
    public function softDelete(Request $request, EvidenceVault $evidence) {
        $reason = $request->validate(['reason' => 'required|string|max:500'])['reason'];
        // Soft-delete only — record preserved with deleted_at
        $evidence->delete();

        AuditLog::create([
            'client_id' => $evidence->client_id,
            'project_id' => $evidence->project_id,
            'action' => 'evidence_soft_deleted',
            'actor_type' => 'admin',
            'actor_id' => auth()->id(),
            'details' => json_encode(['evidence_id' => $evidence->evidence_id, 'reason' => $reason]),
            'ip_address' => $request->ip(),
        ]);

        return back()->with('success', 'Evidence soft-deleted. Record preserved per no-delete policy.');
    }

    public function download(EvidenceVault $evidence) {
        if (!$evidence->file_path) abort(404, 'No file attached.');
        $disk = Storage::disk('private');
        if (!$disk->exists($evidence->file_path)) abort(404, 'File not found on disk.');

        // Verify hash before serving (detect tampering)
        $status = $evidence->verifyIntegrity();
        if ($status === 'tampered') abort(403, 'File integrity compromised — access denied.');

        AuditLog::create([
            'client_id' => $evidence->client_id,
            'project_id' => $evidence->project_id,
            'action' => 'evidence_downloaded',
            'actor_type' => 'admin',
            'actor_id' => auth()->id(),
            'details' => json_encode(['evidence_id' => $evidence->evidence_id]),
            'ip_address' => request()->ip(),
        ]);

        return $disk->download($evidence->file_path, $evidence->evidence_id . '-' . basename($evidence->file_path));
    }
}
