<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\AiAgent;
use App\Models\AiAgentTool;
use App\Models\AiAgentExecution;
use App\Models\AiAgentWorkflow;
use App\Models\AiKnowledgeDocument;
use App\Models\AiApproval;
use App\Models\AiAgentLog;
use App\Services\AiProviderService;
use App\Services\AiExecutionEngine;

class AiAgentController extends Controller {
    public function dashboard() {
        $stats = [
            'active_agents' => AiAgent::where('status', 'active')->count(),
            'inactive_agents' => AiAgent::where('status', 'inactive')->count(),
            'running_tasks' => AiAgentExecution::where('status', 'running')->count(),
            'completed_tasks' => AiAgentExecution::where('status', 'completed')->count(),
            'failed_tasks' => AiAgentExecution::where('status', 'failed')->count(),
            'pending_approvals' => AiApproval::where('status', 'pending')->count(),
            'total_tools' => AiAgentTool::where('enabled', true)->count(),
            'workflows' => AiAgentWorkflow::where('status', 'active')->count(),
            'knowledge_docs' => AiKnowledgeDocument::where('is_active', true)->count(),
        ];
        $agents = AiAgent::withCount('executions')->latest()->get();
        $recentExecutions = AiAgentExecution::with('agent')->latest()->limit(10)->get();
        $pendingApprovals = AiApproval::with('agent')->where('status', 'pending')->latest()->limit(10)->get();
        $recentLogs = AiAgentLog::with('agent')->latest()->limit(20)->get();
        return view('admin.ai-dashboard', compact('stats', 'agents', 'recentExecutions', 'pendingApprovals', 'recentLogs'));
    }

    public function index() {
        $agents = AiAgent::with('skills', 'tools')->latest()->paginate(20);
        return view('admin.ai-agents.index', compact('agents'));
    }

    public function show(AiAgent $aiAgent) {
        $aiAgent->load('skills', 'tools', 'memories', 'executions', 'logs');
        return view('admin.ai-agents.show', compact('aiAgent'));
    }

    public function store(Request $request) {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'instructions' => 'nullable|string',
            'provider' => 'in:openai,ollama,custom',
            'model' => 'nullable|string',
            'mode' => 'in:manual,approval,autonomous',
        ]);
        $count = AiAgent::count();
        $validated['agent_id'] = 'AGENT-' . str_pad($count + 1, 4, '0', STR_PAD_LEFT);
        $validated['slug'] = \Illuminate\Support\Str::slug($validated['name']);
        $validated['status'] = 'active';
        $agent = AiAgent::create($validated);
        return back()->with('success', 'AI Agent created: ' . $agent->name);
    }

    public function toggleStatus(AiAgent $aiAgent) {
        $aiAgent->update(['status' => $aiAgent->status === 'active' ? 'inactive' : 'active']);
        return back()->with('success', 'Agent status updated.');
    }

    public function execute(Request $request, AiAgent $aiAgent) {
        $validated = $request->validate(['input' => 'required|string|max:5000']);
        $engine = new AiExecutionEngine(new AiProviderService());
        $execution = $engine->execute($aiAgent, $validated['input'], auth()->id());
        return back()->with('success', 'Execution created: ' . $execution->execution_id . ' (Status: ' . $execution->status . ')');
    }

    public function approvals() {
        $approvals = AiApproval::with('agent', 'execution')->latest()->paginate(20);
        return view('admin.ai-approvals', compact('approvals'));
    }

    public function approveRequest(Request $request, AiApproval $approval) {
        $engine = new AiExecutionEngine(new AiProviderService());
        $execution = $engine->approveAndExecute($approval);
        $approval->update(['reviewer_id' => auth()->id(), 'reviewed_at' => now()]);
        return back()->with('success', 'Approved and executed. Status: ' . $execution->status);
    }

    public function rejectRequest(Request $request, AiApproval $approval) {
        $approval->update([
            'status' => 'rejected',
            'reviewer_id' => auth()->id(),
            'reviewed_at' => now(),
            'review_note' => $request->review_note ?? 'Rejected by admin',
        ]);
        return back()->with('success', 'Approval rejected.');
    }

    public function knowledge() {
        $docs = AiKnowledgeDocument::latest()->paginate(20);
        return view('admin.ai-knowledge', compact('docs'));
    }

    public function storeKnowledge(Request $request) {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'category' => 'required|string',
            'content' => 'required|string',
        ]);
        $validated['is_active'] = true;
        $validated['created_by'] = auth()->id();
        AiKnowledgeDocument::create($validated);
        return back()->with('success', 'Knowledge document created.');
    }

    public function workflows() {
        $workflows = AiAgentWorkflow::latest()->paginate(20);
        return view('admin.ai-workflows', compact('workflows'));
    }

    public function storeWorkflow(Request $request) {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'trigger_type' => 'nullable|string',
            'steps' => 'nullable|string',
            'schedule' => 'nullable|string',
        ]);
        $count = AiAgentWorkflow::count();
        $validated['workflow_id'] = 'WF-' . str_pad($count + 1, 4, '0', STR_PAD_LEFT);
        if (!empty($validated['steps'])) $validated['steps'] = json_decode($validated['steps'], true) ?? [];
        $validated['status'] = 'inactive';
        AiAgentWorkflow::create($validated);
        return back()->with('success', 'Workflow created.');
    }

    public function logs() {
        $logs = AiAgentLog::with('agent')->latest()->paginate(50);
        return view('admin.ai-logs', compact('logs'));
    }

    public function command(Request $request) {
        $validated = $request->validate(['command' => 'required|string|max:5000']);
        $command = strtolower($validated['command']);
        
        $engine = new AiExecutionEngine(new AiProviderService());
        
        // Route to appropriate agent based on command
        $agent = null;
        if (str_contains($command, 'lead')) $agent = AiAgent::where('slug', 'lead-management-agent')->first();
        elseif (str_contains($command, 'sales') || str_contains($command, 'deal')) $agent = AiAgent::where('slug', 'sales-agent')->first();
        elseif (str_contains($command, 'report')) $agent = AiAgent::where('slug', 'reporting-agent')->first();
        elseif (str_contains($command, 'support')) $agent = AiAgent::where('slug', 'support-agent')->first();
        
        if (!$agent) $agent = AiAgent::first();
        if (!$agent) return back()->withErrors(['error' => 'No AI agents configured.']);
        
        $execution = $engine->execute($agent, $validated['command'], auth()->id());
        return back()->with('success', 'Command sent to ' . $agent->name . '. Execution: ' . $execution->execution_id . ' (Status: ' . $execution->status . ')');
    }
}
