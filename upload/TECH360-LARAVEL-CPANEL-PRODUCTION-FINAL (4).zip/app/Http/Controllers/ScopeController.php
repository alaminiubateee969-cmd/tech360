<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Project;
use App\Models\ScopeOfWork;
use App\Models\ScopeApproval;
use App\Models\AuditLog;
class ScopeController extends Controller {
    public function show(Project $project) {
        $this->authorizeClient($project);
        $scope = $project->scopes()->latest()->first();
        return view('client.scope', compact('project', 'scope'));
    }
    public function approve(Request $request, Project $project) {
        $this->authorizeClient($project);
        $validated = $request->validate([
            'scope_reviewed' => 'required|accepted',
            'preview_reviewed' => 'required|accepted',
            'terms_accepted' => 'required|accepted',
            'refund_policy_acknowledged' => 'required|accepted',
            'non_refundable_acknowledged' => 'required|accepted',
        ]);
        $scope = $project->scopes()->where('status', '!=', 'approved')->latest()->first();
        if (!$scope) return back()->withErrors(['error' => 'No pending scope to approve.']);
        if ($scope->status === 'approved') return back()->withErrors(['error' => 'This scope is already approved.']);
        
        // Create immutable snapshot
        $snapshot = json_encode($scope->only(['scope_id', 'version', 'title', 'objective', 'features_included', 'features_excluded', 'timeline', 'payment_amount', 'payment_terms']));
        
        // Update scope
        $scope->update([
            'status' => 'approved',
            'terms_accepted' => true,
            'refund_policy_accepted' => true,
            'preview_acknowledged' => true,
            'immutable_snapshot' => $snapshot,
            'approved_by' => auth()->id(),
            'approved_at' => now(),
        ]);
        
        // Create approval record
        $count = ScopeApproval::count();
        ScopeApproval::create([
            'approval_id' => 'APR-2026-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT),
            'client_id' => $project->client_id,
            'project_id' => $project->id,
            'scope_id' => $scope->id,
            'scope_version' => $scope->version,
            'terms_version' => 'May 19, 2026',
            'refund_policy_version' => 'May 19, 2026',
            'approval_method' => 'web_form',
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'user_id' => auth()->id(),
            'approved_at' => now(),
            'immutable_snapshot' => $snapshot,
        ]);
        
        // Audit log
        AuditLog::create([
            'client_id' => $project->client_id,
            'project_id' => $project->id,
            'scope_id' => $scope->id,
            'action' => 'scope_approved',
            'actor_type' => 'client',
            'actor_id' => auth()->id(),
            'details' => json_encode(['scope_version' => $scope->version]),
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
        ]);
        
        // Update project state
        $project->update(['commercial_state' => 'SCOPE_APPROVED']);
        
        return redirect()->route('client.payment', $project)->with('success', 'Scope approved. Full payment is now required.');
    }
    public function requestChange(Request $request, Project $project) {
        $this->authorizeClient($project);
        $validated = $request->validate(['change_description' => 'required|string|max:5000']);
        // Create change request
        \App\Models\ChangeRequest::create([
            'project_id' => $project->id,
            'description' => $validated['change_description'],
            'status' => 'pending',
            'requested_by' => auth()->id(),
        ]);
        return back()->with('success', 'Change request submitted. TECH360 will review and respond.');
    }
    private function authorizeClient($project) {
        $user = auth()->user();
        $client = $user->client;
        if (!$client || $project->client_id !== $client->id) abort(403, 'Unauthorized access to this project.');
    }
}
