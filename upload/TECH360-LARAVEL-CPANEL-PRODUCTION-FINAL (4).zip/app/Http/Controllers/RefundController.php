<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\RefundRequest;
use App\Models\AuditLog;
class RefundController extends Controller {
    public function showForm() {
        $user = auth()->user();
        $client = $user->client;
        $projects = $client ? $client->projects : collect();
        return view('client.refund-request', compact('projects', 'client'));
    }
    public function submit(Request $request) {
        $validated = $request->validate([
            'project_id' => 'nullable|exists:projects,id',
            'invoice_number' => 'nullable|string|max:255',
            'payment_reference' => 'nullable|string|max:255',
            'payment_date' => 'nullable|date',
            'reason' => 'required|string|max:1000',
            'description' => 'nullable|string|max:5000',
        ]);
        $user = auth()->user();
        $client = $user->client;
        if (!$client) return back()->withErrors(['error' => 'Client record not found.']);
        
        $count = RefundRequest::count();
        $refund = RefundRequest::create([
            'refund_id' => 'REF-2026-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT),
            'client_id' => $client->id,
            'project_id' => $validated['project_id'] ?? null,
            'invoice_number' => $validated['invoice_number'] ?? null,
            'payment_reference' => $validated['payment_reference'] ?? null,
            'payment_date' => $validated['payment_date'] ?? null,
            'reason' => $validated['reason'],
            'description' => $validated['description'] ?? null,
            'status' => 'refund_requested', // NOT refunded
        ]);
        
        AuditLog::create([
            'client_id' => $client->id,
            'project_id' => $validated['project_id'] ?? null,
            'action' => 'refund_requested',
            'actor_type' => 'client',
            'actor_id' => $user->id,
            'details' => json_encode(['refund_id' => $refund->refund_id, 'reason' => $validated['reason']]),
            'ip_address' => $request->ip(),
        ]);
        
        return back()->with('success', 'Refund request submitted. Submitting a refund request does not guarantee approval. TECH360 will review according to the Refund Policy.');
    }
}
