<?php
namespace App\Http\Controllers;
use App\Models\Project;
class ProjectController extends Controller {
    public function preview(Project $project) {
        $this->authorizeClient($project);
        $preview = $project->scopes()->latest()->first();
        return view('client.preview', compact('project', 'preview'));
    }
    private function authorizeClient($project) {
        $user = auth()->user();
        $client = $user->client;
        if (!$client || $project->client_id !== $client->id) abort(403, 'Unauthorized.');
    }
}
