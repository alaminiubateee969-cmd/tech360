<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Project;
use App\Models\Delivery;
use App\Models\Payment;
use App\Models\AuditLog;
class DeliveryController extends Controller {
    public function show(Project $project) {
        $this->authorizeClient($project);
        $delivery = $project->deliveries()->latest()->first();
        $payment = $project->payments()->where('status', 'paid')->latest()->first();
        $sourceCodeAccess = $this->checkSourceCodeAccess($project, $payment, $delivery);
        return view('client.handover', compact('project', 'delivery', 'payment', 'sourceCodeAccess'));
    }
    public function confirmDelivery(Request $request, Project $project) {
        $this->authorizeClient($project);
        $validated = $request->validate(['delivery_confirmed' => 'required|accepted']);
        $delivery = $project->deliveries()->latest()->first();
        if (!$delivery) return back()->withErrors(['error' => 'No delivery found.']);
        
        $delivery->update([
            'client_confirmed' => true,
            'client_confirmed_at' => now(),
        ]);
        
        $project->update(['commercial_state' => 'PROJECT_CLOSED']);
        
        AuditLog::create([
            'client_id' => $project->client_id,
            'project_id' => $project->id,
            'action' => 'delivery_confirmed',
            'actor_type' => 'client',
            'actor_id' => auth()->id(),
            'ip_address' => $request->ip(),
        ]);
        
        return redirect()->route('client.dashboard')->with('success', 'Project delivery confirmed. Project is now closed.');
    }
    public function download(Request $request, Project $project) {
        $this->authorizeClient($project);
        $payment = $project->payments()->where('status', 'paid')->latest()->first();
        $delivery = $project->deliveries()->latest()->first();
        
        // ENFORCE: Source code is BLOCKED until all gates pass
        $access = $this->checkSourceCodeAccess($project, $payment, $delivery);
        if (!$access['granted']) {
            abort(403, 'Source code access is BLOCKED. Required: ' . implode(', ', $access['failed_gates']));
        }
        
        // Return signed download URL or file
        return response()->json(['message' => 'Download authorized', 'url' => $delivery->signed_url]);
    }
    private function checkSourceCodeAccess($project, $payment, $delivery) {
        $gates = [
            'scope_approved' => $project->scopes()->where('status', 'approved')->exists(),
            'payment_verified' => $payment && $payment->status === 'paid',
            'qa_passed' => $delivery && $delivery->qa_status === 'passed',
            'admin_approval' => $delivery && $delivery->admin_approval === 'approved',
            'password_rotation' => $delivery && $delivery->password_rotation_complete,
        ];
        $failed = array_keys(array_filter($gates, fn($v) => !$v));
        return ['granted' => empty($failed), 'failed_gates' => $failed, 'gates' => $gates];
    }
    private function authorizeClient($project) {
        $user = auth()->user();
        $client = $user->client;
        if (!$client || $project->client_id !== $client->id) abort(403, 'Unauthorized.');
    }
}
