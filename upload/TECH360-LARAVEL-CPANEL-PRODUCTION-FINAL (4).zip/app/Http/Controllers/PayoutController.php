<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Payout;
use App\Models\Payment;
use App\Models\Project;
use App\Models\Client;
use App\Models\AuditLog;
use App\Models\EvidenceVault;

class PayoutController extends Controller {
    public function index(Request $request) {
        $query = Payout::with('project', 'client', 'payment');
        if ($request->filled('status')) $query->where('status', $request->status);
        if ($request->filled('high_value')) $query->where('high_value_review_required', true);
        $payouts = $query->latest()->paginate(20);
        return view('admin.payouts.index', compact('payouts'));
    }

    public function create() {
        $projects = Project::orderBy('name')->get();
        $clients = Client::orderBy('name')->get();
        return view('admin.payouts.create', compact('projects', 'clients'));
    }

    public function store(Request $request) {
        $validated = $request->validate([
            'project_id' => 'nullable|exists:projects,id',
            'client_id' => 'nullable|exists:clients,id',
            'payment_id' => 'nullable|exists:payments,id',
            'amount' => 'required|numeric|min:0.01|max:1000000',
            'currency' => 'in:USD,EUR,GBP',
            'recipient_type' => 'required|string',
            'recipient_name' => 'nullable|string|max:255',
            'recipient_account_reference' => 'nullable|string|max:255',
            'method' => 'nullable|string',
            'notes' => 'nullable|string|max:5000',
        ]);

        // Run risk assessment BEFORE creating
        $risk = Payout::assessRisk((float)$validated['amount'], $validated['client_id'] ?? null);
        $validated['risk_score'] = $risk['score'];
        $validated['risk_flags'] = json_encode($risk['flags']);
        $validated['instant_payout_eligible'] = $risk['instant_payout_eligible'];
        $validated['high_value_review_required'] = $risk['high_value_review_required'];

        // Status logic
        if ($risk['high_value_review_required']) {
            $validated['status'] = 'on_hold'; // requires manual approval
        } else {
            $validated['status'] = $risk['instant_payout_eligible'] ? 'pending' : 'pending';
        }

        $count = Payout::count();
        $validated['payout_id'] = 'PAY-' . date('Y') . '-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT);

        $payout = Payout::create($validated);

        // Audit log
        AuditLog::create([
            'client_id' => $validated['client_id'] ?? null,
            'project_id' => $validated['project_id'] ?? null,
            'action' => 'payout_created',
            'actor_type' => 'admin',
            'actor_id' => auth()->id(),
            'details' => json_encode([
                'payout_id' => $payout->payout_id,
                'amount' => $payout->amount,
                'risk_score' => $risk['score'],
                'risk_flags' => $risk['flags'],
            ]),
            'ip_address' => $request->ip(),
        ]);

        // Evidence vault entry
        EvidenceVault::create([
            'evidence_id' => 'EVD-' . date('Y') . '-' . str_pad(EvidenceVault::count() + 1, 6, '0', STR_PAD_LEFT),
            'type' => EvidenceVault::TYPE_PAYOUT,
            'project_id' => $validated['project_id'] ?? null,
            'client_id' => $validated['client_id'] ?? null,
            'title' => 'Payout Created: ' . $payout->payout_id,
            'description' => "Amount: {$payout->amount} {$payout->currency}, Method: {$payout->method}, Risk Score: {$risk['score']}",
            'event_at' => now(),
            'uploaded_by' => auth()->id(),
        ]);

        $msg = 'Payout created: ' . $payout->payout_id;
        if ($risk['high_value_review_required']) $msg .= ' — HIGH-VALUE REVIEW REQUIRED';
        return redirect()->route('admin.payouts.index')->with('success', $msg);
    }

    public function approve(Request $request, Payout $payout) {
        if (!in_array($payout->status, ['pending', 'on_hold'])) {
            return back()->withErrors(['error' => 'Only pending or on-hold payouts can be approved.']);
        }
        $payout->update([
            'status' => 'approved',
            'approved_by' => auth()->id(),
            'approved_at' => now(),
        ]);
        AuditLog::create([
            'client_id' => $payout->client_id, 'project_id' => $payout->project_id,
            'action' => 'payout_approved', 'actor_type' => 'admin', 'actor_id' => auth()->id(),
            'details' => json_encode(['payout_id' => $payout->payout_id, 'amount' => $payout->amount]),
            'ip_address' => $request->ip(),
        ]);
        return back()->with('success', 'Payout approved.');
    }

    public function markProcessed(Request $request, Payout $payout) {
        $validated = $request->validate([
            'provider_reference' => 'nullable|string|max:255',
        ]);
        $payout->update([
            'status' => 'completed',
            'processed_by' => auth()->id(),
            'processed_at' => now(),
            'provider_reference' => $validated['provider_reference'] ?? null,
        ]);
        AuditLog::create([
            'client_id' => $payout->client_id, 'project_id' => $payout->project_id,
            'action' => 'payout_processed', 'actor_type' => 'admin', 'actor_id' => auth()->id(),
            'details' => json_encode(['payout_id' => $payout->payout_id, 'provider_reference' => $payout->provider_reference]),
            'ip_address' => $request->ip(),
        ]);
        return back()->with('success', 'Payout marked as processed.');
    }
}
