<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Services\AiProviderService;
use App\Services\AiExecutionEngine;
use App\Models\AiAgent;
use App\Models\AiKnowledgeDocument;
use App\Models\AuditLog;
class HomeController extends Controller {
    public function index() { return view('pages.home'); }
    public function about() { return view('pages.about'); }
    public function services() { return view('pages.services'); }
    public function serviceDetail($slug) {
        $service = \App\Models\Service::where('slug', $slug)->where('is_active', true)->firstOrFail();
        return view('pages.service-detail', compact('service'));
    }
    public function industries() { return view('pages.industries'); }
    public function portfolio() {
        $items = \App\Models\Portfolio::where('is_active', true)->orderBy('sort_order')->get();
        return view('pages.portfolio', compact('items'));
    }
    public function portfolioDetail($slug) {
        $item = \App\Models\Portfolio::where('slug', $slug)->where('is_active', true)->firstOrFail();
        return view('pages.portfolio-detail', compact('item'));
    }
    public function caseStudies() { return view('pages.case-studies'); }
    public function blog() {
        $posts = \App\Models\BlogPost::published()->latest()->paginate(9);
        return view('pages.blog', compact('posts'));
    }
    public function blogPost($slug) {
        $post = \App\Models\BlogPost::where('slug', $slug)->published()->firstOrFail();
        return view('pages.blog-post', compact('post'));
    }
    public function pricing() { return view('pages.pricing'); }
    public function contact() { return view('pages.contact'); }
    public function submitContact(Request $request) {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'phone' => 'nullable|string|max:50',
            'company' => 'nullable|string|max:255',
            'message' => 'required|string|max:5000',
        ]);
        // Create or find contact
        $contact = \App\Models\Contact::firstOrCreate(
            ['email' => $validated['email']],
            [
                'contact_id' => 'TECH-CON-' . str_pad(\App\Models\Contact::count() + 1, 6, '0', STR_PAD_LEFT),
                'first_name' => $validated['name'],
                'phone' => $validated['phone'] ?? null,
                'source' => 'website',
                'status' => 'lead',
            ]
        );
        // Create lead
        $lead = \App\Models\LeadCrm::create([
            'lead_id' => 'TECH-LEAD-' . str_pad(\App\Models\LeadCrm::count() + 1, 6, '0', STR_PAD_LEFT),
            'contact_id' => $contact->id,
            'source' => 'website',
            'status' => 'new',
        ]);
        // Store form submission
        \App\Models\FormSubmission::create([
            'form_type' => 'contact',
            'name' => $validated['name'],
            'email' => $validated['email'],
            'phone' => $validated['phone'] ?? null,
            'company' => $validated['company'] ?? null,
            'message' => $validated['message'],
            'source_page' => url()->previous(),
            'contact_id' => $contact->id,
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
        ]);
        // Log activity
        \App\Models\Activity::create([
            'entity_type' => 'lead', 'entity_id' => $lead->id, 'contact_id' => $contact->id,
            'type' => 'form_submission', 'description' => 'Contact form submitted: ' . $validated['name'],
        ]);
        return back()->with('success', 'Thank you for contacting TECH360. We will respond within 24 hours.');
    }
    public function terms() { return view('pages.terms'); }
    public function refundPolicy() { return view('pages.refund-policy'); }
    public function privacyPolicy() { return view('pages.privacy-policy'); }
    public function cookiePolicy() { return view('pages.cookie-policy'); }

    /**
     * Public AI Chatbot — real AI agent execution, NOT a demo.
     * Routes to the "Website Enquiry Agent" (slug: website-enquiry-agent) seeded in the system.
     * Falls back to a knowledge-base-aware response only if AI provider is unconfigured.
     */
    public function aiChat(Request $request) {
        $validated = $request->validate([
            'message' => 'required|string|max:2000',
        ]);

        // Find the Website Enquiry Agent
        $agent = AiAgent::where('slug', 'website-enquiry-agent')->first()
            ?? AiAgent::where('slug', 'support-agent')->first()
            ?? AiAgent::where('status', 'active')->first();

        if (!$agent) {
            return response()->json([
                'success' => false,
                'error' => 'No AI agent available',
            ], 503);
        }

        $provider = new AiProviderService();
        $engine = new AiExecutionEngine($provider);

        // Build context from knowledge base (always included — real data)
        $knowledge = AiKnowledgeDocument::where('is_active', true)->get();
        $knowledgeText = $knowledge->map(fn($d) => "[{$d->category}] {$d->title}: {$d->content}")->implode("\n");

        // Build messages for chat completion (REAL API call)
        $messages = [
            [
                'role' => 'system',
                'content' => $agent->instructions . "\n\nYou are the TECH360 website assistant. Be helpful, concise, and professional. Answer based on TECH360's real services and policies below:\n\n" . $knowledgeText,
            ],
            ['role' => 'user', 'content' => $validated['message']],
        ];

        $result = $provider->chat($messages, $agent->model);

        if (!$result['success']) {
            // AI provider unconfigured or unreachable — return a knowledge-base-aware fallback
            // (NOT a fake response — clearly states AI is unavailable, then provides canned info)
            $fallback = $this->buildKnowledgeFallback($validated['message'], $knowledge);
            return response()->json([
                'success' => true,
                'response' => $fallback,
                'provider_status' => $result['error'] ?? 'unavailable',
            ]);
        }

        // Log the AI execution as an audit entry
        AuditLog::create([
            'action' => 'public_ai_chat',
            'actor_type' => 'visitor',
            'actor_id' => null,
            'details' => json_encode([
                'agent_id' => $agent->id,
                'agent_name' => $agent->name,
                'message_length' => strlen($validated['message']),
                'tokens_input' => $result['tokens_input'] ?? 0,
                'tokens_output' => $result['tokens_output'] ?? 0,
            ]),
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
        ]);

        return response()->json([
            'success' => true,
            'response' => $result['content'],
            'agent' => $agent->name,
        ]);
    }

    /**
     * Build a knowledge-base-aware fallback when AI provider is unreachable.
     * This is NOT a fake demo response — it clearly tells the user AI is offline
     * and provides canned info from the knowledge base.
     */
    private function buildKnowledgeFallback(string $message, $knowledge): string {
        $msg = strtolower($message);
        $prefix = "I apologize — our AI service is temporarily offline. Here's what I can tell you from our knowledge base:\n\n";

        // Match on keywords
        if (str_contains($msg, 'price') || str_contains($msg, 'cost') || str_contains($msg, 'budget')) {
            $pricing = $knowledge->firstWhere('category', 'pricing');
            return $prefix . ($pricing?->content ?? 'Please visit our Pricing page at /pricing for full pricing tiers from $750 to custom enterprise estimates.');
        }
        if (str_contains($msg, 'refund')) {
            $refund = $knowledge->firstWhere('category', 'policy');
            return $prefix . ($refund?->content ?? 'After Scope of Work approval, payments are non-refundable except where required by law. See /refund-policy for full details.');
        }
        if (str_contains($msg, 'support') || str_contains($msg, 'help')) {
            $support = $knowledge->firstWhere('category', 'support');
            return $prefix . ($support?->content ?? '30-day post-delivery bug-fix support is included. Email support@tech360.io for assistance.');
        }
        if (str_contains($msg, 'service') || str_contains($msg, 'what do you do')) {
            $services = $knowledge->firstWhere('category', 'company');
            return $prefix . ($services?->content ?? 'TECH360 provides website, software, CRM, cloud, automation, and digital transformation services. Visit /services for full details.');
        }
        if (str_contains($msg, 'contact') || str_contains($msg, 'email') || str_contains($msg, 'reach')) {
            return $prefix . 'You can reach TECH360 by emailing support@tech360.io, or visit our Contact page at /contact to submit a project inquiry. We respond within 24 business hours.';
        }
        // Default: show full knowledge base summary
        $summary = $knowledge->take(3)->map(fn($d) => "• {$d->title}: {$d->content}")->implode("\n");
        return $prefix . "Here are some key details about TECH360:\n\n" . $summary . "\n\nFor more specific questions, please email support@tech360.io or visit /contact.";
    }
}
