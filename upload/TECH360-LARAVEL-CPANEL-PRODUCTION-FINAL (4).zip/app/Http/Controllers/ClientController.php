<?php
namespace App\Http\Controllers;
use App\Models\Client;
use App\Models\Project;
class ClientController extends Controller {
    public function dashboard() {
        $user = auth()->user();
        $client = $user->client;
        $projects = $client ? $client->projects()->latest()->get() : collect();
        return view('client.dashboard', compact('projects', 'client'));
    }
}
