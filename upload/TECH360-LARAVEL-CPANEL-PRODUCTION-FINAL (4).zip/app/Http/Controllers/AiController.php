<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Services\AiService;

class AiController extends Controller
{
    public function webhook(Request $request, AiService $aiService)
    {
        // Verify webhook signature
        $secret = env('AI_WEBHOOK_SECRET');
        if ($secret) {
            $signature = $request->header('X-AI-Signature');
            $expected = hash_hmac('sha256', $request->getContent(), $secret);
            if (!hash_equals($expected, $signature ?? '')) {
                return response()->json(['error' => 'Invalid signature'], 403);
            }
        }

        $validated = $request->validate([
            'job_id' => 'required|string',
            'result' => 'nullable|string',
            'error' => 'nullable|string',
        ]);

        $success = $aiService->receiveResult(
            $validated['job_id'],
            $validated['result'] ?? '',
            $validated['error'] ?? null
        );

        return response()->json(['received' => $success]);
    }
}
