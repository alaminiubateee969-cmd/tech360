<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
class AdminMiddleware {
    public function handle(Request $request, Closure $next) {
        if (!auth()->check() || !auth()->user()->isStaff()) {
            abort(403, 'Unauthorized. Admin access required.');
        }
        return $next($request);
    }
}
