<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Activity extends Model {
    protected $fillable = ['entity_type', 'entity_id', 'contact_id', 'type', 'description', 'user_id'];
    public function contact() { return $this->belongsTo(Contact::class); }
    public function user() { return $this->belongsTo(User::class); }
}
