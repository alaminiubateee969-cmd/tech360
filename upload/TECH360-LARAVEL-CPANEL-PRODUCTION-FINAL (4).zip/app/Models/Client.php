<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
class Client extends Model {
    use HasFactory;
    use SoftDeletes;
    protected $fillable = ['client_id', 'name', 'email', 'phone', 'company', 'business_type', 'status', 'user_id', 'notes'];
    public function user() { return $this->belongsTo(User::class); }
    public function projects() { return $this->hasMany(Project::class); }
}
