<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class AiAgentWorkflow extends Model {
    protected $fillable = ['workflow_id', 'name', 'description', 'trigger_type', 'steps', 'status', 'schedule'];
    protected $casts = ['steps' => 'array', 'status' => 'string'];
}
