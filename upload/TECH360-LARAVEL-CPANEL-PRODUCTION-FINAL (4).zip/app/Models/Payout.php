<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class Payout extends Model {
    use HasFactory;
    use SoftDeletes;
    protected $fillable = [
        'payout_id', 'project_id', 'client_id', 'payment_id', 'amount', 'currency',
        'recipient_type', 'recipient_name', 'recipient_account_reference', 'method',
        'provider_reference', 'status', 'instant_payout_eligible', 'high_value_review_required',
        'risk_score', 'risk_flags', 'approved_by', 'approved_at', 'processed_by', 'processed_at', 'notes',
    ];
    protected $casts = [
        'approved_at' => 'datetime',
        'processed_at' => 'datetime',
        'instant_payout_eligible' => 'boolean',
        'high_value_review_required' => 'boolean',
        'risk_score' => 'decimal:2',
    ];

    public function project() { return $this->belongsTo(Project::class); }
    public function client() { return $this->belongsTo(Client::class); }
    public function payment() { return $this->belongsTo(Payment::class); }

    // Risk engine — high-value payouts require manual review
    public const INSTANT_PAYOUT_THRESHOLD = 10000; // $10,000
    public const HIGH_VALUE_THRESHOLD = 20000; // $20,000

    public static function assessRisk(float $amount, ?int $clientId = null): array {
        $flags = [];
        $score = 0;

        if ($amount >= self::HIGH_VALUE_THRESHOLD) {
            $flags[] = 'high_value_review_required';
            $score += 50;
        }
        if ($amount >= self::INSTANT_PAYOUT_THRESHOLD && $amount < self::HIGH_VALUE_THRESHOLD) {
            $flags[] = 'instant_payout_eligible_capped';
            $score += 20;
        }
        // Check client history
        if ($clientId) {
            $client = Client::find($clientId);
            if ($client && $client->created_at && $client->created_at->diffInDays(now()) < 7) {
                $flags[] = 'new_client_under_7_days';
                $score += 30;
            }
        }
        $score = min(100, $score);

        return [
            'score' => $score,
            'flags' => $flags,
            'instant_payout_eligible' => $amount < self::INSTANT_PAYOUT_THRESHOLD,
            'high_value_review_required' => $amount >= self::HIGH_VALUE_THRESHOLD,
        ];
    }
}
