<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Preview extends Model {
    protected $fillable = ['preview_id', 'project_id', 'version', 'url', 'access_token', 'password_hash', 'expires_at', 'status', 'viewed_at', 'view_count'];
    protected $casts = ['expires_at' => 'datetime', 'viewed_at' => 'datetime'];
    public function project() { return $this->belongsTo(Project::class); }
}
