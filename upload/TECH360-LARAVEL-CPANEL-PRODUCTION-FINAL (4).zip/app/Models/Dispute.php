<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class Dispute extends Model {
    use HasFactory;
    use SoftDeletes;
    protected $fillable = [
        'dispute_id', 'payment_id', 'project_id', 'client_id', 'case_number', 'source',
        'reason_code', 'reason', 'disputed_amount', 'status', 'respond_by', 'submitted_at',
        'evidence_package_path', 'evidence_package_hash', 'compiled_by', 'resolved_by',
        'resolved_at', 'resolution_notes',
    ];
    protected $casts = [
        'respond_by' => 'datetime',
        'submitted_at' => 'datetime',
        'resolved_at' => 'datetime',
    ];

    public function payment() { return $this->belongsTo(Payment::class); }
    public function project() { return $this->belongsTo(Project::class); }
    public function client() { return $this->belongsTo(Client::class); }
    public function compiler() { return $this->belongsTo(User::class, 'compiled_by'); }
    public function resolver() { return $this->belongsTo(User::class, 'resolved_by'); }

    /**
     * Auto-compile evidence package from all related records.
     * Returns array of evidence item descriptions.
     */
    public function compileEvidencePackage(): array {
        $items = [];

        // 1. All evidence vault entries for this project/client
        $vaultItems = EvidenceVault::where('project_id', $this->project_id)
            ->orWhere('client_id', $this->client_id)
            ->orderBy('event_at')
            ->get();
        foreach ($vaultItems as $item) {
            $items[] = [
                'type' => $item->type,
                'title' => $item->title,
                'description' => $item->description,
                'file_hash' => $item->file_hash,
                'event_at' => $item->event_at?->toISOString(),
                'source' => 'evidence_vault',
            ];
        }

        // 2. Payment records
        if ($this->payment_id) {
            $payment = $this->payment;
            $items[] = [
                'type' => 'payment',
                'title' => 'Payment Record #' . $payment->id,
                'description' => "Amount: {$payment->amount} {$payment->currency}, Status: {$payment->status}",
                'event_at' => $payment->created_at?->toISOString(),
                'source' => 'payments_table',
            ];
        }

        // 3. Scope approval records
        $scopes = ScopeOfWork::where('project_id', $this->project_id)->get();
        foreach ($scopes as $scope) {
            $items[] = [
                'type' => 'contract',
                'title' => 'Scope of Work ' . $scope->scope_id,
                'description' => 'Version ' . $scope->version . ', Status: ' . $scope->status,
                'event_at' => $scope->approved_at?->toISOString() ?? $scope->created_at?->toISOString(),
                'source' => 'scope_of_works_table',
            ];
        }

        // 4. Delivery records
        $deliveries = Delivery::where('project_id', $this->project_id)->get();
        foreach ($deliveries as $delivery) {
            $items[] = [
                'type' => 'delivery',
                'title' => 'Delivery ' . $delivery->delivery_id,
                'description' => "QA: {$delivery->qa_status}, Admin Approval: {$delivery->admin_approval}",
                'event_at' => $delivery->created_at?->toISOString(),
                'source' => 'deliveries_table',
            ];
        }

        // 5. Audit logs
        $logs = AuditLog::where('project_id', $this->project_id)->orderBy('timestamp', 'desc')->limit(50)->get();
        foreach ($logs as $log) {
            $items[] = [
                'type' => 'audit',
                'title' => 'Audit: ' . $log->action,
                'description' => $log->details,
                'event_at' => $log->timestamp ?? $log->created_at?->toISOString(),
                'source' => 'audit_logs_table',
            ];
        }

        // Hash the compiled package
        $canonical = json_encode($items, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $this->evidence_package_hash = hash('sha256', $canonical);
        $this->status = 'evidence_compiled';
        $this->compiled_by = auth()->id();
        $this->save();

        return $items;
    }
}
