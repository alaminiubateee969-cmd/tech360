<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Company extends Model {
    use SoftDeletes;
    protected $fillable = ['name', 'email', 'phone', 'address', 'website', 'industry'];
    public function contacts() { return $this->hasMany(Contact::class); }
    public function deals() { return $this->hasMany(Deal::class); }
}
