<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ClientVerification extends Model {
    use HasFactory;
    protected $fillable = [
        'client_id', 'verification_type', 'status', 'token', 'channel', 'destination',
        'sent_at', 'verified_at', 'expires_at', 'ip_address', 'user_agent',
    ];
    protected $casts = [
        'sent_at' => 'datetime',
        'verified_at' => 'datetime',
        'expires_at' => 'datetime',
    ];

    public function client() { return $this->belongsTo(Client::class); }

    public static function generateToken(): string {
        return bin2hex(random_bytes(32));
    }

    public function isExpired(): bool {
        return $this->expires_at && $this->expires_at->isPast();
    }

    public function verify(string $token): bool {
        if ($this->status === 'verified') return true;
        if ($this->isExpired()) {
            $this->update(['status' => 'expired']);
            return false;
        }
        if (!hash_equals($this->token, $token)) return false;
        $this->update([
            'status' => 'verified',
            'verified_at' => now(),
            'ip_address' => request()?->ip(),
            'user_agent' => request()?->userAgent(),
        ]);
        return true;
    }
}
