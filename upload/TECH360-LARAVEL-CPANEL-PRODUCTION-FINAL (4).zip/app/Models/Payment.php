<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class Payment extends Model {
    use HasFactory;
    protected $fillable = ['invoice_id', 'project_id', 'client_id', 'amount', 'currency', 'status', 'provider', 'provider_transaction_id', 'verified_by', 'verified_at', 'failure_reason'];
    protected $casts = ['verified_at' => 'datetime'];
    public function project() { return $this->belongsTo(Project::class); }
    public function client() { return $this->belongsTo(Client::class); }
}
