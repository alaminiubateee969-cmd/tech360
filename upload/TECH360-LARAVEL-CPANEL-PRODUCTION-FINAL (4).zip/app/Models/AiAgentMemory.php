<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class AiAgentMemory extends Model {
    protected $fillable = ['ai_agent_id', 'type', 'key', 'value', 'contact_id', 'expires_at'];
    protected $casts = ['expires_at' => 'datetime'];
    public function agent() { return $this->belongsTo(AiAgent::class); }
    public function contact() { return $this->belongsTo(Contact::class); }
}
