<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class AiAgentMessage extends Model {
    protected $fillable = ['ai_agent_execution_id', 'role', 'content', 'tool_name', 'tool_input', 'tool_output'];
    protected $casts = ['tool_input' => 'array', 'tool_output' => 'array'];
    public function execution() { return $this->belongsTo(AiAgentExecution::class); }
}
