<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class AiApproval extends Model {
    use HasFactory;
    protected $fillable = ['approval_id', 'ai_agent_id', 'ai_agent_execution_id', 'user_id', 'action', 'target_type', 'target_id', 'reason', 'generated_content', 'risk_level', 'status', 'reviewer_id', 'reviewed_at', 'review_note', 'execution_result'];
    protected $casts = ['reviewed_at' => 'datetime'];
    public function agent() { return $this->belongsTo(AiAgent::class); }
    public function execution() { return $this->belongsTo(AiAgentExecution::class); }
}
