<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
class LeadCrm extends Model {
    use HasFactory;
    use SoftDeletes;
    protected $table = 'leads_crm';
    protected $fillable = ['lead_id', 'contact_id', 'service_interest', 'source', 'campaign', 'utm_source', 'utm_medium', 'utm_campaign', 'score', 'status', 'assigned_to', 'notes'];
    public function contact() { return $this->belongsTo(Contact::class); }
    public function assignedTo() { return $this->belongsTo(User::class, 'assigned_to'); }
}
