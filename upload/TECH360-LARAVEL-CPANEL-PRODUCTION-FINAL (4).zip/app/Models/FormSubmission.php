<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class FormSubmission extends Model {
    protected $fillable = ['form_type', 'name', 'email', 'phone', 'company', 'message', 'service_interest', 'source_page', 'utm_source', 'utm_medium', 'utm_campaign', 'contact_id', 'ip_address', 'user_agent'];
}
