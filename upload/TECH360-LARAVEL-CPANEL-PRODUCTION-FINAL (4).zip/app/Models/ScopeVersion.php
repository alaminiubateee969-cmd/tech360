<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class ScopeVersion extends Model {
    protected $fillable = ['scope_id', 'version', 'content_snapshot', 'changes', 'created_by'];
    public function scope() { return $this->belongsTo(ScopeOfWork::class, 'scope_id'); }
}
