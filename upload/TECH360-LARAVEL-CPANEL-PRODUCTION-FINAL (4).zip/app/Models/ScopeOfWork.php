<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
class ScopeOfWork extends Model {
    use HasFactory;
    use SoftDeletes;
    protected $table = 'scope_of_works';
    protected $fillable = ['scope_id', 'project_id', 'version', 'title', 'objective', 'features_included', 'features_excluded', 'timeline', 'payment_amount', 'payment_terms', 'deliverables', 'revision_allowance', 'status', 'terms_accepted', 'refund_policy_accepted', 'preview_acknowledged', 'immutable_snapshot', 'approved_by', 'approved_at'];
    protected $casts = ['features_included' => 'array', 'features_excluded' => 'array', 'deliverables' => 'array', 'approved_at' => 'datetime'];
    public function project() { return $this->belongsTo(Project::class); }
    public function versions() { return $this->hasMany(ScopeVersion::class); }
    public function approvals() { return $this->hasMany(ScopeApproval::class); }
}
