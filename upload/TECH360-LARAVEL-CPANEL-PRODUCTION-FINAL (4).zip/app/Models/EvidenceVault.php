<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;

class EvidenceVault extends Model {
    use HasFactory;
    use SoftDeletes;
    protected $table = 'evidence_vault';
    protected $fillable = [
        'evidence_id', 'type', 'project_id', 'client_id', 'title', 'description',
        'file_path', 'file_hash', 'content_hash', 'metadata', 'event_at', 'uploaded_by',
        'is_locked', 'permanent_delete_blocked',
    ];
    protected $casts = [
        'event_at' => 'datetime',
        'is_locked' => 'boolean',
        'permanent_delete_blocked' => 'boolean',
        'metadata' => 'array',
    ];

    public const TYPE_COMMUNICATION = 'communication';
    public const TYPE_PAYMENT = 'payment';
    public const TYPE_CONTRACT = 'contract';
    public const TYPE_INVOICE = 'invoice';
    public const TYPE_DELIVERY = 'delivery';
    public const TYPE_ACCEPTANCE = 'acceptance';
    public const TYPE_PAYOUT = 'payout';
    public const TYPE_REFUND = 'refund';
    public const TYPE_DISPUTE = 'dispute';
    public const TYPE_AUDIT = 'audit';
    public const TYPE_SOURCE_RELEASE = 'source_release';
    public const TYPE_HANDOVER = 'handover';

    public function project() { return $this->belongsTo(Project::class); }
    public function client() { return $this->belongsTo(Client::class); }
    public function uploader() { return $this->belongsTo(User::class, 'uploaded_by'); }

    /**
     * No-delete policy: locked evidence cannot be hard-deleted.
     * Override delete() to enforce soft-delete only.
     */
    public function delete(): bool {
        if ($this->permanent_delete_blocked && $this->is_locked) {
            // Force soft-delete only — preserve the record
            return $this->forceSoftDelete();
        }
        return parent::delete();
    }

    public function forceSoftDelete(): bool {
        $this->runSoftDelete();
        return true;
    }

    /**
     * Compute and store SHA-256 hash of attached file.
     */
    public function computeFileHash(): ?string {
        if (!$this->file_path) return null;
        $disk = Storage::disk('private');
        if (!$disk->exists($this->file_path)) return null;
        $hash = hash_file('sha256', $disk->path($this->file_path));
        $this->file_hash = $hash;
        $this->save();
        return $hash;
    }

    /**
     * Verify the attached file against the stored hash.
     * Returns 'verified', 'tampered', or 'missing'.
     */
    public function verifyIntegrity(): string {
        if (!$this->file_path) return 'missing';
        $disk = Storage::disk('private');
        if (!$disk->exists($this->file_path)) return 'missing';
        $currentHash = hash_file('sha256', $disk->path($this->file_path));
        if (!$this->file_hash) {
            $this->file_hash = $currentHash;
            $this->save();
            return 'verified';
        }
        return hash_equals($this->file_hash, $currentHash) ? 'verified' : 'tampered';
    }
}
