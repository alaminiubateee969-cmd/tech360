<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class ScopeApproval extends Model {
    protected $fillable = ['approval_id', 'client_id', 'project_id', 'scope_id', 'scope_version', 'terms_version', 'refund_policy_version', 'approval_method', 'ip_address', 'user_agent', 'user_id', 'approved_at', 'immutable_snapshot'];
    protected $casts = ['approved_at' => 'datetime'];
}
