<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
class Project extends Model {
    use HasFactory;
    use SoftDeletes;
    protected $fillable = ['project_id', 'name', 'client_id', 'commercial_state', 'budget', 'description', 'start_date', 'end_date'];
    public function client() { return $this->belongsTo(Client::class); }
    public function scopes() { return $this->hasMany(ScopeOfWork::class); }
    public function payments() { return $this->hasMany(Payment::class); }
    public function deliveries() { return $this->hasMany(Delivery::class); }
    public function tasks() { return $this->hasMany(ProjectTask::class); }
    public function milestones() { return $this->hasMany(ProjectMilestone::class); }
}
