<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Invoice extends Model {
    protected $fillable = ['invoice_number', 'client_id', 'project_id', 'amount', 'currency', 'tax', 'total', 'status', 'due_date', 'paid_at', 'items', 'notes'];
    protected $casts = ['due_date' => 'date', 'paid_at' => 'datetime', 'items' => 'array'];
    public function client() { return $this->belongsTo(Client::class); }
    public function project() { return $this->belongsTo(Project::class); }
    public function payments() { return $this->hasMany(Payment::class); }
}
