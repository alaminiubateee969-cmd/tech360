<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class Delivery extends Model {
    use HasFactory;
    protected $fillable = ['delivery_id', 'project_id', 'client_id', 'payment_status', 'qa_status', 'admin_approval', 'admin_approved_by', 'admin_approved_at', 'package_hash', 'storage_path', 'signed_url', 'access_token', 'signed_url_expiry', 'client_confirmed', 'client_confirmed_at', 'password_rotation_complete', 'access_status'];
    protected $casts = ['admin_approved_at' => 'datetime', 'signed_url_expiry' => 'datetime', 'client_confirmed_at' => 'datetime'];
    public function project() { return $this->belongsTo(Project::class); }
    public function client() { return $this->belongsTo(Client::class); }
}
