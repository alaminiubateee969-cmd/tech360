<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class IntegrityRecord extends Model {
    use HasFactory;
    protected $fillable = [
        'record_id', 'entity_type', 'entity_id', 'algorithm', 'hash',
        'signed_payload', 'salt', 'created_by', 'verification_status', 'verified_at', 'tamper_note',
    ];
    protected $casts = [
        'verified_at' => 'datetime',
    ];

    /**
     * Create an integrity record for any entity (contract, invoice, delivery, etc.)
     * Uses canonical JSON + salt + SHA-256.
     */
    public static function seal(string $entityType, int $entityId, array $payload, ?int $userId = null): self {
        $salt = bin2hex(random_bytes(32));
        $canonical = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_SORT_KEYS);
        $signedPayload = $canonical . '|' . $salt;
        $hash = hash('sha256', $signedPayload);

        $count = self::count();
        return self::create([
            'record_id' => 'INT-' . date('Y') . '-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT),
            'entity_type' => $entityType,
            'entity_id' => $entityId,
            'algorithm' => 'sha256',
            'hash' => $hash,
            'signed_payload' => $signedPayload,
            'salt' => $salt,
            'created_by' => $userId,
            'verification_status' => 'verified',
            'verified_at' => now(),
        ]);
    }

    /**
     * Verify an entity against its sealed record.
     */
    public static function verify(string $entityType, int $entityId, array $payload): string {
        $record = self::where('entity_type', $entityType)->where('entity_id', $entityId)->latest()->first();
        if (!$record) return 'unknown';

        $canonical = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_SORT_KEYS);
        $signedPayload = $canonical . '|' . $record->salt;
        $currentHash = hash('sha256', $signedPayload);

        if (hash_equals($record->hash, $currentHash)) return 'verified';

        $record->update([
            'verification_status' => 'tampered',
            'tamper_note' => 'Payload mismatch detected at ' . now()->toISOString(),
        ]);
        return 'tampered';
    }
}
