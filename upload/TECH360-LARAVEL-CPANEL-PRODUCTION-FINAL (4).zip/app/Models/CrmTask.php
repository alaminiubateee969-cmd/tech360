<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class CrmTask extends Model {
    protected $table = 'crm_tasks';
    protected $fillable = ['title', 'description', 'entity_type', 'entity_id', 'contact_id', 'assigned_to', 'priority', 'status', 'due_date', 'completed_at'];
    protected $casts = ['due_date' => 'date', 'completed_at' => 'datetime'];
    public function contact() { return $this->belongsTo(Contact::class); }
    public function assignedTo() { return $this->belongsTo(User::class, 'assigned_to'); }
}
