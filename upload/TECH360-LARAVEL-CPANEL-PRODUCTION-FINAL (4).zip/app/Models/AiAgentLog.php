<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class AiAgentLog extends Model {
    protected $fillable = ['ai_agent_id', 'ai_agent_execution_id', 'level', 'action', 'message', 'metadata', 'user_id'];
    protected $casts = ['metadata' => 'array'];
    public function agent() { return $this->belongsTo(AiAgent::class); }
    public function execution() { return $this->belongsTo(AiAgentExecution::class); }
}
