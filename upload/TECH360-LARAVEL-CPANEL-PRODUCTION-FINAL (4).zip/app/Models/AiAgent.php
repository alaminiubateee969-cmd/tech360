<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class AiAgent extends Model {
    use HasFactory;
    protected $fillable = ['agent_id', 'name', 'slug', 'description', 'instructions', 'provider', 'model', 'mode', 'status', 'config'];
    protected $casts = ['config' => 'array'];
    public function skills() { return $this->hasMany(AiAgentSkill::class); }
    public function tools() { return $this->belongsToMany(AiAgentTool::class, 'ai_agent_permissions'); }
    public function memories() { return $this->hasMany(AiAgentMemory::class); }
    public function executions() { return $this->hasMany(AiAgentExecution::class); }
    public function logs() { return $this->hasMany(AiAgentLog::class); }
    public function approvals() { return $this->hasMany(AiApproval::class); }
}
