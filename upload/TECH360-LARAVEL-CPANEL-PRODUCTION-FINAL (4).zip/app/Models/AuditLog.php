<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class AuditLog extends Model {
    public $timestamps = false;
    protected $table = 'audit_logs';
    protected $fillable = ['client_id', 'project_id', 'scope_id', 'payment_id', 'action', 'actor_type', 'actor_id', 'details', 'ip_address', 'user_agent', 'timestamp'];
    protected $casts = ['details' => 'array', 'timestamp' => 'datetime'];
}
