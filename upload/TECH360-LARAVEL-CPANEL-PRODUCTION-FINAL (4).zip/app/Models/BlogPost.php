<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class BlogPost extends Model {
    protected $fillable = ['slug', 'title', 'excerpt', 'content', 'featured_image', 'category', 'tags', 'author', 'seo_title', 'seo_description', 'status', 'published_at'];
    protected $casts = ['published_at' => 'datetime'];
    public function scopePublished() { return $this->where('status', 'published')->where('published_at', '<=', now()); }
}
