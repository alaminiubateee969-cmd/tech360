<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class AiAgentSkill extends Model {
    protected $fillable = ['ai_agent_id', 'name', 'description', 'enabled'];
    protected $casts = ['enabled' => 'boolean'];
    public function agent() { return $this->belongsTo(AiAgent::class); }
}
