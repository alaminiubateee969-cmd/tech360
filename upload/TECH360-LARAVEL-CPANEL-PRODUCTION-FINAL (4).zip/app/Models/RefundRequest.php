<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class RefundRequest extends Model {
    protected $fillable = ['refund_id', 'client_id', 'project_id', 'invoice_number', 'payment_reference', 'payment_date', 'reason', 'description', 'status', 'reviewed_by', 'reviewed_at', 'decision', 'resolution'];
    protected $casts = ['payment_date' => 'date', 'reviewed_at' => 'datetime'];
    public function client() { return $this->belongsTo(Client::class); }
}
