<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
class Contact extends Model {
    use HasFactory;
    use SoftDeletes;
    protected $fillable = ['contact_id', 'first_name', 'last_name', 'email', 'phone', 'company_id', 'source', 'tags', 'status', 'notes', 'assigned_to'];
    public function company() { return $this->belongsTo(Company::class); }
    public function assignedTo() { return $this->belongsTo(User::class, 'assigned_to'); }
    public function leads() { return $this->hasMany(LeadCrm::class); }
    public function deals() { return $this->hasMany(Deal::class); }
    public function activities() { return $this->hasMany(Activity::class); }
    public function communications() { return $this->hasMany(Communication::class); }
    public function tasks() { return $this->hasMany(CrmTask::class); }
    public function getFullNameAttribute() { return trim($this->first_name . ' ' . $this->last_name); }
}
