<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class CommunicationChannel extends Model {
    use HasFactory;
    use SoftDeletes;
    protected $fillable = [
        'channel_id', 'client_id', 'contact_id', 'primary_channel', 'whatsapp_number',
        'email_address', 'phone_number', 'email_collected', 'email_verified',
        'whatsapp_verified', 'bd_manager_id', 'first_contact_at', 'client_identifier', 'notes',
    ];
    protected $casts = [
        'email_collected' => 'boolean',
        'email_verified' => 'boolean',
        'whatsapp_verified' => 'boolean',
        'first_contact_at' => 'datetime',
    ];

    public function client() { return $this->belongsTo(Client::class); }
    public function contact() { return $this->belongsTo(Contact::class); }
    public function bdManager() { return $this->belongsTo(User::class, 'bd_manager_id'); }

    /**
     * Generate the next TECH-CL-XXXXXX client identifier.
     * Called when first WhatsApp contact is logged.
     */
    public static function generateClientIdentifier(): string {
        $count = self::whereNotNull('client_identifier')->count();
        return 'TECH-CL-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT);
    }

    /**
     * WhatsApp-first contact flow:
     * 1. Lead contacts via WhatsApp
     * 2. System auto-requests email
     * 3. Email verified → client_id assigned
     */
    public function requestEmailCollection(): void {
        if (!$this->email_collected && $this->whatsapp_verified) {
            // Trigger email request workflow
            $this->update(['email_collected' => false]);
            // (In production: dispatch job to send WhatsApp template asking for email)
        }
    }

    public function assignClientIdentifier(): ?string {
        if ($this->email_verified && !$this->client_identifier) {
            $this->client_identifier = self::generateClientIdentifier();
            $this->save();
            return $this->client_identifier;
        }
        return null;
    }
}
