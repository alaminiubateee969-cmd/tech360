<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class AiJob extends Model {
    protected $table = 'ai_jobs';
    protected $fillable = ['job_id', 'job_type', 'client_id', 'project_id', 'agent_name', 'status', 'input', 'result', 'error', 'started_at', 'completed_at'];
    protected $casts = ['started_at' => 'datetime', 'completed_at' => 'datetime'];
}
