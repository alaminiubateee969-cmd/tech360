<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class QaRecord extends Model {
    protected $fillable = ['project_id', 'checklist_item', 'status', 'notes', 'checked_by', 'checked_at'];
    protected $casts = ['checked_at' => 'datetime'];
    public function project() { return $this->belongsTo(Project::class); }
}
