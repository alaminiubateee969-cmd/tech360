<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
class Deal extends Model {
    use HasFactory;
    use SoftDeletes;
    protected $fillable = ['deal_id', 'title', 'contact_id', 'company_id', 'value', 'stage', 'probability', 'expected_close_date', 'assigned_to', 'notes'];
    protected $casts = ['expected_close_date' => 'date'];
    public function contact() { return $this->belongsTo(Contact::class); }
    public function company() { return $this->belongsTo(Company::class); }
    public function assignedTo() { return $this->belongsTo(User::class, 'assigned_to'); }
}
