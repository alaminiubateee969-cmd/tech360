<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class AiAgentPermission extends Model {
    protected $fillable = ['ai_agent_id', 'ai_agent_tool_id', 'allowed'];
    protected $casts = ['allowed' => 'boolean'];
}
