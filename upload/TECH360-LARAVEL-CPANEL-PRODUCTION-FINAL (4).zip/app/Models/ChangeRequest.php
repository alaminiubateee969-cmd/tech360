<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class ChangeRequest extends Model {
    protected $fillable = ['project_id', 'description', 'details', 'estimated_cost', 'estimated_time', 'status', 'requested_by'];
    public function project() { return $this->belongsTo(Project::class); }
}
