<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class AiAgentTool extends Model {
    use HasFactory;
    protected $fillable = ['name', 'slug', 'description', 'input_schema', 'output_schema', 'handler_class', 'category', 'risk_level', 'enabled'];
    protected $casts = ['input_schema' => 'array', 'output_schema' => 'array', 'enabled' => 'boolean'];
    public function agents() { return $this->belongsToMany(AiAgent::class, 'ai_agent_permissions'); }
}
