<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Communication extends Model {
    protected $fillable = ['contact_id', 'channel', 'direction', 'subject', 'body', 'user_id'];
    public function contact() { return $this->belongsTo(Contact::class); }
    public function user() { return $this->belongsTo(User::class); }
}
