<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class AiAgentExecution extends Model {
    use HasFactory;
    protected $fillable = ['execution_id', 'ai_agent_id', 'user_id', 'input', 'output', 'status', 'provider', 'model', 'tokens_input', 'tokens_output', 'error', 'started_at', 'completed_at'];
    protected $casts = ['started_at' => 'datetime', 'completed_at' => 'datetime'];
    public function agent() { return $this->belongsTo(AiAgent::class); }
    public function messages() { return $this->hasMany(AiAgentMessage::class); }
    public function logs() { return $this->hasMany(AiAgentLog::class); }
    public function approvals() { return $this->hasMany(AiApproval::class); }
}
