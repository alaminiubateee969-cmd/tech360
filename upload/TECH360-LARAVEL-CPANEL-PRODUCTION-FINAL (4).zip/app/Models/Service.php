<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Service extends Model {
    protected $fillable = ['slug', 'title', 'icon', 'image', 'short_description', 'description', 'features', 'benefits', 'seo_title', 'seo_description', 'is_active', 'sort_order'];
    protected $casts = ['features' => 'array', 'benefits' => 'array', 'is_active' => 'boolean'];
}
