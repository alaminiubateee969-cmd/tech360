<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class AiKnowledgeDocument extends Model {
    use HasFactory;
    protected $fillable = ['title', 'category', 'content', 'tags', 'is_active', 'created_by'];
    protected $casts = ['tags' => 'array', 'is_active' => 'boolean'];
}
