<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Portfolio extends Model {
    protected $table = 'portfolio';
    protected $fillable = ['slug', 'title', 'client_name', 'industry', 'image', 'screenshot', 'technology', 'services_delivered', 'description', 'results', 'seo_title', 'seo_description', 'is_featured', 'is_active', 'sort_order'];
    protected $casts = ['services_delivered' => 'array', 'is_featured' => 'boolean', 'is_active' => 'boolean'];
}
