<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class ProjectMilestone extends Model {
    protected $fillable = ['project_id', 'name', 'description', 'order', 'status', 'due_date', 'completed_at'];
    protected $casts = ['due_date' => 'date', 'completed_at' => 'datetime'];
    public function project() { return $this->belongsTo(Project::class); }
}
