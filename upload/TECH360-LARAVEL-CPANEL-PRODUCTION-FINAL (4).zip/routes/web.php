<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\ScopeController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\DeliveryController;
use App\Http\Controllers\RefundController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AiController;
use App\Http\Controllers\CrmController;
use App\Http\Controllers\CmsController;

// === PUBLIC WEBSITE ===
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/about', [HomeController::class, 'about'])->name('about');
Route::get('/services', [HomeController::class, 'services'])->name('services');
Route::get('/services/{slug}', [HomeController::class, 'serviceDetail'])->name('service.detail');
Route::get('/industries', [HomeController::class, 'industries'])->name('industries');
Route::get('/portfolio', [HomeController::class, 'portfolio'])->name('portfolio');
Route::get('/portfolio/{slug}', [HomeController::class, 'portfolioDetail'])->name('portfolio.detail');
Route::get('/case-studies', [HomeController::class, 'caseStudies'])->name('case-studies');
Route::get('/blog', [HomeController::class, 'blog'])->name('blog');
Route::get('/blog/{slug}', [HomeController::class, 'blogPost'])->name('blog.post');
Route::get('/pricing', [HomeController::class, 'pricing'])->name('pricing');
Route::get('/contact', [HomeController::class, 'contact'])->name('contact');
Route::post('/contact', [HomeController::class, 'submitContact'])->middleware('throttle:5,10')->name('contact.submit');
Route::post('/ai-chat', [HomeController::class, 'aiChat'])->middleware('throttle:20,1')->name('public.ai.chat');
Route::get('/terms', [HomeController::class, 'terms'])->name('terms');
Route::get('/refund-policy', [HomeController::class, 'refundPolicy'])->name('refund-policy');
Route::get('/privacy-policy', [HomeController::class, 'privacyPolicy'])->name('privacy-policy');
Route::get('/cookie-policy', [HomeController::class, 'cookiePolicy'])->name('cookie-policy');

// === AUTH ===
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:5,1')->name('login.post');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
Route::post('/register', [AuthController::class, 'register'])->middleware('throttle:3,60')->name('register.post');

// === CLIENT PORTAL ===
Route::middleware(['auth'])->prefix('client')->group(function () {
    Route::get('/dashboard', [ClientController::class, 'dashboard'])->name('client.dashboard');
    Route::get('/projects/{project}/scope', [ScopeController::class, 'show'])->name('client.scope');
    Route::post('/projects/{project}/scope/approve', [ScopeController::class, 'approve'])->name('client.scope.approve');
    Route::post('/projects/{project}/scope/change', [ScopeController::class, 'requestChange'])->name('client.scope.change');
    Route::get('/projects/{project}/preview', [ProjectController::class, 'preview'])->name('client.preview');
    Route::get('/projects/{project}/payment', [PaymentController::class, 'show'])->name('client.payment');
    Route::post('/projects/{project}/payment', [PaymentController::class, 'process'])->name('client.payment.process');
    Route::get('/projects/{project}/handover', [DeliveryController::class, 'show'])->name('client.handover');
    Route::post('/projects/{project}/delivery-confirm', [DeliveryController::class, 'confirmDelivery'])->name('client.delivery.confirm');
    Route::get('/projects/{project}/download', [DeliveryController::class, 'download'])->name('client.download');
    Route::get('/refund-request', [RefundController::class, 'showForm'])->name('client.refund.form');
    Route::post('/refund-request', [RefundController::class, 'submit'])->name('client.refund.submit');
});

// === WEBHOOKS (CSRF-exempt, rate-limited, HMAC-verified) ===
Route::post('/webhook/payment', [PaymentController::class, 'webhook'])->middleware('throttle:60,1')->name('payment.webhook');
Route::post('/webhook/ai', [AiController::class, 'webhook'])->middleware('throttle:60,1')->name('ai.webhook')->withoutMiddleware(['csrf']);

// === CRM (auth + admin/staff) ===
Route::middleware(['auth', 'admin'])->prefix('crm')->group(function () {
    Route::get('/dashboard', [CrmController::class, 'dashboard'])->name('crm.dashboard');
    Route::get('/contacts', [CrmController::class, 'contacts'])->name('crm.contacts');
    Route::get('/contacts/{id}', [CrmController::class, 'showContact'])->name('crm.contacts.show');
    Route::post('/contacts', [CrmController::class, 'storeContact'])->name('crm.contacts.store');
    Route::post('/contacts/{id}/communication', [CrmController::class, 'addCommunication'])->name('crm.communication.add');
    Route::get('/leads', [CrmController::class, 'leads'])->name('crm.leads');
    Route::post('/leads', [CrmController::class, 'storeLead'])->name('crm.leads.store');
    Route::get('/deals', [CrmController::class, 'deals'])->name('crm.deals');
    Route::post('/deals', [CrmController::class, 'storeDeal'])->name('crm.deals.store');
    Route::get('/tasks', [CrmController::class, 'tasks'])->name('crm.tasks');
    Route::post('/tasks', [CrmController::class, 'storeTask'])->name('crm.tasks.store');
});

// === ADMIN ===
Route::middleware(['auth', 'admin'])->prefix('admin')->group(function () {
    Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('admin.dashboard');
    Route::get('/clients', [AdminController::class, 'clients'])->name('admin.clients');
    Route::get('/projects', [AdminController::class, 'projects'])->name('admin.projects');
    Route::get('/payments', [AdminController::class, 'payments'])->name('admin.payments');
    Route::post('/payments/{id}/verify', [AdminController::class, 'verifyPayment'])->name('admin.payment.verify');
    Route::get('/refunds', [AdminController::class, 'refunds'])->name('admin.refunds');
    Route::post('/refunds/{id}/review', [AdminController::class, 'reviewRefund'])->name('admin.refund.review');
    Route::post('/projects/{id}/handover', [AdminController::class, 'releaseHandover'])->name('admin.handover.release');
    Route::get('/audit-logs', [AdminController::class, 'auditLogs'])->name('admin.audit');
    Route::get('/ai-command-center', [AdminController::class, 'aiCommandCenter'])->name('admin.ai');
    // CMS
    Route::get('/cms/services', [CmsController::class, 'services'])->name('admin.cms.services');
    Route::post('/cms/services', [CmsController::class, 'storeService'])->name('admin.cms.services.store');
    Route::get('/cms/portfolio', [CmsController::class, 'portfolio'])->name('admin.cms.portfolio');
    Route::post('/cms/portfolio', [CmsController::class, 'storePortfolio'])->name('admin.cms.portfolio.store');
    Route::get('/cms/blog', [CmsController::class, 'blog'])->name('admin.cms.blog');
    Route::post('/cms/blog', [CmsController::class, 'storeBlog'])->name('admin.cms.blog.store');
    Route::get('/cms/testimonials', [CmsController::class, 'testimonials'])->name('admin.cms.testimonials');
    Route::post('/cms/testimonials', [CmsController::class, 'storeTestimonial'])->name('admin.cms.testimonials.store');
    Route::get('/cms/settings', [CmsController::class, 'settings'])->name('admin.cms.settings');
    Route::post('/cms/settings', [CmsController::class, 'storeSetting'])->name('admin.cms.settings.store');
    Route::get('/cms/form-submissions', [CmsController::class, 'formSubmissions'])->name('admin.cms.submissions');
    // Payouts
    Route::get('/payouts', [App\Http\Controllers\PayoutController::class, 'index'])->name('admin.payouts.index');
    Route::get('/payouts/create', [App\Http\Controllers\PayoutController::class, 'create'])->name('admin.payouts.create');
    Route::post('/payouts', [App\Http\Controllers\PayoutController::class, 'store'])->name('admin.payouts.store');
    Route::post('/payouts/{payout}/approve', [App\Http\Controllers\PayoutController::class, 'approve'])->name('admin.payouts.approve');
    Route::post('/payouts/{payout}/process', [App\Http\Controllers\PayoutController::class, 'markProcessed'])->name('admin.payouts.process');
    // Evidence Vault
    Route::get('/evidence', [App\Http\Controllers\EvidenceVaultController::class, 'index'])->name('admin.evidence.index');
    Route::get('/evidence/{evidence}', [App\Http\Controllers\EvidenceVaultController::class, 'show'])->name('admin.evidence.show');
    Route::post('/evidence', [App\Http\Controllers\EvidenceVaultController::class, 'store'])->name('admin.evidence.store');
    Route::post('/evidence/{evidence}/verify', [App\Http\Controllers\EvidenceVaultController::class, 'verify'])->name('admin.evidence.verify');
    Route::post('/evidence/{evidence}/soft-delete', [App\Http\Controllers\EvidenceVaultController::class, 'softDelete'])->name('admin.evidence.soft-delete');
    Route::get('/evidence/{evidence}/download', [App\Http\Controllers\EvidenceVaultController::class, 'download'])->name('admin.evidence.download');
    // Disputes
    Route::get('/disputes', [App\Http\Controllers\DisputeController::class, 'index'])->name('admin.disputes.index');
    Route::get('/disputes/create', [App\Http\Controllers\DisputeController::class, 'create'])->name('admin.disputes.create');
    Route::post('/disputes', [App\Http\Controllers\DisputeController::class, 'store'])->name('admin.disputes.store');
    Route::get('/disputes/{dispute}', [App\Http\Controllers\DisputeController::class, 'show'])->name('admin.disputes.show');
    Route::post('/disputes/{dispute}/compile', [App\Http\Controllers\DisputeController::class, 'compileEvidence'])->name('admin.disputes.compile');
    Route::post('/disputes/{dispute}/resolve', [App\Http\Controllers\DisputeController::class, 'resolve'])->name('admin.disputes.resolve');
});

// === AI AGENT ROUTES (admin only) ===
Route::middleware(['auth', 'admin'])->prefix('admin/ai')->group(function () {
    Route::get('/dashboard', [App\Http\Controllers\AiAgentController::class, 'dashboard'])->name('admin.ai.dashboard');
    Route::get('/agents', [App\Http\Controllers\AiAgentController::class, 'index'])->name('admin.ai.agents');
    Route::post('/agents', [App\Http\Controllers\AiAgentController::class, 'store'])->name('admin.ai.agents.store');
    Route::get('/agents/{aiAgent}', [App\Http\Controllers\AiAgentController::class, 'show'])->name('admin.ai.agents.show');
    Route::post('/agents/{aiAgent}/toggle', [App\Http\Controllers\AiAgentController::class, 'toggleStatus'])->name('admin.ai.agents.toggle');
    Route::post('/agents/{aiAgent}/execute', [App\Http\Controllers\AiAgentController::class, 'execute'])->name('admin.ai.agents.execute');
    Route::get('/approvals', [App\Http\Controllers\AiAgentController::class, 'approvals'])->name('admin.ai.approvals');
    Route::post('/approvals/{approval}/approve', [App\Http\Controllers\AiAgentController::class, 'approveRequest'])->name('admin.ai.approvals.approve');
    Route::post('/approvals/{approval}/reject', [App\Http\Controllers\AiAgentController::class, 'rejectRequest'])->name('admin.ai.approvals.reject');
    Route::get('/knowledge', [App\Http\Controllers\AiAgentController::class, 'knowledge'])->name('admin.ai.knowledge');
    Route::post('/knowledge', [App\Http\Controllers\AiAgentController::class, 'storeKnowledge'])->name('admin.ai.knowledge.store');
    Route::get('/workflows', [App\Http\Controllers\AiAgentController::class, 'workflows'])->name('admin.ai.workflows');
    Route::post('/workflows', [App\Http\Controllers\AiAgentController::class, 'storeWorkflow'])->name('admin.ai.workflows.store');
    Route::get('/logs', [App\Http\Controllers\AiAgentController::class, 'logs'])->name('admin.ai.logs');
    Route::post('/command', [App\Http\Controllers\AiAgentController::class, 'command'])->middleware('throttle:20,1')->name('admin.ai.command');
});
