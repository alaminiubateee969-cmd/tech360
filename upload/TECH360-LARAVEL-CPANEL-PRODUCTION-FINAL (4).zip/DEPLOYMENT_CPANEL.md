# TECH360 LLC — cPanel Production Deployment Guide

> Stack: Laravel 11.x • PHP 8.2+ • MySQL 8 / MariaDB 10.4+ • Apache/cPanel
> No Node.js required. No Docker required. No Redis required. No Supervisor required.

---

## Prerequisites

- cPanel shared hosting or VPS with cPanel/WHM
- PHP 8.2 or higher (set in cPanel → MultiPHP Manager)
- MySQL 8.0+ or MariaDB 10.4+
- SSL certificate (Let's Encrypt via cPanel is fine)
- 1 GB minimum disk space (vendor/ + storage/ + images)

---

## Step-by-Step Deployment

### 1. Upload the ZIP

1. Log into cPanel → **File Manager**
2. Navigate to your domain's directory (e.g., `public_html/` or a subdirectory)
3. Click **Upload** and select `tech360-laravel-cpanel-production-final.zip`
4. Once uploaded, right-click → **Extract**
5. You should now have a folder named `tech360-laravel/`

### 2. Configure the Database

1. cPanel → **MySQL® Database Wizard**
2. Create database: `tech360_prod` (cPanel prefixes with your username: `username_tech360_prod`)
3. Create user: `tech360_user` with a strong password (save it!)
4. Grant **ALL PRIVILEGES** to the user on the database

### 3. Configure .env

1. In File Manager, navigate into `tech360-laravel/`
2. Copy `.env.example` to `.env` (right-click → Copy)
3. Right-click `.env` → **Edit**
4. Set the following:

```env
APP_NAME="TECH360"
APP_ENV=production
APP_DEBUG=false
APP_URL=https://your-domain.com

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=username_tech360_prod
DB_USERNAME=username_tech360_user
DB_PASSWORD=your_strong_password_here

SESSION_DRIVER=database
SESSION_ENCRYPT=true
SESSION_SECURE_COOKIE=true

MAIL_MAILER=smtp
MAIL_HOST=mail.your-domain.com
MAIL_PORT=587
MAIL_USERNAME=support@your-domain.com
MAIL_PASSWORD=your_mail_password
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=support@your-domain.com

AI_PROVIDER=openai
AI_MODEL=gpt-4o-mini
AI_API_KEY=sk-your-openai-key
AI_BASE_URL=https://api.openai.com/v1

PAYMENT_WEBHOOK_SECRET=generate_a_random_64_char_string
STRIPE_SECRET=sk_live_or_test_key
STRIPE_WEBHOOK_SECRET=whsec_your_stripe_webhook_secret
```

### 4. Set the Document Root

1. cPanel → **Domains** (or **Subdomains** if applicable)
2. Click **Manage** next to your domain
3. Set **Document Root** to: `/home/USERNAME/tech360-laravel/public`
4. Save

### 5. Set PHP Version

1. cPanel → **MultiPHP Manager**
2. Select your domain
3. Set PHP version to **8.2** or higher (8.3 recommended)

### 6. Run Migrations & Seeders

If you have SSH access:

```bash
cd /home/USERNAME/tech360-laravel
php artisan migrate --force
php artisan db:seed --force
php artisan key:generate --force
php artisan storage:link
```

If you do NOT have SSH access:

1. cPanel → **Terminal** (if available) — same commands work
2. OR: Use **phpMyAdmin** → Import → select files from `database/migrations/` in order
3. OR: Create a temporary `install.php` script in `public/` that calls `Artisan::call('migrate')` (delete after use!)

### 7. Set Permissions

In File Manager or via SSH:

```bash
chmod -R 775 storage bootstrap/cache
chmod -R 644 .env
```

### 8. Configure the Cron Job (REQUIRED)

Laravel's scheduler needs a single cron entry to run scheduled jobs.

1. cPanel → **Cron Jobs**
2. Under **Add New Cron Job**, set:
   - **Minute:** `*`
   - **Hour:** `*`
   - **Day:** `*`
   - **Month:** `*`
   - **Weekday:** `*`
3. **Command:**

```bash
/usr/local/bin/php /home/USERNAME/tech360-laravel/artisan schedule:run >> /dev/null 2>&1
```

> Replace `USERNAME` with your cPanel username.
> Replace `/usr/local/bin/php` with the path shown in cPanel → **MultiPHP Manager** → "PHP Path" if different.

### 9. Cache Optimization (Production)

```bash
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan event:cache
```

> ⚠️ After any `.env` change, run `php artisan config:cache` again.

### 10. Test the Deployment

- Visit `https://your-domain.com/` — homepage should load
- Visit `https://your-domain.com/login` — should load login page
- Visit `https://your-domain.com/robots.txt` — should return the robots.txt
- Visit `https://your-domain.com/sitemap.xml` — should return XML

### 11. Test the Admin Login

The default admin user is `admin@tech360.io` with a randomly generated password.
The password is printed to console output during seeding. To retrieve it:

```bash
php artisan tinker
>>> $u = User::where('email', 'admin@tech360.io')->first();
>>> // If you lost the password, reset it:
>>> $u->update(['password' => bcrypt('new-secure-password')]);
```

Or via SQL in phpMyAdmin:

```sql
UPDATE users SET password = '$2y$12$...' WHERE email = 'admin@tech360.io';
```

> ⚠️ **Change the admin password immediately after first login.**

### 12. Configure Stripe Webhooks (for payments)

1. Stripe Dashboard → Developers → Webhooks → **Add endpoint**
2. URL: `https://your-domain.com/webhook/payment`
3. Events to send: `payment_intent.succeeded`, `payment_intent.payment_failed`
4. Copy the **Signing secret** → paste into `.env` as `STRIPE_WEBHOOK_SECRET`

### 13. Configure AI Provider (Optional)

If using OpenAI:

```env
AI_PROVIDER=openai
AI_API_KEY=sk-...
```

If using local Ollama (advanced):

```env
AI_PROVIDER=ollama
AI_BASE_URL=http://127.0.0.1:11434/v1
AI_MODEL=llama3.2
AI_API_KEY=
```

If AI is not configured, AI agents will gracefully return fallback responses and approval requests will still work.

---

## Common Issues

### 500 Internal Server Error

1. Check `storage/logs/laravel.log`
2. Verify `.env` exists and has correct DB credentials
3. Run `php artisan config:clear && php artisan config:cache`
4. Verify `storage/` and `bootstrap/cache/` are writable (775)

### 404 on all routes

1. Ensure **Document Root** points to `tech360-laravel/public/`
2. Verify `.htaccess` exists in `public/` (it ships with Laravel)

### Login redirect loop

1. Verify `SESSION_DRIVER=database` in `.env`
2. Ensure `sessions` table exists (run `php artisan migrate`)
3. Clear cookies and retry

### AI execution fails

1. Check `AI_API_KEY` is set
2. Check `storage/logs/laravel.log` for provider errors
3. AI agents in `approval` mode require admin approval — check `/admin/ai/approvals`

---

## Security Hardening Checklist

- [ ] `APP_DEBUG=false` in production
- [ ] `APP_KEY` generated (run `php artisan key:generate`)
- [ ] `SESSION_ENCRYPT=true`
- [ ] `SESSION_SECURE_COOKIE=true` (requires HTTPS)
- [ ] `.env` file permissions: 644 (not world-readable)
- [ ] `storage/` and `bootstrap/cache/` permissions: 775
- [ ] Default admin password changed
- [ ] Stripe webhook secret configured
- [ ] SSL certificate active (https://)
- [ ] `robots.txt` blocks `/admin/`, `/crm/`, `/client/`, `/webhook/`
- [ ] Cron job running (`* * * * * php artisan schedule:run`)
- [ ] Backups configured in cPanel → **Backup Wizard**

---

## Queue Worker (Optional — for background AI jobs)

By default, TECH360 uses `QUEUE_CONNECTION=sync` (jobs run inline). If you want background processing on cPanel:

1. Set `QUEUE_CONNECTION=database` in `.env`
2. Run `php artisan queue:table && php artisan migrate`
3. Add a second cron job every minute:

```bash
/usr/local/bin/php /home/USERNAME/tech360-laravel/artisan queue:work --stop-when-empty >> /dev/null 2>&1
```

This is **optional** — the application works fine with `sync` driver on standard cPanel.

---

## Post-Deployment Verification

Run through this checklist after deployment:

- [ ] Homepage loads with all images
- [ ] All 13 public pages return 200
- [ ] Login page loads
- [ ] Admin can login and see dashboard
- [ ] CRM dashboard shows real metrics (not zeros if data exists)
- [ ] Admin can create contact, lead, deal, task
- [ ] AI dashboard loads and shows seeded 11 agents
- [ ] AI agent can be toggled active/inactive
- [ ] AI command executes and creates approval (in approval mode)
- [ ] Approval center shows pending approval
- [ ] Admin can approve/reject
- [ ] Payment webhook accepts signed POST
- [ ] Source code download blocked without verified payment
- [ ] Audit logs created for sensitive actions
- [ ] 404 page renders with TECH360 branding
- [ ] 403 page renders when unauthorized
- [ ] robots.txt accessible
- [ ] sitemap.xml accessible
- [ ] Cron job running (check cPanel → Cron Jobs → list)

---

## Support

- **Email:** support@tech360.io
- **Phone:** +1 (800) 360-0199
- **Address:** 117 S Lexington St, Ste 100, Harrisonville, MO 64701
- **Documentation:** See `README_CPANEL.md`, `SECURITY.md`, `DATABASE_SETUP.md`

---

© TECH360 LLC — Connect • Innovate • Grow
