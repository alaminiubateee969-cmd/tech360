# TECH360 — cPanel Deployment Guide

## Requirements
- PHP 8.2+
- MySQL 8 / MariaDB 10.4+
- cPanel with Terminal or SSH access (optional but recommended)

## Steps

1. Create MySQL database in cPanel
2. Create MySQL user and assign ALL PRIVILEGES
3. Upload tech360-laravel-cpanel-production.zip
4. Extract to your domain directory (e.g., /home/USERNAME/tech360)
5. Point domain document root to /home/USERNAME/tech360/public
6. Set PHP version to 8.2+
7. Copy .env.example to .env
8. Edit .env: set APP_URL, DB credentials, MAIL, AI provider
9. Generate APP_KEY: `php artisan key:generate`
10. Run migrations: `php artisan migrate --force`
11. Run seeder: `php artisan db:seed --force`
12. Create storage link: `php artisan storage:link`
13. Optimize: `php artisan config:cache && php artisan route:cache && php artisan view:cache`
14. Set permissions: `chmod -R 775 storage bootstrap/cache`
15. Configure cron: `* * * * * cd /home/USERNAME/tech360 && php artisan schedule:run >> /dev/null 2>&1`
16. Enable SSL
17. Test website, CRM, Admin, AI

## Default Admin
Email: admin@tech360.io
Password: (generated during seed — check console output)
Change immediately after first login.
