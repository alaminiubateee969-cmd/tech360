
cat > resources/views/pages/blog.blade.php << 'EOF'
@extends('layouts.app')
@section('title', 'Blog | TECH360')
@section('content')
<section class="section"><div class="container">
<div class="section-header"><h2>TECH360 <span class="text-gradient">Blog</span></h2><p>Insights on technology, innovation, and growth</p></div>
@if($posts->isEmpty())
<p style="text-align:center;color:var(--secondary-text);">Articles coming soon.</p>
@else
<div class="grid grid-3">
@foreach($posts as $post)
<div class="card">
@if($post->featured_image)<img src="{{ $post->featured_image }}" alt="{{ $post->title }}" class="card-img">@endif
<span class="badge badge-blue">{{ $post->category ?? 'Technology' }}</span>
<h3 style="margin-top:12px;">{{ $post->title }}</h3>
<p>{{ $post->excerpt ?? mb_substr($post->content, 0, 150) }}...</p>
<a href="{{ route('blog.post', $post->slug) }}" class="btn btn-sm btn-outline" style="margin-top:12px;">Read More</a>
</div>
@endforeach
</div>
{{ $posts->links() }}
@endif
</div></section>
@endsection
EOF

cat > resources/views/pages/blog-post.blade.php << 'EOF'
@extends('layouts.app')
@section('title', $post->title . ' | TECH360 Blog')
@section('content')
<section class="section"><div class="container" style="max-width:800px;">
<span class="badge badge-blue">{{ $post->category ?? 'Technology' }}</span>
<h1 style="margin:16px 0;">{{ $post->title }}</h1>
<p style="color:var(--secondary-text);">By {{ $post->author }} · {{ $post->created_at->format('M d, Y') }}</p>
@if($post->featured_image)<img src="{{ $post->featured_image }}" alt="{{ $post->title }}" style="width:100%;border-radius:12px;margin:24px 0;">@endif
<div style="line-height:1.8;">{!! nl2br(e($post->content)) !!}</div>
<a href="{{ route('blog') }}" class="btn btn-outline" style="margin-top:32px;">← Back to Blog</a>
</div></section>
@endsection
EOF

echo "✓ All public pages created"

# Create CRM views
mkdir -p resources/views/crm
cat > resources/views/crm/dashboard.blade.php << 'EOF'
@extends('layouts.app')
@section('title', 'CRM Dashboard | TECH360')
@section('content')
<div style="display:flex;">
    <div class="crm-sidebar">
        <a href="{{ route('crm.dashboard') }}" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        <a href="{{ route('crm.contacts') }}"><i class="fas fa-users"></i> Contacts</a>
        <a href="{{ route('crm.leads') }}"><i class="fas fa-flag"></i> Leads</a>
        <a href="{{ route('crm.deals') }}"><i class="fas fa-handshake"></i> Deals</a>
        <a href="{{ route('crm.tasks') }}"><i class="fas fa-tasks"></i> Tasks</a>
        <a href="{{ route('admin.dashboard') }}"><i class="fas fa-cog"></i> Admin</a>
    </div>
    <div class="crm-main">
        <h2 style="margin-bottom:24px;">CRM Dashboard</h2>
        <div class="grid grid-4" style="margin-bottom:32px;">
            <div class="stat-card"><div class="number">{{ $stats['total_contacts'] }}</div><div class="label">Total Contacts</div></div>
            <div class="stat-card"><div class="number" style="color:var(--blue);">{{ $stats['new_leads'] }}</div><div class="label">New Leads</div></div>
            <div class="stat-card"><div class="number" style="color:var(--cyan);">{{ $stats['qualified_leads'] }}</div><div class="label">Qualified Leads</div></div>
            <div class="stat-card"><div class="number" style="color:var(--green);">{{ $stats['customers'] }}</div><div class="label">Customers</div></div>
        </div>
        <div class="grid grid-4" style="margin-bottom:32px;">
            <div class="stat-card"><div class="number">{{ $stats['open_deals'] }}</div><div class="label">Open Deals</div></div>
            <div class="stat-card"><div class="number" style="color:var(--green);">{{ $stats['won_deals'] }}</div><div class="label">Won Deals</div></div>
            <div class="stat-card"><div class="number">${{ number_format($stats['pipeline_value'], 0) }}</div><div class="label">Pipeline Value</div></div>
            <div class="stat-card"><div class="number" style="color:var(--green);">${{ number_format($stats['won_value'], 0) }}</div><div class="label">Won Value</div></div>
        </div>
        <h3>Recent Leads</h3>
        <table class="table" style="margin-top:16px;">
            <tr><th>Lead ID</th><th>Contact</th><th>Status</th><th>Source</th><th>Created</th></tr>
            @foreach($stats['recent_leads'] as $lead)
            <tr><td>{{ $lead->lead_id }}</td><td>{{ $lead->contact?->full_name ?? '—' }}</td><td><span class="badge badge-blue">{{ $lead->status }}</span></td><td>{{ $lead->source ?? '—' }}</td><td>{{ $lead->created_at->diffForHumans() }}</td></tr>
            @endforeach
        </table>
        <h3 style="margin-top:32px;">Recent Activities</h3>
        <table class="table" style="margin-top:16px;">
            <tr><th>Type</th><th>Description</th><th>Contact</th><th>Time</th></tr>
            @foreach($stats['recent_activities'] as $activity)
            <tr><td><span class="badge badge-navy">{{ $activity->type }}</span></td><td>{{ $activity->description }}</td><td>{{ $activity->contact?->full_name ?? '—' }}</td><td>{{ $activity->created_at->diffForHumans() }}</td></tr>
            @endforeach
        </table>
    </div>
</div>
@endsection
EOF

cat > resources/views/crm/contacts.blade.php << 'EOF'
@extends('layouts.app')
@section('title', 'Contacts | TECH360 CRM')
@section('content')
<div style="display:flex;"><div class="crm-sidebar"><a href="{{ route('crm.dashboard') }}">Dashboard</a><a href="{{ route('crm.contacts') }}" class="active">Contacts</a><a href="{{ route('crm.leads') }}">Leads</a><a href="{{ route('crm.deals') }}">Deals</a><a href="{{ route('crm.tasks') }}">Tasks</a></div>
<div class="crm-main">
<h2>Contacts ({{ $contacts->total() }})</h2>
<form method="GET" style="margin:16px 0;display:flex;gap:12px;">
<input type="text" name="search" placeholder="Search name, email, phone..." value="{{ request('search') }}" style="padding:10px;border:1px solid var(--border);border-radius:8px;flex:1;">
<select name="status" style="padding:10px;border:1px solid var(--border);border-radius:8px;"><option value="">All Status</option><option value="lead" {{ request('status')=='lead'?'selected':'' }}>Lead</option><option value="qualified" {{ request('status')=='qualified'?'selected':'' }}>Qualified</option><option value="customer" {{ request('status')=='customer'?'selected':'' }}>Customer</option></select>
<button type="submit" class="btn btn-sm btn-primary">Search</button>
</form>
<table class="table"><tr><th>Contact ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Company</th><th>Status</th><th>Actions</th></tr>
@foreach($contacts as $contact)
<tr><td>{{ $contact->contact_id }}</td><td>{{ $contact->full_name }}</td><td>{{ $contact->email ?? '—' }}</td><td>{{ $contact->phone ?? '—' }}</td><td>{{ $contact->company?->name ?? '—' }}</td><td><span class="badge {{ $contact->status=='customer'?'badge-green':'badge-blue' }}">{{ $contact->status }}</span></td><td><a href="{{ route('crm.contacts.show', $contact->id) }}" class="btn btn-sm btn-outline">View</a></td></tr>
@endforeach
</table>
{{ $contacts->links() }}
</div></div>
@endsection
EOF

cat > resources/views/crm/contact-detail.blade.php << 'EOF'
@extends('layouts.app')
@section('title', $contact->full_name . ' | TECH360 CRM')
@section('content')
<div style="display:flex;"><div class="crm-sidebar"><a href="{{ route('crm.dashboard') }}">Dashboard</a><a href="{{ route('crm.contacts') }}" class="active">Contacts</a><a href="{{ route('crm.leads') }}">Leads</a><a href="{{ route('crm.deals') }}">Deals</a></div>
<div class="crm-main">
<h2>{{ $contact->full_name }}</h2>
<p style="color:var(--secondary-text);">{{ $contact->contact_id }} | {{ $contact->email ?? 'No email' }} | {{ $contact->phone ?? 'No phone' }} | <span class="badge {{ $contact->status=='customer'?'badge-green':'badge-blue' }}">{{ $contact->status }}</span></p>

<h3 style="margin-top:32px;">Communication History</h3>
@if($contact->communications->isEmpty())<p>No communications yet.</p>@else
<table class="table" style="margin-top:12px;"><tr><th>Channel</th><th>Direction</th><th>Subject</th><th>Date</th></tr>
@foreach($contact->communications as $comm)<tr><td><span class="badge badge-blue">{{ $comm->channel }}</span></td><td>{{ $comm->direction }}</td><td>{{ $comm->subject ?? '—' }}</td><td>{{ $comm->created_at->format('M d, Y H:i') }}</td></tr>@endforeach
</table>@endif

<h3 style="margin-top:32px;">Add Communication</h3>
<form method="POST" action="{{ route('crm.communication.add', $contact->id) }}">@csrf
<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
<select name="channel" style="padding:10px;border:1px solid var(--border);border-radius:8px;"><option value="email">Email</option><option value="whatsapp">WhatsApp</option><option value="phone">Phone</option><option value="meeting">Meeting</option><option value="sms">SMS</option><option value="note">Note</option></select>
<select name="direction" style="padding:10px;border:1px solid var(--border);border-radius:8px;"><option value="outbound">Outbound</option><option value="inbound">Inbound</option></select>
</div>
<input type="text" name="subject" placeholder="Subject" style="width:100%;padding:10px;border:1px solid var(--border);border-radius:8px;margin-top:12px;">
<textarea name="body" placeholder="Message body..." rows="4" style="width:100%;padding:10px;border:1px solid var(--border);border-radius:8px;margin-top:12px;"></textarea>
<button type="submit" class="btn btn-primary" style="margin-top:12px;">Log Communication</button>
</form>

<h3 style="margin-top:32px;">Leads</h3>
@if($contact->leads->isEmpty())<p>No leads.</p>@else
<table class="table" style="margin-top:12px;"><tr><th>Lead ID</th><th>Status</th><th>Source</th><th>Created</th></tr>
@foreach($contact->leads as $lead)<tr><td>{{ $lead->lead_id }}</td><td><span class="badge badge-blue">{{ $lead->status }}</span></td><td>{{ $lead->source ?? '—' }}</td><td>{{ $lead->created_at->format('M d, Y') }}</td></tr>@endforeach
</table>@endif

<h3 style="margin-top:32px;">Activities</h3>
@if($contact->activities->isEmpty())<p>No activities.</p>@else
<table class="table" style="margin-top:12px;"><tr><th>Type</th><th>Description</th><th>Date</th></tr>
@foreach($contact->activities as $activity)<tr><td><span class="badge badge-navy">{{ $activity->type }}</span></td><td>{{ $activity->description }}</td><td>{{ $activity->created_at->format('M d, Y H:i') }}</td></tr>@endforeach
</table>@endif
</div></div>
@endsection
EOF

# Create leads, deals, tasks views (simplified)
for view in leads deals tasks; do
cat > resources/views/crm/$view.blade.php << ENDVIEW
@extends('layouts.app')
@section('title', ucfirst('$view') . ' | TECH360 CRM')
@section('content')
<div style="display:flex;"><div class="crm-sidebar"><a href="{{ route('crm.dashboard') }}">Dashboard</a><a href="{{ route('crm.contacts') }}">Contacts</a><a href="{{ route('crm.leads') }}" @if('$view'=='leads')class="active"@endif>Leads</a><a href="{{ route('crm.deals') }}" @if('$view'=='deals')class="active"@endif>Deals</a><a href="{{ route('crm.tasks') }}" @if('$view'=='tasks')class="active"@endif>Tasks</a></div>
<div class="crm-main">
<h2>{{ ucfirst('$view') }} ({{ \${$view}->total() }})</h2>
@if(\${$view}->isEmpty())<p>No ${view} found.</p>@else
<table class="table" style="margin-top:16px;">
@if('$view'=='leads')<tr><th>Lead ID</th><th>Contact</th><th>Status</th><th>Source</th><th>Interest</th><th>Created</th></tr>@foreach(\${$view} as \$item)<tr><td>{{ \$item->lead_id }}</td><td>{{ \$item->contact?->full_name ?? '—' }}</td><td><span class="badge badge-blue">{{ \$item->status }}</span></td><td>{{ \$item->source ?? '—' }}</td><td>{{ \$item->service_interest ?? '—' }}</td><td>{{ \$item->created_at->format('M d, Y') }}</td></tr>@endforeach
@elseif('$view'=='deals')<tr><th>Deal ID</th><th>Title</th><th>Contact</th><th>Value</th><th>Stage</th><th>Expected Close</th></tr>@foreach(\${$view} as \$item)<tr><td>{{ \$item->deal_id }}</td><td>{{ \$item->title }}</td><td>{{ \$item->contact?->full_name ?? '—' }}</td><td>\${{ number_format(\$item->value, 0) }}</td><td><span class="badge {{ \$item->stage=='won'?'badge-green':(\$item->stage=='lost'?'badge-red':'badge-blue') }}">{{ \$item->stage }}</span></td><td>{{ \$item->expected_close_date?->format('M d, Y') ?? '—' }}</td></tr>@endforeach
@else<tr><th>Task</th><th>Priority</th><th>Status</th><th>Due Date</th><th>Assigned To</th></tr>@foreach(\${$view} as \$item)<tr><td>{{ \$item->title }}</td><td><span class="badge {{ \$item->priority=='urgent'?'badge-red':'badge-blue' }}">{{ \$item->priority }}</span></td><td><span class="badge {{ \$item->status=='completed'?'badge-green':'badge-navy' }}">{{ \$item->status }}</span></td><td>{{ \$item->due_date?->format('M d, Y') ?? '—' }}</td><td>{{ \$item->assignedTo?->name ?? '—' }}</td></tr>@endforeach@endif
</table>
{{ \${$view}->links() }}
@endif
</div></div>
@endsection
ENDVIEW
done

echo "✓ CRM views created (dashboard, contacts, contact-detail, leads, deals, tasks)"

# Clear cache and run tests
/tmp/php artisan config:clear 2>&1
/tmp/php artisan route:clear 2>&1

# Test all routes
/tmp/php artisan serve --port=8200 > /tmp/laravel-master.log 2>&1 &
sleep 4

echo ""
echo "=== ALL ROUTE TESTS ==="
PASS=0; FAIL=0
for path in / /about /services /industries /portfolio /case-studies /blog /pricing /contact /terms /refund-policy /privacy-policy /cookie-policy /login; do
  CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 "http://localhost:8200$path" 2>&1)
  printf "  %-25s %s\n" "$path" "$CODE"
  if [ "$CODE" = "200" ]; then PASS=$((PASS+1)); else FAIL=$((FAIL+1)); fi
done

echo ""
echo "=== PROTECTED ROUTES ==="
for path in /client/dashboard /crm/dashboard /admin/dashboard /admin/ai-command-center /crm/contacts /crm/leads /crm/deals; do
  CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 "http://localhost:8200$path" 2>&1)
  printf "  %-35s %s\n" "$path" "$CODE"
done

echo ""
echo "=== WEBHOOKS ==="
CODE1=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 -X POST http://localhost:8200/webhook/ai -H "Content-Type: application/json" -d '{"job_id":"test","result":"ok"}' 2>&1)
printf "  POST /webhook/ai          %s\n" "$CODE1"

kill %1 2>/dev/null

echo ""
echo "=== FINAL COUNTS ==="
echo "Migrations: $(ls database/migrations/ | wc -l)"
echo "Models: $(ls app/Models/ | wc -l)"
echo "Controllers: $(ls app/Http/Controllers/ | wc -l)"
echo "Views: $(find resources/views -name '*.blade.php' | wc -l)"
echo "Routes: $(/tmp/php artisan route:list 2>&1 | grep -c 'GET\|POST')"

echo ""
echo "=== TYPECHECK ==="
/tmp/php -l app/Http/Controllers/CrmController.php 2>&1
/tmp/php -l app/Http/Controllers/CmsController.php 2>&1
/tmp/php -l app/Http/Controllers/HomeController.php 2>&1
__workspace_agent_exit_code=$?
printf "\n<<workspace_agent_exit_code:1787284853699:%s>>\n" "$__workspace_agent_exit_code"
