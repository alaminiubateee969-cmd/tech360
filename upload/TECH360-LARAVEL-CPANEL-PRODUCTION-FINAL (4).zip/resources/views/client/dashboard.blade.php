@extends('layouts.client')
@section('title', 'Client Dashboard | TECH360 LLC')
@section('content')
<section class="section"><div class="container">
<h2>My Projects</h2>
@if($projects->isEmpty())
<p>No projects yet. <a href="{{ route('contact') }}">Start a project</a></p>
@else
<div class="grid">
@foreach($projects as $project)
<div class="card">
<h3>{{ $project->name }}</h3>
<p>Project ID: {{ $project->project_id }}</p>
<p>State: {{ $project->commercial_state }}</p>
<p>Budget: ${{ number_format($project->budget, 2) }}</p>
<a href="{{ route('client.scope', $project) }}" class="btn btn-primary" style="margin-top:12px;">View Scope</a>
@if($project->commercial_state === 'SCOPE_APPROVED')
<a href="{{ route('client.payment', $project) }}" class="btn btn-primary" style="margin-top:12px;">Payment</a>
@endif
@if(in_array($project->commercial_state, ['PAYMENT_PAID', 'FINAL_DEVELOPMENT', 'FINAL_HANDOVER']))
<a href="{{ route('client.handover', $project) }}" class="btn btn-primary" style="margin-top:12px;">Delivery</a>
@endif
</div>
@endforeach
</div>
@endif
</div></section>
@endsection
