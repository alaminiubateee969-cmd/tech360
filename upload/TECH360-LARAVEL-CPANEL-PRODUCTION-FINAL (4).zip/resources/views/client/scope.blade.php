@extends('layouts.client')
@section('title', 'Scope of Work | TECH360 LLC')
@section('content')
<section class="section"><div class="container" style="max-width:800px;">
@if($scope)
<h2>{{ $scope->title }}</h2>
<p><strong>Scope ID:</strong> {{ $scope->scope_id }} | <strong>Version:</strong> {{ $scope->version }}</p>
@if($scope->status === 'approved')
<div class="alert alert-success" style="background:#dcfce7;color:#166534;padding:12px;border-radius:8px;margin-bottom:16px;">
✓ This scope has been approved. <a href="{{ route('client.payment', $project) }}">Proceed to Payment</a>
</div>
@elseif($scope->status === 'pending_approval' || $scope->status === 'sent')
<h3>Review and Approve</h3>
<p>Review your Scope of Work before approving. By approving, you confirm you have reviewed and accepted the project requirements, preview, Terms & Conditions, and Refund Policy.</p>
@if($scope->objective)<p><strong>Objective:</strong> {{ $scope->objective }}</p>@endif
@if($scope->timeline)<p><strong>Timeline:</strong> {{ $scope->timeline }}</p>@endif
<p><strong>Payment Amount:</strong> ${{ number_format($scope->payment_amount, 2) }}</p>
@if($scope->payment_terms)<p><strong>Payment Terms:</strong> {{ $scope->payment_terms }}</p>@endif

<form method="POST" action="{{ route('client.scope.approve', $project) }}">@csrf
<div class="checkbox-group">
<label><input type="checkbox" name="scope_reviewed" value="1" required> I have reviewed and approve the Scope of Work.</label>
</div>
<div class="checkbox-group">
<label><input type="checkbox" name="preview_reviewed" value="1" required> I have reviewed the applicable HTML preview.</label>
</div>
<div class="checkbox-group">
<label><input type="checkbox" name="terms_accepted" value="1" required> I have read and agree to the <a href="{{ route('terms') }}" target="_blank">Terms & Conditions</a>.</label>
</div>
<div class="checkbox-group">
<label><input type="checkbox" name="refund_policy_acknowledged" value="1" required> I have read and acknowledge the <a href="{{ route('refund-policy') }}" target="_blank">Refund Policy</a>.</label>
</div>
<div class="checkbox-group">
<label><input type="checkbox" name="non_refundable_acknowledged" value="1" required> I understand that after Scope of Work approval, project payments are non-refundable except where required by applicable law or otherwise agreed in writing.</label>
</div>
<button type="submit" class="btn btn-primary">APPROVE SCOPE & CONTINUE TO PAYMENT</button>
</form>

<hr style="margin:24px 0;">
<h3>Request a Change</h3>
<form method="POST" action="{{ route('client.scope.change', $project) }}">@csrf
<div class="form-group"><label>Change Description</label><textarea name="change_description" rows="3" required></textarea></div>
<button type="submit" class="btn btn-outline" style="background:transparent;color:var(--blue);border:2px solid var(--blue);">REQUEST CHANGE</button>
</form>
@else
<p>Scope status: {{ $scope->status }}</p>
@endif
@else
<p>No scope has been created for this project yet.</p>
@endif
</div></section>
@endsection
