@extends('layouts.client')
@section('title', 'Payment Instructions | TECH360 LLC')
@section('content')
<section class="section"><div class="container" style="max-width:600px;text-align:center;">
<h2>Payment Initiated</h2>
<p>Your payment of ${{ number_format($payment->amount, 2) }} has been initiated. Payment status: <strong>{{ $payment->status }}</strong></p>
<p>TECH360 LLC will verify your payment server-side. You will be notified once payment is confirmed.</p>
<a href="{{ route('client.dashboard') }}" class="btn btn-primary">Back to Dashboard</a>
</div></section>
@endsection
