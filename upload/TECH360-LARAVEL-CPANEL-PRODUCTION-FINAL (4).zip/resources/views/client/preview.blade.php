@extends('layouts.client')
@section('title', 'HTML Preview | TECH360 LLC')
@section('content')
<section class="section"><div class="container" style="max-width:800px;">
<h2>HTML Preview</h2>
<div class="alert alert-warning" style="background:#fef3c7;color:#92400e;padding:12px;border-radius:8px;margin-bottom:16px;">
<strong>PREVIEW — NOT FINAL PRODUCTION HANDOVER</strong>
</div>
<p>Project: {{ $project->name }}</p>
<p>The preview shows the proposed design direction for your review. This is not the final production deliverable.</p>
<a href="{{ route('client.scope', $project) }}" class="btn btn-primary">Back to Scope</a>
</div></section>
@endsection
