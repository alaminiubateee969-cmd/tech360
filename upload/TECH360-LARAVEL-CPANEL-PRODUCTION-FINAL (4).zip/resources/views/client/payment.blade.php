@extends('layouts.client')
@section('title', 'Payment | TECH360 LLC')
@section('content')
<section class="section"><div class="container" style="max-width:600px;text-align:center;">
<h2>Full Payment Required</h2>
<p>Your Scope of Work and applicable HTML preview have been approved. Full payment is required before final development and final project handover.</p>
<div class="card" style="margin:24px 0;text-align:left;">
<p><strong>Project:</strong> {{ $project->name }}</p>
<p><strong>Scope:</strong> {{ $scope->scope_id }} (v{{ $scope->version }})</p>
<p><strong>Amount:</strong> ${{ number_format($scope->payment_amount, 2) }} {{ $scope->payment_terms ?? '' }}</p>
<p><strong>Status:</strong> @if($payment && $payment->status === 'paid')<span style="color:green;">PAID</span>@else<span style="color:orange;">PAYMENT REQUIRED</span>@endif</p>
</div>
@if($payment && $payment->status === 'paid')
<div class="alert alert-success" style="background:#dcfce7;color:#166534;padding:16px;border-radius:8px;">
<h3>Payment Completed</h3><p>Your payment has been successfully verified. TECH360 LLC will now proceed with final development.</p>
<a href="{{ route('client.handover', $project) }}" class="btn btn-primary">View Handover</a>
</div>
@else
<form method="POST" action="{{ route('client.payment.process', $project) }}">@csrf
<div class="checkbox-group">
<label><input type="checkbox" name="terms_acknowledged" value="1" required> I have reviewed the approved Scope of Work, <a href="{{ route('terms') }}" target="_blank">Terms & Conditions</a>, and <a href="{{ route('refund-policy') }}" target="_blank">Refund Policy</a>.</label>
</div>
<button type="submit" class="btn btn-primary">PAY FULL AMOUNT</button>
</form>
@endif
</div></section>
@endsection
