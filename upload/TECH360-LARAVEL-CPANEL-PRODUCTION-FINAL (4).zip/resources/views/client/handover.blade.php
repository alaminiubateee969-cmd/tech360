@extends('layouts.client')
@section('title', 'Handover | TECH360 LLC')
@section('content')
<section class="section"><div class="container" style="max-width:600px;">
<h2>Project Handover</h2>
@if($sourceCodeAccess['granted'])
<div class="alert alert-success" style="background:#dcfce7;color:#166534;padding:16px;border-radius:8px;">
<h3>Delivery Ready</h3>
<p>✓ Source code prepared</p>
<p>✓ Files prepared</p>
<p>✓ Documentation ready</p>
@if(!$delivery || !$delivery->client_confirmed)
<h3>Confirm Delivery</h3>
<form method="POST" action="{{ route('client.delivery.confirm', $project) }}">@csrf
<div class="checkbox-group">
<label><input type="checkbox" name="delivery_confirmed" value="1" required> I confirm that I have received the agreed project deliverables.</label>
</div>
<button type="submit" class="btn btn-primary">CONFIRM DELIVERY</button>
</form>
<h3>Security Action Required</h3>
<div class="checkbox-group">
<label><input type="checkbox" required> I have changed or secured the provided administrative credentials.</label>
</div>
@else
<p>✓ Delivery confirmed</p>
@endif
</div>
@else
<div class="alert alert-error" style="background:#fee2e2;color:#991b1b;padding:16px;border-radius:8px;">
<h3>Source Code Access Blocked</h3>
<p>Source code access is BLOCKED. The following requirements have not been met:</p>
<ul>
@foreach($sourceCodeAccess['failed_gates'] as $gate)
<li>{{ str_replace('_', ' ', ucfirst($gate)) }}</li>
@endforeach
</ul>
</div>
@endif
</div></section>
@endsection
