@extends('layouts.client')
@section('title', 'Refund Request | TECH360 LLC')
@section('content')
<section class="section"><div class="container" style="max-width:600px;">
<h2>Refund Request</h2>
<p style="color:var(--muted);margin-bottom:16px;">Submitting a refund request does not guarantee approval.</p>
<form method="POST" action="{{ route('client.refund.submit') }}">@csrf
<div class="form-group"><label>Project</label><select name="project_id"><option value="">— Select —</option>@foreach($projects as $p)<option value="{{ $p->id }}">{{ $p->name }}</option>@endforeach</select></div>
<div class="form-group"><label>Invoice Number</label><input type="text" name="invoice_number"></div>
<div class="form-group"><label>Payment Reference</label><input type="text" name="payment_reference"></div>
<div class="form-group"><label>Payment Date</label><input type="date" name="payment_date"></div>
<div class="form-group"><label>Reason *</label><input type="text" name="reason" required></div>
<div class="form-group"><label>Description</label><textarea name="description" rows="4"></textarea></div>
<button type="submit" class="btn btn-primary">Submit Refund Request</button>
</form>
</div></section>
@endsection
