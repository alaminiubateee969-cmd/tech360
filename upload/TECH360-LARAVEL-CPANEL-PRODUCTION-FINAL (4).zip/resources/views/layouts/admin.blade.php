<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="{{ csrf_token() }}">
<meta name="robots" content="noindex,nofollow">
<title>@yield('title', 'TECH360 Admin')</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<style>
:root {
--navy: #063B8F;
--blue: #009FE3;
--cyan: #00A8A8;
--green: #18B83A;
--bright-green: #20C94F;
--white: #FFFFFF;
--light-blue: #F4FAFF;
--light-green: #F3FFF7;
--primary-text: #152238;
--secondary-text: #526173;
--border: #E2E8F0;
--shadow: 0 4px 24px rgba(6,59,143,0.08);
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Inter', -apple-system, system-ui, sans-serif; background: var(--light-blue); color: var(--primary-text); line-height: 1.6; }
h1, h2, h3, h4, h5, h6 { font-family: 'Poppins', sans-serif; font-weight: 700; color: var(--primary-text); }
a { text-decoration: none; color: var(--blue); }
.app-shell { display: flex; min-height: 100vh; }
/* Sidebar */
.sidebar { width: 260px; background: var(--navy); color: var(--white); flex-shrink: 0; position: sticky; top: 0; height: 100vh; overflow-y: auto; padding: 24px 0; }
.sidebar-header { padding: 0 24px 24px; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 16px; }
.sidebar-header .logo { display: flex; align-items: center; gap: 10px; }
.sidebar-header .logo-mark { background: linear-gradient(135deg, var(--blue), var(--green)); color: white; width: 40px; height: 40px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 1.2rem; }
.sidebar-header .logo-text { font-family: 'Poppins', sans-serif; font-size: 1.3rem; font-weight: 800; color: var(--white); }
.sidebar-header .logo-slogan { font-size: 0.6rem; color: rgba(255,255,255,0.6); letter-spacing: 0.1em; text-transform: uppercase; }
.sidebar-section { padding: 8px 16px; }
.sidebar-section-label { font-size: 0.65rem; text-transform: uppercase; letter-spacing: 0.1em; color: rgba(255,255,255,0.4); padding: 8px 8px 4px; font-weight: 600; }
.sidebar-link { display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: 8px; color: rgba(255,255,255,0.7); font-size: 0.9rem; transition: all 0.2s; margin-bottom: 2px; }
.sidebar-link:hover { background: rgba(255,255,255,0.08); color: var(--white); }
.sidebar-link.active { background: linear-gradient(90deg, rgba(0,159,227,0.2), rgba(24,184,58,0.1)); color: var(--white); border-left: 3px solid var(--cyan); }
.sidebar-link i { width: 18px; text-align: center; }
/* Main */
.main { flex: 1; display: flex; flex-direction: column; min-width: 0; }
.topbar { background: var(--white); border-bottom: 1px solid var(--border); padding: 12px 24px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 8px rgba(0,0,0,0.03); }
.topbar h1 { font-size: 1.1rem; margin: 0; }
.topbar-user { display: flex; align-items: center; gap: 12px; }
.user-avatar { width: 36px; height: 36px; border-radius: 50%; background: linear-gradient(135deg, var(--blue), var(--cyan)); color: white; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 0.9rem; }
.content { padding: 24px; flex: 1; }
.container { max-width: 1280px; margin: 0 auto; }
/* Buttons */
.btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border-radius: 8px; font-size: 0.9rem; font-weight: 600; border: none; cursor: pointer; transition: all 0.2s; text-decoration: none; }
.btn-primary { background: var(--blue); color: white; }
.btn-primary:hover { background: var(--navy); }
.btn-success { background: var(--green); color: white; }
.btn-danger { background: #DC2626; color: white; }
.btn-outline { background: transparent; color: var(--navy); border: 1.5px solid var(--blue); }
.btn-outline:hover { background: var(--blue); color: white; }
.btn-sm { padding: 6px 12px; font-size: 0.8rem; }
/* Cards */
.card { background: var(--white); border-radius: 12px; padding: 24px; box-shadow: var(--shadow); margin-bottom: 16px; border: 1px solid var(--border); }
.stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; margin-bottom: 24px; }
.stat-card { background: var(--white); border-radius: 12px; padding: 20px; box-shadow: var(--shadow); border-left: 4px solid var(--blue); }
.stat-card .number { font-family: 'Poppins', sans-serif; font-size: 1.8rem; font-weight: 800; color: var(--navy); }
.stat-card .label { color: var(--secondary-text); font-size: 0.85rem; }
.stat-card.blue { border-left-color: var(--blue); }
.stat-card.green { border-left-color: var(--green); }
.stat-card.amber { border-left-color: #F59E0B; }
.stat-card.red { border-left-color: #DC2626; }
.stat-card.navy { border-left-color: var(--navy); }
.stat-card.cyan { border-left-color: var(--cyan); }
/* Grid */
.grid { display: grid; gap: 16px; }
.grid-2 { grid-template-columns: repeat(2, 1fr); }
.grid-3 { grid-template-columns: repeat(3, 1fr); }
.grid-4 { grid-template-columns: repeat(4, 1fr); }
/* Tables */
.table { width: 100%; border-collapse: collapse; background: var(--white); border-radius: 12px; overflow: hidden; box-shadow: var(--shadow); }
.table th { background: var(--navy); color: var(--white); padding: 12px 16px; text-align: left; font-size: 0.85rem; font-weight: 600; }
.table td { padding: 12px 16px; border-bottom: 1px solid var(--border); font-size: 0.9rem; }
.table tr:hover { background: var(--light-blue); }
.table tr:last-child td { border-bottom: none; }
/* Badges */
.badge { padding: 3px 10px; border-radius: 20px; font-size: 0.72rem; font-weight: 600; }
.badge-blue { background: rgba(0,159,227,0.12); color: var(--blue); }
.badge-green { background: rgba(24,184,58,0.12); color: var(--green); }
.badge-red { background: rgba(220,38,38,0.12); color: #DC2626; }
.badge-navy { background: rgba(6,59,143,0.12); color: var(--navy); }
.badge-amber { background: rgba(245,158,11,0.12); color: #F59E0B; }
/* Forms */
.form-group { margin-bottom: 14px; }
.form-group label { display: block; margin-bottom: 6px; font-weight: 600; font-size: 0.85rem; color: var(--primary-text); }
.form-group input, .form-group textarea, .form-group select { width: 100%; padding: 10px 14px; border: 1px solid var(--border); border-radius: 8px; font-size: 0.95rem; font-family: inherit; }
.form-group input:focus, .form-group textarea:focus, .form-group select:focus { outline: none; border-color: var(--blue); box-shadow: 0 0 0 3px rgba(0,159,227,0.1); }
/* Alerts */
.alert { padding: 12px 18px; border-radius: 8px; margin-bottom: 16px; font-size: 0.9rem; }
.alert-success { background: #dcfce7; color: #166534; border: 1px solid #86efac; }
.alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
.alert-info { background: #dbeafe; color: #1e40af; border: 1px solid #93c5fd; }
.alert-warn { background: #fef3c7; color: #92400e; border: 1px solid #fde68a; }
/* Modal */
.modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 2000; align-items: center; justify-content: center; padding: 16px; }
.modal-overlay.show { display: flex; }
.modal { background: white; border-radius: 16px; padding: 28px; max-width: 560px; width: 100%; max-height: 90vh; overflow-y: auto; }
.modal h3 { margin-bottom: 16px; }
/* Mobile */
.mobile-toggle { display: none; background: none; border: none; font-size: 1.4rem; color: var(--navy); cursor: pointer; }
@media (max-width: 1024px) {
.sidebar { position: fixed; left: -260px; z-index: 1000; transition: left 0.3s; }
.sidebar.show { left: 0; }
.mobile-toggle { display: inline-block; }
.grid-3, .grid-4 { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 768px) {
.grid-2, .grid-3, .grid-4 { grid-template-columns: 1fr; }
.content { padding: 16px; }
.table { font-size: 0.8rem; }
.table th, .table td { padding: 8px; }
}
</style>
@yield('head')
</head>
<body>
<div class="app-shell">
<aside class="sidebar" id="sidebar">
<div class="sidebar-header">
<div class="logo">
<div class="logo-mark">T</div>
<div>
<div class="logo-text">TECH360</div>
<div class="logo-slogan">Connect • Innovate • Grow</div>
</div>
</div>
</div>
<div class="sidebar-section">
<div class="sidebar-section-label">Main</div>
<a href="{{ route('admin.dashboard') }}" class="sidebar-link @if(request()->routeIs('admin.dashboard')) active @endif"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
<a href="{{ route('admin.clients') }}" class="sidebar-link @if(request()->routeIs('admin.clients')) active @endif"><i class="fas fa-users"></i> Clients</a>
<a href="{{ route('admin.projects') }}" class="sidebar-link @if(request()->routeIs('admin.projects')) active @endif"><i class="fas fa-project-diagram"></i> Projects</a>
</div>
<div class="sidebar-section">
<div class="sidebar-section-label">Financial</div>
<a href="{{ route('admin.payments') }}" class="sidebar-link @if(request()->routeIs('admin.payments')) active @endif"><i class="fas fa-credit-card"></i> Payments</a>
<a href="{{ route('admin.refunds') }}" class="sidebar-link @if(request()->routeIs('admin.refunds')) active @endif"><i class="fas fa-undo-alt"></i> Refunds</a>
<a href="{{ route('admin.payouts.index') }}" class="sidebar-link @if(request()->routeIs('admin.payouts.*')) active @endif"><i class="fas fa-money-bill-wave"></i> Payouts</a>
<a href="{{ route('admin.disputes.index') }}" class="sidebar-link @if(request()->routeIs('admin.disputes.*')) active @endif"><i class="fas fa-gavel"></i> Disputes</a>
</div>
<div class="sidebar-section">
<div class="sidebar-section-label">Evidence</div>
<a href="{{ route('admin.evidence.index') }}" class="sidebar-link @if(request()->routeIs('admin.evidence.*')) active @endif"><i class="fas fa-vault"></i> Evidence Vault</a>
<a href="{{ route('admin.audit') }}" class="sidebar-link @if(request()->routeIs('admin.audit')) active @endif"><i class="fas fa-history"></i> Audit Logs</a>
</div>
<div class="sidebar-section">
<div class="sidebar-section-label">CRM</div>
<a href="{{ route('crm.dashboard') }}" class="sidebar-link @if(request()->routeIs('crm.dashboard')) active @endif"><i class="fas fa-chart-pie"></i> CRM Dashboard</a>
<a href="{{ route('crm.contacts') }}" class="sidebar-link @if(request()->routeIs('crm.contacts')) active @endif"><i class="fas fa-address-book"></i> Contacts</a>
<a href="{{ route('crm.leads') }}" class="sidebar-link @if(request()->routeIs('crm.leads')) active @endif"><i class="fas fa-bullseye"></i> Leads</a>
<a href="{{ route('crm.deals') }}" class="sidebar-link @if(request()->routeIs('crm.deals')) active @endif"><i class="fas fa-handshake"></i> Deals</a>
<a href="{{ route('crm.tasks') }}" class="sidebar-link @if(request()->routeIs('crm.tasks')) active @endif"><i class="fas fa-tasks"></i> Tasks</a>
</div>
<div class="sidebar-section">
<div class="sidebar-section-label">AI Platform</div>
<a href="{{ route('admin.ai.dashboard') }}" class="sidebar-link @if(request()->routeIs('admin.ai.dashboard')) active @endif"><i class="fas fa-robot"></i> AI Dashboard</a>
<a href="{{ route('admin.ai.agents') }}" class="sidebar-link @if(request()->routeIs('admin.ai.agents.*')) active @endif"><i class="fas fa-microchip"></i> AI Agents</a>
<a href="{{ route('admin.ai.approvals') }}" class="sidebar-link @if(request()->routeIs('admin.ai.approvals')) active @endif"><i class="fas fa-check-double"></i> Approvals</a>
<a href="{{ route('admin.ai.knowledge') }}" class="sidebar-link @if(request()->routeIs('admin.ai.knowledge')) active @endif"><i class="fas fa-book"></i> Knowledge Base</a>
<a href="{{ route('admin.ai.workflows') }}" class="sidebar-link @if(request()->routeIs('admin.ai.workflows')) active @endif"><i class="fas fa-sitemap"></i> Workflows</a>
<a href="{{ route('admin.ai.logs') }}" class="sidebar-link @if(request()->routeIs('admin.ai.logs')) active @endif"><i class="fas fa-list"></i> Execution Logs</a>
</div>
<div class="sidebar-section">
<div class="sidebar-section-label">Content</div>
<a href="{{ route('admin.cms.services') }}" class="sidebar-link @if(request()->routeIs('admin.cms.services')) active @endif"><i class="fas fa-cogs"></i> Services</a>
<a href="{{ route('admin.cms.portfolio') }}" class="sidebar-link @if(request()->routeIs('admin.cms.portfolio')) active @endif"><i class="fas fa-briefcase"></i> Portfolio</a>
<a href="{{ route('admin.cms.blog') }}" class="sidebar-link @if(request()->routeIs('admin.cms.blog')) active @endif"><i class="fas fa-newspaper"></i> Blog</a>
<a href="{{ route('admin.cms.testimonials') }}" class="sidebar-link @if(request()->routeIs('admin.cms.testimonials')) active @endif"><i class="fas fa-quote-right"></i> Testimonials</a>
<a href="{{ route('admin.cms.submissions') }}" class="sidebar-link @if(request()->routeIs('admin.cms.submissions')) active @endif"><i class="fas fa-inbox"></i> Submissions</a>
<a href="{{ route('admin.cms.settings') }}" class="sidebar-link @if(request()->routeIs('admin.cms.settings')) active @endif"><i class="fas fa-cog"></i> Settings</a>
</div>
<div class="sidebar-section">
<div class="sidebar-section-label">Account</div>
<a href="{{ route('home') }}" class="sidebar-link"><i class="fas fa-globe"></i> View Website</a>
<form method="POST" action="{{ route('logout') }}" style="display:inline;">@csrf<button type="submit" class="sidebar-link" style="border:none;background:none;cursor:pointer;width:100%;text-align:left;"><i class="fas fa-sign-out-alt"></i> Logout</button></form>
</div>
</aside>

<div class="main">
<header class="topbar">
<div style="display:flex;align-items:center;gap:12px;">
<button class="mobile-toggle" onclick="document.getElementById('sidebar').classList.toggle('show')"><i class="fas fa-bars"></i></button>
<h1>@yield('page-title', 'TECH360 Admin')</h1>
</div>
<div class="topbar-user">
<div style="text-align:right;">
<div style="font-size:0.9rem;font-weight:600;">{{ auth()->user()->name }}</div>
<div style="font-size:0.75rem;color:var(--secondary-text);text-transform:capitalize;">{{ auth()->user()->role }}</div>
</div>
<div class="user-avatar">{{ strtoupper(substr(auth()->user()->name, 0, 1)) }}</div>
</div>
</header>

<main class="content">
@if(session('success'))
<div class="alert alert-success"><i class="fas fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if($errors->any())
<div class="alert alert-error">@foreach($errors->all() as $error)<div>{{ $error }}</div>@endforeach</div>
@endif
@yield('content')
</main>
</div>
</div>
@yield('scripts')
</body>
</html>
