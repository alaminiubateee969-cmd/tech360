<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="{{ csrf_token() }}">
<meta name="robots" content="noindex,nofollow">
<title>@yield('title', 'TECH360 Client Portal')</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<style>
:root {
--navy: #063B8F;
--blue: #009FE3;
--cyan: #00A8A8;
--green: #18B83A;
--bright-green: #20C94F;
--white: #FFFFFF;
--light-blue: #F4FAFF;
--light-green: #F3FFF7;
--primary-text: #152238;
--secondary-text: #526173;
--border: #E2E8F0;
--shadow: 0 4px 24px rgba(6,59,143,0.08);
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Inter', -apple-system, system-ui, sans-serif; background: var(--light-blue); color: var(--primary-text); line-height: 1.6; }
h1, h2, h3, h4, h5, h6 { font-family: 'Poppins', sans-serif; font-weight: 700; color: var(--primary-text); }
a { text-decoration: none; color: var(--blue); }
.client-shell { min-height: 100vh; display: flex; flex-direction: column; }
.client-header { background: var(--white); border-bottom: 1px solid var(--border); padding: 16px 32px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 8px rgba(0,0,0,0.03); }
.client-logo { display: flex; align-items: center; gap: 10px; }
.client-logo .logo-mark { background: linear-gradient(135deg, var(--navy), var(--green)); color: white; width: 40px; height: 40px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 1.2rem; }
.client-logo .logo-text { font-family: 'Poppins', sans-serif; font-size: 1.3rem; font-weight: 800; color: var(--navy); }
.client-logo .logo-slogan { font-size: 0.6rem; color: var(--secondary-text); letter-spacing: 0.1em; text-transform: uppercase; }
.client-nav { display: flex; gap: 8px; align-items: center; }
.client-nav a { padding: 8px 16px; border-radius: 8px; color: var(--primary-text); font-size: 0.9rem; font-weight: 500; transition: all 0.2s; }
.client-nav a:hover, .client-nav a.active { background: var(--light-blue); color: var(--blue); }
.client-main { flex: 1; padding: 32px; max-width: 1200px; margin: 0 auto; width: 100%; }
.client-footer { background: var(--navy); color: var(--white); padding: 24px 32px; text-align: center; }
.client-footer p { font-size: 0.85rem; color: rgba(255,255,255,0.7); }
.btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border-radius: 8px; font-size: 0.9rem; font-weight: 600; border: none; cursor: pointer; transition: all 0.2s; text-decoration: none; }
.btn-primary { background: var(--blue); color: white; }
.btn-outline { background: transparent; color: var(--navy); border: 1.5px solid var(--blue); }
.btn-sm { padding: 6px 12px; font-size: 0.8rem; }
.card { background: var(--white); border-radius: 12px; padding: 24px; box-shadow: var(--shadow); margin-bottom: 16px; border: 1px solid var(--border); }
.alert { padding: 12px 18px; border-radius: 8px; margin-bottom: 16px; font-size: 0.9rem; }
.alert-success { background: #dcfce7; color: #166534; border: 1px solid #86efac; }
.alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
.alert-info { background: #dbeafe; color: #1e40af; border: 1px solid #93c5fd; }
.alert-warn { background: #fef3c7; color: #92400e; border: 1px solid #fde68a; }
.badge { padding: 3px 10px; border-radius: 20px; font-size: 0.72rem; font-weight: 600; }
.badge-blue { background: rgba(0,159,227,0.12); color: var(--blue); }
.badge-green { background: rgba(24,184,58,0.12); color: var(--green); }
.badge-red { background: rgba(220,38,38,0.12); color: #DC2626; }
.badge-navy { background: rgba(6,59,143,0.12); color: var(--navy); }
.badge-amber { background: rgba(245,158,11,0.12); color: #F59E0B; }
.form-group { margin-bottom: 14px; }
.form-group label { display: block; margin-bottom: 6px; font-weight: 600; font-size: 0.85rem; }
.form-group input, .form-group textarea, .form-group select { width: 100%; padding: 10px 14px; border: 1px solid var(--border); border-radius: 8px; font-size: 0.95rem; font-family: inherit; }
.form-group input[type="checkbox"] { width: auto; }
.table { width: 100%; border-collapse: collapse; background: var(--white); border-radius: 12px; overflow: hidden; box-shadow: var(--shadow); }
.table th { background: var(--navy); color: var(--white); padding: 12px 16px; text-align: left; font-size: 0.85rem; font-weight: 600; }
.table td { padding: 12px 16px; border-bottom: 1px solid var(--border); font-size: 0.9rem; }
.grid { display: grid; gap: 16px; }
.grid-2 { grid-template-columns: repeat(2, 1fr); }
.grid-3 { grid-template-columns: repeat(3, 1fr); }
.grid-4 { grid-template-columns: repeat(4, 1fr); }
@media (max-width: 768px) {
.client-header { padding: 12px 16px; flex-direction: column; gap: 12px; }
.client-nav { flex-wrap: wrap; justify-content: center; }
.client-main { padding: 16px; }
.grid-2, .grid-3, .grid-4 { grid-template-columns: 1fr; }
}
</style>
@yield('head')
</head>
<body>
<div class="client-shell">
<header class="client-header">
<a href="{{ route('client.dashboard') }}" class="client-logo">
<div class="logo-mark">T</div>
<div>
<div class="logo-text">TECH360</div>
<div class="logo-slogan">Client Portal</div>
</div>
</a>
<nav class="client-nav">
<a href="{{ route('client.dashboard') }}" class="@if(request()->routeIs('client.dashboard')) active @endif"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
<a href="{{ route('client.refund.form') }}" class="@if(request()->routeIs('client.refund.*')) active @endif"><i class="fas fa-undo-alt"></i> Refund Request</a>
<form method="POST" action="{{ route('logout') }}" style="display:inline;">@csrf<button type="submit" class="btn btn-outline btn-sm"><i class="fas fa-sign-out-alt"></i> Logout</button></form>
</nav>
</header>

<main class="client-main">
@if(session('success'))
<div class="alert alert-success"><i class="fas fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if($errors->any())
<div class="alert alert-error">@foreach($errors->all() as $error)<div>{{ $error }}</div>@endforeach</div>
@endif
@yield('content')
</main>

<footer class="client-footer">
<p>© {{ date('Y') }} TECH360 LLC — Connect • Innovate • Grow — Client Portal</p>
</footer>
</div>
@yield('scripts')
</body>
</html>
