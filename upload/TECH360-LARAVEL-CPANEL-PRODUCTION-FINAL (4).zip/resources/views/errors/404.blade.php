@extends('layouts.app')
@section('title', '404 - Page Not Found | TECH360')
@section('content')
<section class="section" style="text-align:center;padding:120px 0;">
<h1 style="font-size:5rem;color:var(--navy);">404</h1>
<h2>Page Not Found</h2>
<p style="color:var(--secondary-text);margin:16px 0 32px;">The page you are looking for does not exist.</p>
<a href="{{ route('home') }}" class="btn btn-primary">Back to Home</a>
</section>
@endsection
