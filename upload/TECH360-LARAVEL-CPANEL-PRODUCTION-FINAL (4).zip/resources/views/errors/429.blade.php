@extends('layouts.app')
@section('title', '429 - Too Many Requests | TECH360')
@section('content')
<section class="section" style="text-align:center;padding:120px 0;">
<h1 style="font-size:5rem;color:var(--cyan);">429</h1>
<h2>Too Many Requests</h2>
<a href="{{ route('home') }}" class="btn btn-primary">Back to Home</a>
</section>
@endsection
