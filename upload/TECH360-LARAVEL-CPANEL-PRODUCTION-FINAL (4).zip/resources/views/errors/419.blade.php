@extends('layouts.app')
@section('title', '419 - Session Expired | TECH360')
@section('content')
<section class="section" style="text-align:center;padding:120px 0;">
<h1 style="font-size:5rem;color:var(--blue);">419</h1>
<h2>Session Expired</h2>
<a href="{{ route('login') }}" class="btn btn-primary">Login Again</a>
</section>
@endsection
