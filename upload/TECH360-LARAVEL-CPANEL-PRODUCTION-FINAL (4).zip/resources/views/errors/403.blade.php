@extends('layouts.app')
@section('title', '403 - Access Denied | TECH360')
@section('content')
<section class="section" style="text-align:center;padding:120px 0;">
<h1 style="font-size:5rem;color:var(--navy);">403</h1>
<h2>Access Denied</h2>
<a href="{{ route('home') }}" class="btn btn-primary">Back to Home</a>
</section>
@endsection
