@extends('layouts.app')
@section('title', '503 - Maintenance | TECH360')
@section('content')
<section class="section" style="text-align:center;padding:120px 0;">
<h1 style="font-size:5rem;color:var(--green);">503</h1>
<h2>Under Maintenance</h2>
</section>
@endsection
