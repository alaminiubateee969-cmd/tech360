@extends('layouts.admin')
@section('title', 'Payouts | TECH360 Admin')
@section('page-title', 'Payouts')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;">
<h2 style="margin:0;">Payouts <span style="color:var(--secondary-text);font-size:1rem;">({{ $payouts->total() }} total)</span></h2>
<a href="{{ route('admin.payouts.create') }}" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> New Payout</a>
</div>

<div style="background:#fef3c7;border:1px solid #fde68a;border-radius:12px;padding:16px;margin-bottom:24px;">
<strong><i class="fas fa-shield-alt"></i> Payout Risk Engine:</strong> Payouts ≥ $10,000 are eligible for instant processing. Payouts ≥ $20,000 require mandatory high-value review and cannot be auto-approved. Risk scores are computed automatically on creation.
</div>

<form method="GET" style="display:flex;gap:12px;margin-bottom:16px;">
<select name="status" style="padding:10px 14px;border:1px solid var(--border);border-radius:8px;">
<option value="">All Statuses</option>
@foreach(['pending','approved','processing','completed','failed','on_hold'] as $s)
<option value="{{ $s }}" @if(request('status')===$s) selected @endif>{{ ucfirst(str_replace('_',' ',$s)) }}</option>
@endforeach
</select>
<label style="display:flex;align-items:center;gap:6px;">
<input type="checkbox" name="high_value" value="1" @if(request('high_value')) checked @endif> High-value only
</label>
<button type="submit" class="btn btn-outline btn-sm"><i class="fas fa-filter"></i> Filter</button>
</form>

<div style="background:white;border-radius:12px;box-shadow:var(--shadow);overflow:hidden;">
<table class="table">
<thead><tr><th>Payout ID</th><th>Project</th><th>Amount</th><th>Recipient</th><th>Risk</th><th>Status</th><th>Actions</th></tr></thead>
<tbody>
@if($payouts->count())
@foreach($payouts as $payout)
<tr>
<td><code>{{ $payout->payout_id }}</code></td>
<td>{{ $payout->project?->name ?? '—' }}</td>
<td><strong>${{ number_format($payout->amount, 2) }}</strong> {{ $payout->currency }}</td>
<td>{{ ucfirst($payout->recipient_type) }}<br><small>{{ $payout->recipient_name ?? '—' }}</small></td>
<td>
@if($payout->high_value_review_required)
<span class="badge badge-red">HIGH ({{ $payout->risk_score }})</span>
@elseif($payout->risk_score > 30)
<span class="badge badge-blue">{{ $payout->risk_score }}</span>
@else
<span class="badge badge-green">{{ $payout->risk_score }}</span>
@endif
@if($payout->instant_payout_eligible)
<br><small style="color:var(--green);">Instant eligible</small>
@endif
</td>
<td><span class="badge badge-{{ $payout->status==='completed'?'green':($payout->status==='on_hold'?'red':($payout->status==='approved'?'blue':'navy')) }}">{{ ucfirst(str_replace('_',' ',$payout->status)) }}</span></td>
<td>
@if(in_array($payout->status, ['pending','on_hold']))
<form method="POST" action="{{ route('admin.payouts.approve', $payout) }}" style="display:inline;">@csrf<button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Approve payout?')">Approve</button></form>
@elseif($payout->status === 'approved')
<form method="POST" action="{{ route('admin.payouts.process', $payout) }}" style="display:inline;">@csrf<input type="text" name="provider_reference" placeholder="Provider ref" style="padding:6px;border:1px solid var(--border);border-radius:4px;font-size:0.8rem;width:120px;"><button type="submit" class="btn btn-sm btn-primary">Mark Processed</button></form>
@else
<span style="color:var(--secondary-text);font-size:0.85rem;">—</span>
@endif
</td>
</tr>
@endforeach
@else
<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--secondary-text);">No payouts yet.</td></tr>
@endif
</tbody>
</table>
</div>
{{ $payouts->links() }}
</div>
</section>
@endsection
