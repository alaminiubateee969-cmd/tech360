@extends('layouts.admin')
@section('title', 'Create Payout | TECH360 Admin')
@section('page-title', 'Create Payout')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container" style="max-width:680px;">
<h2>Create Payout</h2>
<p style="color:var(--secondary-text);margin-bottom:24px;">Risk assessment runs automatically on submit. Payouts ≥ $20,000 will be placed <strong>on hold</strong> for manual review.</p>

<div style="background:white;border-radius:16px;padding:32px;box-shadow:var(--shadow);">
<form method="POST" action="{{ route('admin.payouts.store') }}">@csrf
<div class="grid grid-2">
<div class="form-group"><label>Project</label>
<select name="project_id"><option value="">—</option>@foreach($projects as $p)<option value="{{ $p->id }}">{{ $p->project_id }} — {{ $p->name }}</option>@endforeach</select>
</div>
<div class="form-group"><label>Client</label>
<select name="client_id"><option value="">—</option>@foreach($clients as $c)<option value="{{ $c->id }}">{{ $c->client_id }} — {{ $c->name }}</option>@endforeach</select>
</div>
</div>
<div class="grid grid-2">
<div class="form-group"><label>Amount (USD) *</label><input type="number" name="amount" step="0.01" min="0.01" required></div>
<div class="form-group"><label>Currency</label><select name="currency"><option>USD</option><option>EUR</option><option>GBP</option></select></div>
</div>
<div class="grid grid-2">
<div class="form-group"><label>Recipient Type *</label>
<select name="recipient_type" required>
<option value="developer">Developer</option>
<option value="vendor">Vendor</option>
<option value="contractor">Contractor</option>
<option value="partner">Partner</option>
<option value="staff">Staff</option>
</select>
</div>
<div class="form-group"><label>Recipient Name</label><input type="text" name="recipient_name"></div>
</div>
<div class="form-group"><label>Account Reference (masked)</label><input type="text" name="recipient_account_reference" placeholder="e.g., ****1234"></div>
<div class="form-group"><label>Method</label>
<select name="method">
<option value="bank_transfer">Bank Transfer</option>
<option value="paypal">PayPal</option>
<option value="wise">Wise</option>
<option value="stripe_payout">Stripe Payout</option>
</select>
</div>
<div class="form-group"><label>Notes</label><textarea name="notes" rows="3"></textarea></div>
<button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Create Payout</button>
<a href="{{ route('admin.payouts.index') }}" class="btn btn-outline">Cancel</a>
</form>
</div>
</div>
</section>
@endsection
