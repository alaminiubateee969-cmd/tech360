@extends('layouts.admin')
@section('title', 'Admin: Clients | TECH360 LLC')
@section('page-title', 'Clients')
@section('content')

<h2>Clients <span style="color:var(--secondary-text);font-size:1rem;">({{ $clients->total() }} total)</span></h2>
<a href="{{ route('admin.dashboard') }}" class="btn btn-outline btn-sm" style="margin:16px 0;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>

<div style="background:white;border-radius:12px;box-shadow:var(--shadow);overflow:hidden;">
<table class="table">
<thead><tr><th>Client ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Company</th><th>Status</th><th>Projects</th></tr></thead>
<tbody>
@if($clients->count())
@foreach($clients as $client)
<tr>
<td><code>{{ $client->client_id }}</code></td>
<td>{{ $client->name ?? '—' }}</td>
<td><a href="mailto:{{ $client->email }}">{{ $client->email ?? '—' }}</a></td>
<td>{{ $client->phone ?? '—' }}</td>
<td>{{ $client->company ?? '—' }}</td>
<td><span class="badge badge-{{ $client->status==='active'?'green':'blue' }}">{{ ucfirst($client->status) }}</span></td>
<td>{{ $client->projects->count() }}</td>
</tr>
@endforeach
@else
<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--secondary-text);">No clients yet. New client registrations will appear here.</td></tr>
@endif
</tbody>
</table>
</div>
{{ $clients->links() }}
@endsection
