@extends('layouts.admin')
@section('title', 'Evidence Vault | TECH360 Admin')
@section('page-title', 'Evidence Vault')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;">
<h2 style="margin:0;">Evidence Vault <span style="color:var(--secondary-text);font-size:1rem;">({{ $evidence->total() }} items)</span></h2>
<button class="btn btn-primary btn-sm" onclick="document.getElementById('newEvidenceModal').style.display='block'"><i class="fas fa-plus"></i> Add Evidence</button>
</div>

<div style="background:#fee2e2;border:1px solid #fca5a5;border-radius:12px;padding:16px;margin-bottom:24px;">
<strong><i class="fas fa-lock"></i> No-Delete Policy:</strong> All evidence is cryptographically hashed (SHA-256) on upload and locked. Records can only be soft-deleted — never permanently destroyed. Every download and verification is audit-logged.
</div>

<form method="GET" style="display:flex;gap:12px;margin-bottom:16px;">
<select name="type" style="padding:10px 14px;border:1px solid var(--border);border-radius:8px;">
<option value="">All Types</option>
@foreach($types as $key => $label)
<option value="{{ $key }}" @if(request('type')===$key) selected @endif>{{ $label }}</option>
@endforeach
</select>
<button type="submit" class="btn btn-outline btn-sm"><i class="fas fa-filter"></i> Filter</button>
</form>

<div style="background:white;border-radius:12px;box-shadow:var(--shadow);overflow:hidden;">
<table class="table">
<thead><tr><th>Evidence ID</th><th>Type</th><th>Title</th><th>Hash</th><th>Event Date</th><th>Actions</th></tr></thead>
<tbody>
@if($evidence->count())
@foreach($evidence as $item)
<tr>
<td><code>{{ $item->evidence_id }}</code></td>
<td><span class="badge badge-blue">{{ ucfirst($item->type) }}</span></td>
<td><strong>{{ $item->title }}</strong><br><small style="color:var(--secondary-text);">{{ \Illuminate\Support\Str::limit($item->description ?? '', 80) }}</small></td>
<td><code style="font-size:0.7rem;">{{ $item->file_hash ? substr($item->file_hash, 0, 16) . '...' : '—' }}</code></td>
<td>{{ $item->event_at ? $item->event_at->format('M d, Y') : '—' }}</td>
<td>
<a href="{{ route('admin.evidence.show', $item) }}" class="btn btn-sm btn-outline">View</a>
<form method="POST" action="{{ route('admin.evidence.verify', $item) }}" style="display:inline;">@csrf<button type="submit" class="btn btn-sm btn-outline" title="Verify integrity"><i class="fas fa-check-double"></i></button></form>
@if($item->file_path)
<a href="{{ route('admin.evidence.download', $item) }}" class="btn btn-sm btn-outline"><i class="fas fa-download"></i></a>
@endif
</td>
</tr>
@endforeach
@else
<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--secondary-text);">No evidence yet.</td></tr>
@endif
</tbody>
</table>
</div>
{{ $evidence->links() }}
</div>
</section>

<div id="newEvidenceModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:2000;align-items:center;justify-content:center;" onclick="if(event.target===this)this.style.display='none'">
<div style="background:white;border-radius:16px;padding:32px;max-width:560px;width:90%;max-height:90vh;overflow-y:auto;">
<h3 style="margin-bottom:16px;">Add Evidence</h3>
<form method="POST" action="{{ route('admin.evidence.store') }}" enctype="multipart/form-data">@csrf
<div class="form-group"><label>Type *</label>
<select name="type" required>
@foreach($types as $key => $label)<option value="{{ $key }}">{{ $label }}</option>@endforeach
</select>
</div>
<div class="grid grid-2">
<div class="form-group"><label>Project</label>
<select name="project_id"><option value="">—</option>@foreach(\App\Models\Project::orderBy('name')->get() as $p)<option value="{{ $p->id }}">{{ $p->project_id }} — {{ $p->name }}</option>@endforeach</select>
</div>
<div class="form-group"><label>Client</label>
<select name="client_id"><option value="">—</option>@foreach(\App\Models\Client::orderBy('name')->get() as $c)<option value="{{ $c->id }}">{{ $c->client_id }} — {{ $c->name }}</option>@endforeach</select>
</div>
</div>
<div class="form-group"><label>Title *</label><input type="text" name="title" required></div>
<div class="form-group"><label>Description</label><textarea name="description" rows="3"></textarea></div>
<div class="form-group"><label>Event Date</label><input type="datetime-local" name="event_at"></div>
<div class="form-group"><label>File (max 10MB; allowed: pdf, png, jpg, gif, txt, csv, json, zip)</label><input type="file" name="file"></div>
<button type="submit" class="btn btn-primary">Store Evidence</button>
<button type="button" onclick="document.getElementById('newEvidenceModal').style.display='none'" class="btn btn-outline">Cancel</button>
</form>
</div>
</div>
@endsection
