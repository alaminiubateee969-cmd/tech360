@extends('layouts.admin')
@section('title', 'Evidence: ' . $evidence->evidence_id . ' | TECH360 Admin')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container" style="max-width:900px;">
<a href="{{ route('admin.evidence.index') }}" class="btn btn-outline btn-sm" style="margin-bottom:16px;"><i class="fas fa-arrow-left"></i> Back to Vault</a>

<div style="background:white;border-radius:16px;padding:32px;box-shadow:var(--shadow);margin-bottom:24px;">
<div style="display:flex;justify-content:space-between;align-items:start;">
<div>
<h2>{{ $evidence->title }}</h2>
<p style="color:var(--secondary-text);"><code>{{ $evidence->evidence_id }}</code> • <span class="badge badge-blue">{{ ucfirst($evidence->type) }}</span> • @if($evidence->is_locked)<span class="badge badge-green"><i class="fas fa-lock"></i> Locked</span>@endif</p>
</div>
<form method="POST" action="{{ route('admin.evidence.verify', $evidence) }}">@csrf<button type="submit" class="btn btn-outline btn-sm"><i class="fas fa-check-double"></i> Verify Integrity</button></form>
</div>
<hr style="border:none;border-top:1px solid var(--border);margin:20px 0;">
<div class="grid grid-2">
<div><strong>Project:</strong><br>{{ $evidence->project?->name ?? '—' }}</div>
<div><strong>Client:</strong><br>{{ $evidence->client?->name ?? '—' }}</div>
<div><strong>Event Date:</strong><br>{{ $evidence->event_at ? $evidence->event_at->format('M d, Y H:i') : '—' }}</div>
<div><strong>Uploaded:</strong><br>{{ $evidence->created_at ? $evidence->created_at->format('M d, Y H:i') : '—' }} by {{ $evidence->uploader?->name ?? 'System' }}</div>
</div>
@if($evidence->description)
<p style="margin-top:16px;"><strong>Description:</strong><br>{{ $evidence->description }}</p>
@endif
@if($evidence->file_path)
<div style="margin-top:16px;padding:16px;background:#f8fafc;border-radius:8px;">
<strong>File:</strong> <code>{{ basename($evidence->file_path) }}</code><br>
<strong>SHA-256 Hash:</strong> <code style="word-break:break-all;">{{ $evidence->file_hash }}</code><br>
<a href="{{ route('admin.evidence.download', $evidence) }}" class="btn btn-sm btn-primary" style="margin-top:8px;"><i class="fas fa-download"></i> Download</a>
</div>
@endif
@if($evidence->metadata)
<div style="margin-top:16px;padding:16px;background:#f8fafc;border-radius:8px;">
<strong>Metadata:</strong>
<pre style="white-space:pre-wrap;font-size:0.85rem; margin-top:8px;">{{ json_encode($evidence->metadata, JSON_PRETTY_PRINT) }}</pre>
</div>
@endif
</div>

<div style="background:#fee2e2;border:1px solid #fca5a5;border-radius:12px;padding:16px;">
<strong><i class="fas fa-shield-alt"></i> No-Delete Policy:</strong> This evidence is locked and cannot be permanently deleted. Soft-deletion preserves the record in the database with a `deleted_at` timestamp; the file on disk is preserved; the hash is preserved. Only authorized admins with documented reason can soft-delete.
@if($evidence->deleted_at)
<br><strong>Status:</strong> <span class="badge badge-red">Soft-deleted {{ $evidence->deleted_at->diffForHumans() }}</span>
@endif
</div>
</div>
</section>
@endsection
