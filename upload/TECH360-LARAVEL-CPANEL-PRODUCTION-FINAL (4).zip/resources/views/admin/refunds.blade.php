@extends('layouts.admin')
@section('title', 'Admin: Refund Requests | TECH360 LLC')
@section('page-title', 'Refund Requests')
@section('content')

<h2>Refund Requests <span style="color:var(--secondary-text);font-size:1rem;">({{ $refunds->total() }} total)</span></h2>
<a href="{{ route('admin.dashboard') }}" class="btn btn-outline btn-sm" style="margin:16px 0;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>

<div style="background:#fef3c7;border:1px solid #fde68a;border-radius:12px;padding:16px;margin-bottom:24px;">
<strong><i class="fas fa-exclamation-triangle"></i> Refund Policy:</strong> After Scope of Work approval, payments are non-refundable except where required by applicable law or otherwise agreed in writing. Each refund decision is audited and cannot be undone.
</div>

<div style="background:white;border-radius:12px;box-shadow:var(--shadow);overflow:hidden;">
<table class="table">
<thead><tr><th>Refund ID</th><th>Client</th><th>Reason</th><th>Status</th><th>Reviewed</th><th>Actions</th></tr></thead>
<tbody>
@if($refunds->count())
@foreach($refunds as $refund)
<tr>
<td><code>{{ $refund->refund_id }}</code></td>
<td>{{ $refund->client?->name ?? '—' }}</td>
<td>{{ \Illuminate\Support\Str::limit($refund->reason ?? '—', 60) }}</td>
<td><span class="badge badge-{{ $refund->status==='approved'?'green':($refund->status==='denied'?'red':'blue') }}">{{ str_replace('_', ' ', ucfirst($refund->status)) }}</span></td>
<td>{{ $refund->reviewed_at ? $refund->reviewed_at->format('M d, Y') : '—' }}</td>
<td>
@if(in_array($refund->status, ['refund_requested', 'refund_review', 'pending']))
<form method="POST" action="{{ route('admin.refund.review', $refund->id) }}" style="display:inline;">@csrf
<input type="hidden" name="decision" value="approved">
<button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Approve refund? This is irreversible.')"><i class="fas fa-check"></i> Approve</button>
</form>
<form method="POST" action="{{ route('admin.refund.review', $refund->id) }}" style="display:inline;">@csrf
<input type="hidden" name="decision" value="denied">
<button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Deny refund? This is irreversible.')"><i class="fas fa-times"></i> Deny</button>
</form>
@else
<span style="color:var(--secondary-text);font-size:0.85rem;">Reviewed</span>
@endif
</td>
</tr>
@endforeach
@else
<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--secondary-text);">No refund requests.</td></tr>
@endif
</tbody>
</table>
</div>
{{ $refunds->links() }}
@endsection
