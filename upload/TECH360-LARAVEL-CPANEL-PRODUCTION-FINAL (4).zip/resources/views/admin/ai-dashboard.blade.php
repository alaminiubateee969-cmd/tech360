@extends('layouts.admin')
@section('title', 'AI Command Center | TECH360')
@section('page-title', 'AI Command Center')
@section('content')

<div class="stat-grid">
<div class="stat-card green"><div class="number" style="color:var(--green);">{{ $stats['active_agents'] }}</div><div class="label">Active Agents</div></div>
<div class="stat-card blue"><div class="number" style="color:var(--blue);">{{ $stats['running_tasks'] }}</div><div class="label">Running Tasks</div></div>
<div class="stat-card cyan"><div class="number" style="color:var(--cyan);">{{ $stats['completed_tasks'] }}</div><div class="label">Completed</div></div>
<div class="stat-card amber"><div class="number" style="color:#F59E0B;">{{ $stats['pending_approvals'] }}</div><div class="label">Pending Approvals</div></div>
<div class="stat-card navy"><div class="number">{{ $stats['failed_tasks'] }}</div><div class="label">Failed</div></div>
<div class="stat-card green"><div class="number">{{ $stats['total_tools'] }}</div><div class="label">Active Tools</div></div>
<div class="stat-card blue"><div class="number">{{ $stats['workflows'] }}</div><div class="label">Workflows</div></div>
<div class="stat-card cyan"><div class="number">{{ $stats['knowledge_docs'] }}</div><div class="label">Knowledge Docs</div></div>
</div>

<div class="card">
<h3 style="margin-bottom:16px;"><i class="fas fa-terminal" style="color:var(--blue);"></i> AI Command Interface</h3>
<p style="color:var(--secondary-text);margin-bottom:16px;font-size:0.9rem;">Type a natural language command. The system routes it to the appropriate AI agent based on keywords. Every command creates a real execution record — no demo responses.</p>
<form method="POST" action="{{ route('admin.ai.command') }}">@csrf
<div style="display:flex;gap:12px;">
<input type="text" name="command" placeholder='Try: "Show high priority leads" or "Generate weekly report" or "Search contacts for John"' style="flex:1;padding:12px 16px;border:1px solid var(--border);border-radius:8px;font-size:0.95rem;" required>
<button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Execute</button>
</div>
</form>
</div>

<div class="card">
<h3 style="margin-bottom:16px;">Agents ({{ $agents->count() }})</h3>
<table class="table">
<thead><tr><th>Agent</th><th>Provider</th><th>Mode</th><th>Status</th><th>Executions</th><th>Actions</th></tr></thead>
<tbody>
@foreach($agents as $agent)
<tr>
<td>
<a href="{{ route('admin.ai.agents.show', $agent) }}" style="font-weight:600;">{{ $agent->name }}</a><br>
<span style="font-size:0.7rem;color:var(--secondary-text);">{{ $agent->agent_id }}</span>
</td>
<td>{{ $agent->provider }}</td>
<td><span class="badge badge-blue">{{ $agent->mode }}</span></td>
<td><span class="badge {{ $agent->status=='active'?'badge-green':'badge-red' }}">{{ $agent->status }}</span></td>
<td>{{ $agent->executions_count }}</td>
<td>
<form method="POST" action="{{ route('admin.ai.agents.toggle', $agent) }}" style="display:inline;">@csrf<button type="submit" class="btn btn-sm btn-outline">{{ $agent->status=='active'?'Disable':'Enable' }}</button></form>
<a href="{{ route('admin.ai.agents.show', $agent) }}" class="btn btn-sm btn-outline">View</a>
</td>
</tr>
@endforeach
</tbody>
</table>
</div>

@if($pendingApprovals->isNotEmpty())
<div class="card">
<h3 style="margin-bottom:16px;color:#F59E0B;"><i class="fas fa-clock"></i> Pending Approvals ({{ $pendingApprovals->count() }})</h3>
<table class="table">
<thead><tr><th>Approval ID</th><th>Agent</th><th>Action</th><th>Risk</th><th>Actions</th></tr></thead>
<tbody>
@foreach($pendingApprovals as $approval)
<tr>
<td style="font-size:0.8rem;">{{ $approval->approval_id }}</td>
<td>{{ $approval->agent?->name ?? '—' }}</td>
<td>{{ $approval->action }}</td>
<td><span class="badge {{ $approval->risk_level=='high'?'badge-red':($approval->risk_level=='medium'?'badge-amber':'badge-green') }}">{{ $approval->risk_level }}</span></td>
<td>
<form method="POST" action="{{ route('admin.ai.approvals.approve', $approval) }}" style="display:inline;">@csrf<button type="submit" class="btn btn-sm btn-success">Approve</button></form>
<form method="POST" action="{{ route('admin.ai.approvals.reject', $approval) }}" style="display:inline;">@csrf<input type="hidden" name="review_note" value="Rejected by admin"><button type="submit" class="btn btn-sm btn-danger">Reject</button></form>
</td>
</tr>
@endforeach
</tbody>
</table>
</div>
@endif

<div class="card">
<h3 style="margin-bottom:16px;">Recent Executions</h3>
<table class="table">
<thead><tr><th>Execution ID</th><th>Agent</th><th>Status</th><th>Tokens</th><th>Time</th></tr></thead>
<tbody>
@foreach($recentExecutions as $exec)
<tr>
<td style="font-size:0.8rem;">{{ $exec->execution_id }}</td>
<td>{{ $exec->agent?->name ?? '—' }}</td>
<td><span class="badge {{ $exec->status=='completed'?'badge-green':($exec->status=='failed'?'badge-red':($exec->status=='awaiting_approval'?'badge-amber':'badge-blue')) }}">{{ str_replace('_',' ',$exec->status) }}</span></td>
<td>{{ ($exec->tokens_input ?? 0) + ($exec->tokens_output ?? 0) }}</td>
<td>{{ $exec->created_at ? $exec->created_at->diffForHumans() : '—' }}</td>
</tr>
@endforeach
</tbody>
</table>
</div>
@endsection
