@extends('layouts.admin')
@section('title', 'Admin Dashboard | TECH360 LLC')
@section('page-title', 'Dashboard')
@section('content')

<div class="stat-grid">
<div class="stat-card blue"><div class="number">{{ $stats['clients'] }}</div><div class="label">Clients</div></div>
<div class="stat-card navy"><div class="number">{{ $stats['projects'] }}</div><div class="label">Projects</div></div>
<div class="stat-card amber"><div class="number">{{ $stats['payments_pending'] }}</div><div class="label">Payments Pending</div></div>
<div class="stat-card green"><div class="number">{{ $stats['payments_paid'] }}</div><div class="label">Payments Paid</div></div>
<div class="stat-card red"><div class="number">{{ $stats['refunds_pending'] }}</div><div class="label">Refunds Pending</div></div>
</div>

<div class="card">
<h3 style="margin-bottom:16px;"><i class="fas fa-bolt" style="color:var(--blue);"></i> Quick Actions</h3>
<div style="display:flex;flex-wrap:wrap;gap:8px;">
<a href="{{ route('admin.clients') }}" class="btn btn-primary btn-sm"><i class="fas fa-users"></i> Clients</a>
<a href="{{ route('admin.projects') }}" class="btn btn-primary btn-sm"><i class="fas fa-project-diagram"></i> Projects</a>
<a href="{{ route('admin.payments') }}" class="btn btn-primary btn-sm"><i class="fas fa-credit-card"></i> Payments</a>
<a href="{{ route('admin.refunds') }}" class="btn btn-primary btn-sm"><i class="fas fa-undo-alt"></i> Refunds</a>
<a href="{{ route('admin.payouts.index') }}" class="btn btn-primary btn-sm"><i class="fas fa-money-bill-wave"></i> Payouts</a>
<a href="{{ route('admin.evidence.index') }}" class="btn btn-primary btn-sm"><i class="fas fa-vault"></i> Evidence Vault</a>
<a href="{{ route('admin.disputes.index') }}" class="btn btn-primary btn-sm"><i class="fas fa-gavel"></i> Disputes</a>
<a href="{{ route('admin.audit') }}" class="btn btn-primary btn-sm"><i class="fas fa-history"></i> Audit Logs</a>
<a href="{{ route('crm.dashboard') }}" class="btn btn-outline btn-sm"><i class="fas fa-chart-pie"></i> CRM</a>
<a href="{{ route('admin.ai.dashboard') }}" class="btn btn-outline btn-sm"><i class="fas fa-robot"></i> AI Dashboard</a>
<a href="{{ route('admin.ai.agents') }}" class="btn btn-outline btn-sm"><i class="fas fa-microchip"></i> AI Agents</a>
<a href="{{ route('admin.ai.approvals') }}" class="btn btn-outline btn-sm"><i class="fas fa-check-double"></i> AI Approvals</a>
<a href="{{ route('admin.ai.knowledge') }}" class="btn btn-outline btn-sm"><i class="fas fa-book"></i> Knowledge Base</a>
<a href="{{ route('admin.cms.services') }}" class="btn btn-outline btn-sm"><i class="fas fa-cogs"></i> CMS</a>
</div>
</div>

<div class="alert alert-info">
<strong><i class="fas fa-info-circle"></i> Default Admin Login:</strong> <code>admin@tech360.io</code> — the password is printed to console output when running the DatabaseSeeder. Change it immediately after first login via: <code>php artisan tinker</code> → <code>User::where('email','admin@tech360.io')->update(['password' => bcrypt('new-password')])</code>
</div>
@endsection
