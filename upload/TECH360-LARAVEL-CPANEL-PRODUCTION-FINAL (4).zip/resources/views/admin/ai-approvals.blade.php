@extends('layouts.admin')
@section('title', 'AI Approvals | TECH360')
@section('page-title', 'AI Approvals')
@section('content')

<h2>AI Approval Center</h2>
<p style="color:var(--secondary-text);margin-bottom:24px;">Every action that requires human review must be approved here. AI must never bypass approval rules.</p>

<table class="table">
<thead><tr><th>Approval ID</th><th>Agent</th><th>Action</th><th>Risk</th><th>Status</th><th>Submitted</th><th>Actions</th></tr></thead>
<tbody>
@if($approvals->count())
@foreach($approvals as $approval)
<tr>
<td style="font-size:0.8rem;">{{ $approval->approval_id }}</td>
<td>{{ $approval->agent?->name ?? '—' }}</td>
<td>{{ $approval->action }}</td>
<td><span class="badge {{ $approval->risk_level=='high'?'badge-red':($approval->risk_level=='medium'?'badge-blue':'badge-green') }}">{{ $approval->risk_level }}</span></td>
<td><span class="badge {{ $approval->status=='pending'?'badge-blue':($approval->status=='approved'?'badge-green':'badge-red') }}">{{ $approval->status }}</span></td>
<td>{{ $approval->created_at ? $approval->created_at->diffForHumans() : '—' }}</td>
<td>
@if($approval->status=='pending')
<form method="POST" action="{{ route('admin.ai.approvals.approve', $approval) }}" style="display:inline;">@csrf<button type="submit" class="btn btn-sm btn-success">Approve</button></form>
<form method="POST" action="{{ route('admin.ai.approvals.reject', $approval) }}" style="display:inline;">@csrf<input type="hidden" name="review_note" value="Rejected by admin"><button type="submit" class="btn btn-sm btn-danger">Reject</button></form>
@else
<span style="color:var(--secondary-text);">—</span>
@endif
</td>
</tr>
@endforeach
@else
<tr><td colspan="7" style="text-align:center;padding:48px;color:var(--secondary-text);">No approvals found.</td></tr>
@endif
</tbody>
</table>
{{ $approvals->links() }}
@endsection
