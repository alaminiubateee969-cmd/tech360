@extends('layouts.admin')
@section('title', 'AI Command Center | TECH360 LLC')
@section('page-title', 'AI Command Center')
@section('content')

<h2>AI Command Center</h2>
<p style="color:var(--muted);margin-bottom:24px;">Private admin view. AI agents can recommend but never execute commercial actions.</p>

<div class="grid" style="margin-bottom:24px;">
<div class="card"><h3>Running</h3><p style="font-size:2rem;color:var(--blue);">{{ $runningJobs->count() }}</p></div>
<div class="card"><h3>Queued</h3><p style="font-size:2rem;color:orange;">{{ $queuedJobs->count() }}</p></div>
<div class="card"><h3>Completed</h3><p style="font-size:2rem;color:green;">{{ $completedJobs->count() }}</p></div>
<div class="card"><h3>Failed</h3><p style="font-size:2rem;color:red;">{{ $failedJobs->count() }}</p></div>
</div>

<h3>Recommendations (require human approval)</h3>
@if($recommendations)
<table style="width:100%;border-collapse:collapse;margin-top:12px;">
<tr style="background:#052E6F;color:white;"><th style="padding:8px;text-align:left;">Job ID</th><th style="padding:8px;text-align:left;">Type</th><th style="padding:8px;text-align:left;">Agent</th><th style="padding:8px;text-align:left;">Status</th></tr>
@foreach(array_slice($recommendations, 0, 10) as $rec)
<tr style="border-bottom:1px solid #E2E8F0;">
<td style="padding:8px;">{{ $rec['job_id'] }}</td>
<td style="padding:8px;">{{ $rec['job_type'] }}</td>
<td style="padding:8px;">{{ $rec['agent_name'] }}</td>
<td style="padding:8px;">{{ $rec['status'] }}</td>
</tr>
@endforeach
</table>
@else
<p>No recommendations pending.</p>
@endif

<h3 style="margin-top:24px;">Recent Jobs</h3>
<table style="width:100%;border-collapse:collapse;margin-top:12px;">
<tr style="background:#052E6F;color:white;"><th style="padding:8px;text-align:left;">Job ID</th><th style="padding:8px;text-align:left;">Type</th><th style="padding:8px;text-align:left;">Status</th><th style="padding:8px;text-align:left;">Completed</th></tr>
@foreach($completedJobs->take(10) as $job)
<tr style="border-bottom:1px solid #E2E8F0;">
<td style="padding:8px;">{{ $job->job_id }}</td>
<td style="padding:8px;">{{ $job->job_type }}</td>
<td style="padding:8px;">{{ $job->status }}</td>
<td style="padding:8px;">{{ $job->completed_at ?? '—' }}</td>
</tr>
@endforeach
</table>
@endsection
