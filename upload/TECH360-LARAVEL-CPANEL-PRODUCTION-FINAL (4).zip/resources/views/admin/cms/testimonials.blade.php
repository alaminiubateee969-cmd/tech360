@extends('layouts.admin')
@section('title', 'CMS: Testimonials | TECH360 Admin')
@section('page-title', 'CMS: Testimonials')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container">
<h2>CMS: Testimonials</h2>
<button class="btn btn-primary btn-sm" style="margin:16px 0;" onclick="document.getElementById('newTestModal').style.display='block'"><i class="fas fa-plus"></i> Add Testimonial</button>

<table class="table">
<thead><tr><th>Author</th><th>Quote</th><th>Rating</th><th>Active</th></tr></thead>
<tbody>
@if($items->count())
@foreach($items as $item)
<tr>
<td>{{ $item->author_name }}</td>
<td>{{ \Illuminate\Support\Str::limit($item->content, 80) }}</td>
<td>{{ $item->rating ?? 5 }}/5</td>
<td><span class="badge {{ $item->is_active?'badge-green':'badge-red' }}">{{ $item->is_active?'Active':'Inactive' }}</span></td>
</tr>
@endforeach
@else
<tr><td colspan="4" style="text-align:center;padding:32px;color:var(--secondary-text);">No testimonials yet.</td></tr>
@endif
</tbody>
</table>
{{ $items->links() }}
</div>
</section>
@endsection
