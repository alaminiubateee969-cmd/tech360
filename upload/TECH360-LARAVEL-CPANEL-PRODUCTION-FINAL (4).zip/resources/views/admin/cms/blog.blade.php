@extends('layouts.admin')
@section('title', 'CMS: Blog | TECH360 Admin')
@section('page-title', 'CMS: Blog')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container">
<h2>CMS: Blog Posts</h2>
<button class="btn btn-primary btn-sm" style="margin:16px 0;" onclick="document.getElementById('newBlogModal').style.display='block'"><i class="fas fa-plus"></i> New Post</button>

<table class="table">
<thead><tr><th>Title</th><th>Slug</th><th>Status</th><th>Published</th></tr></thead>
<tbody>
@if($posts->count())
@foreach($posts as $post)
<tr>
<td>{{ $post->title }}</td>
<td><code>{{ $post->slug }}</code></td>
<td><span class="badge {{ $post->status=='published'?'badge-green':'badge-blue' }}">{{ $post->status }}</span></td>
<td>{{ $post->published_at ? $post->published_at->format('M d, Y') : '—' }}</td>
</tr>
@endforeach
@else
<tr><td colspan="4" style="text-align:center;padding:32px;color:var(--secondary-text);">No posts yet.</td></tr>
@endif
</tbody>
</table>
{{ $posts->links() }}
</div>
</section>
@endsection
