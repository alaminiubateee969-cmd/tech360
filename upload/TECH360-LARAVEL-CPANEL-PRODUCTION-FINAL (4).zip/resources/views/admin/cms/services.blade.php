@extends('layouts.admin')
@section('title', 'CMS: Services | TECH360 Admin')
@section('page-title', 'CMS: Services')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container">
<h2>CMS: Services</h2>
<button class="btn btn-primary btn-sm" style="margin:16px 0;" onclick="document.getElementById('newServiceModal').style.display='block'"><i class="fas fa-plus"></i> Add Service</button>

<table class="table">
<thead><tr><th>Slug</th><th>Title</th><th>Icon</th><th>Active</th><th>Order</th></tr></thead>
<tbody>
@if($services->count())
@foreach($services as $service)
<tr>
<td><code>{{ $service->slug }}</code></td>
<td>{{ $service->title }}</td>
<td>{{ $service->icon }}</td>
<td><span class="badge {{ $service->is_active?'badge-green':'badge-red' }}">{{ $service->is_active?'Active':'Inactive' }}</span></td>
<td>{{ $service->sort_order ?? 0 }}</td>
</tr>
@endforeach
@else
<tr><td colspan="5" style="text-align:center;padding:32px;color:var(--secondary-text);">No services. Run DatabaseSeeder.</td></tr>
@endif
</tbody>
</table>
{{ $services->links() }}

<div id="newServiceModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:2000;align-items:center;justify-content:center;" onclick="if(event.target===this)this.style.display='none'">
<div style="background:white;border-radius:16px;padding:32px;max-width:560px;width:90%;">
<h3>Add Service</h3>
<form method="POST" action="{{ route('admin.cms.services.store') }}">@csrf
<div class="form-group"><label>Title *</label><input type="text" name="title" required></div>
<div class="form-group"><label>Slug *</label><input type="text" name="slug" required pattern="[a-z0-9-]+"></div>
<div class="form-group"><label>Icon (Font Awesome)</label><input type="text" name="icon" value="fa-code" placeholder="fa-code"></div>
<div class="form-group"><label>Short Description</label><input type="text" name="short_description"></div>
<div class="form-group"><label>Description</label><textarea name="description" rows="3"></textarea></div>
<button type="submit" class="btn btn-primary">Create</button>
</form>
</div>
</div>
</div>
</section>
@endsection
