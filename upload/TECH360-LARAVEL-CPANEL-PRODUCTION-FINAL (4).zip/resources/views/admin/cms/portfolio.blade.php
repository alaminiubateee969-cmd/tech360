@extends('layouts.admin')
@section('title', 'CMS: Portfolio | TECH360 Admin')
@section('page-title', 'CMS: Portfolio')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container">
<h2>CMS: Portfolio</h2>
<button class="btn btn-primary btn-sm" style="margin:16px 0;" onclick="document.getElementById('newPortfolioModal').style.display='block'"><i class="fas fa-plus"></i> Add Portfolio Item</button>

<table class="table">
<thead><tr><th>Title</th><th>Slug</th><th>Active</th><th>Created</th></tr></thead>
<tbody>
@if($items->count())
@foreach($items as $item)
<tr>
<td>{{ $item->title }}</td>
<td><code>{{ $item->slug }}</code></td>
<td><span class="badge {{ $item->is_active?'badge-green':'badge-red' }}">{{ $item->is_active?'Active':'Inactive' }}</span></td>
<td>{{ $item->created_at ? $item->created_at->format('M d, Y') : '—' }}</td>
</tr>
@endforeach
@else
<tr><td colspan="4" style="text-align:center;padding:32px;color:var(--secondary-text);">No portfolio items.</td></tr>
@endif
</tbody>
</table>
{{ $items->links() }}
</div>
</section>
@endsection
