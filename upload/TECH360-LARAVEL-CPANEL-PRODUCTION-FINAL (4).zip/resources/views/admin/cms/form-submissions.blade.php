@extends('layouts.admin')
@section('title', 'Form Submissions | TECH360 Admin')
@section('page-title', 'Form Submissions')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container">
<h2>Contact Form Submissions</h2>
<p style="color:var(--secondary-text);margin-bottom:24px;">All submissions from the public contact form. Each creates a contact + lead in CRM.</p>

<table class="table">
<thead><tr><th>Received</th><th>Name</th><th>Email</th><th>Phone</th><th>Message</th></tr></thead>
<tbody>
@if($submissions->count())
@foreach($submissions as $sub)
<tr>
<td>{{ $sub->created_at ? $sub->created_at->format('M d, Y H:i') : '—' }}</td>
<td>{{ $sub->name }}</td>
<td><a href="mailto:{{ $sub->email }}">{{ $sub->email }}</a></td>
<td>{{ $sub->phone ?? '—' }}</td>
<td>{{ \Illuminate\Support\Str::limit($sub->message, 80) }}</td>
</tr>
@endforeach
@else
<tr><td colspan="5" style="text-align:center;padding:32px;color:var(--secondary-text);">No submissions yet.</td></tr>
@endif
</tbody>
</table>
{{ $submissions->links() }}
</div>
</section>
@endsection
