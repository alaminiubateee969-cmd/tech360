@extends('layouts.admin')
@section('title', 'CMS: Settings | TECH360 Admin')
@section('page-title', 'CMS: Settings')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container">
<h2>CMS: Settings</h2>
<p style="color:var(--secondary-text);margin-bottom:24px;">Application settings grouped by category.</p>

<div style="background:white;border-radius:12px;box-shadow:var(--shadow);overflow:hidden;">
<table class="table">
<thead><tr><th>Key</th><th>Value</th><th>Category</th></tr></thead>
<tbody>
@if($settings->count())
@foreach($settings as $setting)
<tr>
<td><code>{{ $setting->key }}</code></td>
<td>{{ \Illuminate\Support\Str::limit($setting->value, 100) }}</td>
<td><span class="badge badge-blue">{{ ucfirst($setting->category) }}</span></td>
</tr>
@endforeach
@else
<tr><td colspan="3" style="text-align:center;padding:32px;color:var(--secondary-text);">No settings. Run DatabaseSeeder.</td></tr>
@endif
</tbody>
</table>
</div>
</div>
</section>
@endsection
