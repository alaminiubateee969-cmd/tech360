@extends('layouts.admin')
@section('title', 'Disputes & Chargebacks | TECH360 Admin')
@section('page-title', 'Disputes & Chargebacks')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;">
<h2 style="margin:0;">Disputes & Chargebacks <span style="color:var(--secondary-text);font-size:1rem;">({{ $disputes->total() }} total)</span></h2>
<a href="{{ route('admin.disputes.create') }}" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Open Dispute</a>
</div>

<div style="background:#fef3c7;border:1px solid #fde68a;border-radius:12px;padding:16px;margin-bottom:24px;">
<strong><i class="fas fa-gavel"></i> Dispute Workflow:</strong> When a chargeback or dispute is received, the system auto-compiles an evidence package from all related records (communications, payments, contracts, deliveries, audit logs). The compiled package is hashed with SHA-256 for tamper-evidence.
</div>

<form method="GET" style="display:flex;gap:12px;margin-bottom:16px;">
<select name="status" style="padding:10px 14px;border:1px solid var(--border);border-radius:8px;">
<option value="">All Statuses</option>
@foreach(['open','evidence_compiling','evidence_submitted','won','lost','expired'] as $s)
<option value="{{ $s }}" @if(request('status')===$s) selected @endif>{{ ucfirst(str_replace('_',' ',$s)) }}</option>
@endforeach
</select>
<button type="submit" class="btn btn-outline btn-sm"><i class="fas fa-filter"></i> Filter</button>
</form>

<div style="background:white;border-radius:12px;box-shadow:var(--shadow);overflow:hidden;">
<table class="table">
<thead><tr><th>Dispute ID</th><th>Source</th><th>Amount</th><th>Case #</th><th>Status</th><th>Respond By</th><th>Actions</th></tr></thead>
<tbody>
@if($disputes->count())
@foreach($disputes as $dispute)
<tr>
<td><code>{{ $dispute->dispute_id }}</code></td>
<td><span class="badge badge-blue">{{ ucfirst(str_replace('_',' ',$dispute->source)) }}</span></td>
<td><strong>${{ number_format($dispute->disputed_amount, 2) }}</strong></td>
<td>{{ $dispute->case_number ?? '—' }}</td>
<td><span class="badge badge-{{ $dispute->status==='won'?'green':($dispute->status==='lost'?'red':($dispute->status==='expired'?'navy':'blue')) }}">{{ ucfirst(str_replace('_',' ',$dispute->status)) }}</span></td>
<td>{{ $dispute->respond_by ? $dispute->respond_at->format('M d, Y') : '—' }}</td>
<td>
<a href="{{ route('admin.disputes.show', $dispute) }}" class="btn btn-sm btn-outline">View</a>
@if(in_array($dispute->status, ['open','evidence_compiling']))
<form method="POST" action="{{ route('admin.disputes.compile', $dispute) }}" style="display:inline;">@csrf<button type="submit" class="btn btn-sm btn-primary"><i class="fas fa-bolt"></i> Compile Evidence</button></form>
@endif
</td>
</tr>
@endforeach
@else
<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--secondary-text);">No disputes yet.</td></tr>
@endif
</tbody>
</table>
</div>
{{ $disputes->links() }}
</div>
</section>
@endsection
