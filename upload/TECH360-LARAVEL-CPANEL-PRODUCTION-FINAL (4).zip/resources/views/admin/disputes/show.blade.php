@extends('layouts.admin')
@section('title', 'Dispute: ' . $dispute->dispute_id . ' | TECH360 Admin')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container" style="max-width:900px;">
<a href="{{ route('admin.disputes.index') }}" class="btn btn-outline btn-sm" style="margin-bottom:16px;"><i class="fas fa-arrow-left"></i> Back to Disputes</a>

<div style="background:white;border-radius:16px;padding:32px;box-shadow:var(--shadow);margin-bottom:24px;">
<div style="display:flex;justify-content:space-between;align-items:start;">
<div>
<h2>{{ $dispute->dispute_id }}</h2>
<p style="color:var(--secondary-text);">Case: {{ $dispute->case_number ?? '—' }} • Source: {{ ucfirst(str_replace('_',' ', $dispute->source)) }}</p>
</div>
<span class="badge badge-{{ $dispute->status==='won'?'green':($dispute->status==='lost'?'red':'blue') }}">{{ ucfirst(str_replace('_',' ',$dispute->status)) }}</span>
</div>
<hr style="border:none;border-top:1px solid var(--border);margin:20px 0;">
<div class="grid grid-2">
<div><strong>Disputed Amount:</strong><br>${{ number_format($dispute->disputed_amount, 2) }}</div>
<div><strong>Reason Code:</strong><br>{{ $dispute->reason_code ?? '—' }}</div>
<div><strong>Project:</strong><br>{{ $dispute->project?->name ?? '—' }}</div>
<div><strong>Client:</strong><br>{{ $dispute->client?->name ?? '—' }}</div>
<div><strong>Respond By:</strong><br>{{ $dispute->respond_by?->format('M d, Y H:i') ?? '—' }}</div>
<div><strong>Opened:</strong><br>{{ $dispute->created_at?->format('M d, Y H:i') }}</div>
</div>
@if($dispute->reason)
<p style="margin-top:16px;"><strong>Reason:</strong><br>{{ $dispute->reason }}</p>
@endif
</div>

@if($dispute->evidence_package_hash)
<div style="background:#dcfce7;border:1px solid #86efac;border-radius:12px;padding:24px;margin-bottom:24px;">
<h3><i class="fas fa-check-circle"></i> Evidence Package Compiled</h3>
<p><strong>SHA-256 Hash:</strong></p>
<code style="word-break:break-all;font-size:0.85rem;">{{ $dispute->evidence_package_hash }}</code>
<p style="margin-top:8px;font-size:0.85rem;color:var(--secondary-text);">Compiled by {{ $dispute->compiler?->name ?? '—' }} on {{ $dispute->compiled_by ? $dispute->updated_at?->format('M d, Y H:i') : '—' }}</p>
@if($dispute->evidence_package_path)
<p style="margin-top:8px;"><a href="#" class="btn btn-sm btn-primary"><i class="fas fa-download"></i> Download Package</a></p>
@endif
</div>
@endif

@if(in_array($dispute->status, ['open','evidence_compiling','evidence_submitted']))
<div style="background:white;border-radius:16px;padding:32px;box-shadow:var(--shadow);margin-bottom:24px;">
<h3>Compile Evidence Package</h3>
<p style="color:var(--secondary-text);margin-bottom:16px;">Click below to auto-compile evidence from all related records: communications, payments, contracts, deliveries, audit logs. The compiled package is hashed for tamper-evidence.</p>
<form method="POST" action="{{ route('admin.disputes.compile', $dispute) }}">@csrf<button type="submit" class="btn btn-primary"><i class="fas fa-bolt"></i> Compile Now</button></form>
</div>
@endif

@if(in_array($dispute->status, ['open','evidence_compiling','evidence_submitted']))
<div style="background:white;border-radius:16px;padding:32px;box-shadow:var(--shadow);">
<h3>Resolve Dispute</h3>
<form method="POST" action="{{ route('admin.disputes.resolve', $dispute) }}">@csrf
<div class="form-group"><label>Resolution</label>
<select name="status" required>
<option value="won">Won</option>
<option value="lost">Lost</option>
<option value="expired">Expired</option>
</select>
</div>
<div class="form-group"><label>Resolution Notes</label><textarea name="resolution_notes" rows="3"></textarea></div>
<button type="submit" class="btn btn-primary">Resolve</button>
</form>
</div>
@endif

@if($dispute->resolved_at)
<div style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:12px;padding:24px;">
<h3>Resolution</h3>
<p><strong>Status:</strong> {{ ucfirst($dispute->status) }}</p>
<p><strong>Resolved by:</strong> {{ $dispute->resolver?->name ?? '—' }}</p>
<p><strong>Resolved at:</strong> {{ $dispute->resolved_at?->format('M d, Y H:i') }}</p>
@if($dispute->resolution_notes)
<p><strong>Notes:</strong> {{ $dispute->resolution_notes }}</p>
@endif
</div>
@endif
</div>
</section>
@endsection
