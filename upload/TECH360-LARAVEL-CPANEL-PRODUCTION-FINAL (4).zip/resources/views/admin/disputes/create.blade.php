@extends('layouts.admin')
@section('title', 'Open Dispute | TECH360 Admin')
@section('page-title', 'Open Dispute')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container" style="max-width:680px;">
<h2>Open Dispute / Chargeback</h2>
<p style="color:var(--secondary-text);margin-bottom:24px;">Use this form when Stripe, PayPal, or a bank notifies TECH360 of a chargeback or client dispute. The system will set a 7-day response window and prepare to auto-compile evidence.</p>

<div style="background:white;border-radius:16px;padding:32px;box-shadow:var(--shadow);">
<form method="POST" action="{{ route('admin.disputes.store') }}">@csrf
<div class="grid grid-2">
<div class="form-group"><label>Payment</label>
<select name="payment_id"><option value="">—</option>@foreach($payments as $p)<option value="{{ $p->id }}">#{{ $p->id }} — ${{ number_format($p->amount,2) }}</option>@endforeach</select>
</div>
<div class="form-group"><label>Source *</label>
<select name="source" required>
<option value="stripe">Stripe Chargeback</option>
<option value="paypal">PayPal Dispute</option>
<option value="bank_chargeback">Bank Chargeback</option>
<option value="client_dispute">Client Dispute</option>
</select>
</div>
</div>
<div class="grid grid-2">
<div class="form-group"><label>Project</label>
<select name="project_id"><option value="">—</option>@foreach($projects as $p)<option value="{{ $p->id }}">{{ $p->project_id }} — {{ $p->name }}</option>@endforeach</select>
</div>
<div class="form-group"><label>Client</label>
<select name="client_id"><option value="">—</option>@foreach($clients as $c)<option value="{{ $c->id }}">{{ $c->client_id }} — {{ $c->name }}</option>@endforeach</select>
</div>
</div>
<div class="grid grid-2">
<div class="form-group"><label>Case Number</label><input type="text" name="case_number"></div>
<div class="form-group"><label>Reason Code</label><input type="text" name="reason_code" placeholder="e.g., fraud, product_not_received"></div>
</div>
<div class="form-group"><label>Disputed Amount (USD) *</label><input type="number" name="disputed_amount" step="0.01" min="0" required></div>
<div class="form-group"><label>Reason / Details</label><textarea name="reason" rows="4" placeholder="What is the dispute about?"></textarea></div>
<button type="submit" class="btn btn-primary"><i class="fas fa-gavel"></i> Open Dispute</button>
<a href="{{ route('admin.disputes.index') }}" class="btn btn-outline">Cancel</a>
</form>
</div>
</div>
</section>
@endsection
