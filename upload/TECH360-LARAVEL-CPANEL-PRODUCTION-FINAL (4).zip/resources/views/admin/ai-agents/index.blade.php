@extends('layouts.admin')
@section('title', 'AI Agents | TECH360')
@section('page-title', 'AI Agents')
@section('content')
<div style="display:flex;"><div class="crm-sidebar">
<a href="{{ route('admin.dashboard') }}">Admin</a>
<a href="{{ route('admin.ai.dashboard') }}">AI Dashboard</a>
<a href="{{ route('admin.ai.agents') }}" class="active">Agents</a>
<a href="{{ route('admin.ai.approvals') }}">Approvals</a>
<a href="{{ route('admin.ai.knowledge') }}">Knowledge</a>
<a href="{{ route('admin.ai.workflows') }}">Workflows</a>
<a href="{{ route('admin.ai.logs') }}">Logs</a>
<a href="{{ route('crm.dashboard') }}">CRM</a>
</div>
<div class="crm-main">
<h2>AI Agents <span style="color:var(--secondary-text);font-size:1rem;">({{ $agents->total() }} total)</span></h2>

<div style="margin:16px 0;">
<button class="btn btn-primary btn-sm" onclick="document.getElementById('newAgentModal').style.display='block'"><i class="fas fa-plus"></i> Create Agent</button>
</div>

<table class="table">
<thead><tr><th>Agent ID</th><th>Name</th><th>Provider</th><th>Mode</th><th>Status</th><th>Executions</th><th>Actions</th></tr></thead>
<tbody>
@if($agents->count())
@foreach($agents as $agent)
<tr>
<td style="font-size:0.8rem;">{{ $agent->agent_id }}</td>
<td><a href="{{ route('admin.ai.agents.show', $agent) }}" style="font-weight:600;">{{ $agent->name }}</a><br><small style="color:var(--secondary-text);">{{ $agent->description }}</small></td>
<td>{{ $agent->provider }}</td>
<td><span class="badge badge-blue">{{ $agent->mode }}</span></td>
<td><span class="badge {{ $agent->status=='active'?'badge-green':'badge-red' }}">{{ $agent->status }}</span></td>
<td>{{ $agent->executions_count ?? 0 }}</td>
<td>
<form method="POST" action="{{ route('admin.ai.agents.toggle', $agent) }}" style="display:inline;">@csrf<button type="submit" class="btn btn-sm btn-outline">{{ $agent->status=='active'?'Disable':'Enable' }}</button></form>
<a href="{{ route('admin.ai.agents.show', $agent) }}" class="btn btn-sm btn-outline">View</a>
</td>
</tr>
@endforeach
@else
<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--secondary-text);">No agents. Run <code>php artisan db:seed --class=AiAgentSeeder</code> to seed.</td></tr>
@endif
</tbody>
</table>
{{ $agents->links() }}

<div id="newAgentModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:2000;align-items:center;justify-content:center;" onclick="if(event.target===this)this.style.display='none'">
<div style="background:white;border-radius:16px;padding:32px;max-width:560px;width:90%;max-height:90vh;overflow-y:auto;">
<h3 style="margin-bottom:16px;">Create AI Agent</h3>
<form method="POST" action="{{ route('admin.ai.agents.store') }}">
@csrf
<div class="form-group"><label>Name *</label><input type="text" name="name" required></div>
<div class="form-group"><label>Description</label><textarea name="description" rows="2"></textarea></div>
<div class="form-group"><label>Instructions (System Prompt)</label><textarea name="instructions" rows="4" placeholder="You are..."></textarea></div>
<div class="grid grid-2">
<div class="form-group"><label>Provider</label>
<select name="provider"><option value="openai">OpenAI</option><option value="ollama">Ollama</option><option value="custom">Custom</option></select>
</div>
<div class="form-group"><label>Model</label><input type="text" name="model" value="gpt-4o-mini"></div>
</div>
<div class="form-group"><label>Mode</label>
<select name="mode"><option value="manual">Manual</option><option value="approval" selected>Approval (recommended)</option><option value="autonomous">Autonomous</option></select>
</div>
<button type="submit" class="btn btn-primary">Create</button>
<button type="button" onclick="document.getElementById('newAgentModal').style.display='none'" class="btn btn-outline">Cancel</button>
</form>
</div>
</div>
</div></div>
@endsection
