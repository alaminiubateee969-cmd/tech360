@extends('layouts.admin')
@section('title', $aiAgent->name . ' | AI Agent')
@section('content')
<div style="display:flex;"><div class="crm-sidebar">
<a href="{{ route('admin.dashboard') }}">Admin</a>
<a href="{{ route('admin.ai.dashboard') }}">AI Dashboard</a>
<a href="{{ route('admin.ai.agents') }}" class="active">Agents</a>
<a href="{{ route('admin.ai.approvals') }}">Approvals</a>
<a href="{{ route('admin.ai.knowledge') }}">Knowledge</a>
<a href="{{ route('admin.ai.workflows') }}">Workflows</a>
<a href="{{ route('admin.ai.logs') }}">Logs</a>
<a href="{{ route('crm.dashboard') }}">CRM</a>
</div>
<div class="crm-main">
<a href="{{ route('admin.ai.agents') }}" class="btn btn-outline btn-sm" style="margin-bottom:16px;"><i class="fas fa-arrow-left"></i> Back</a>

<div style="background:white;border-radius:16px;padding:32px;box-shadow:var(--shadow);margin-bottom:24px;">
<div style="display:flex;justify-content:space-between;align-items:start;">
<div>
<h2>{{ $aiAgent->name }}</h2>
<p style="color:var(--secondary-text);">{{ $aiAgent->agent_id }} • <span class="badge {{ $aiAgent->status=='active'?'badge-green':'badge-red' }}">{{ $aiAgent->status }}</span> • <span class="badge badge-blue">{{ $aiAgent->mode }}</span></p>
</div>
<form method="POST" action="{{ route('admin.ai.agents.toggle', $aiAgent) }}">@csrf<button type="submit" class="btn btn-sm {{ $aiAgent->status=='active'?'btn-danger':'btn-success' }}">{{ $aiAgent->status=='active'?'Disable':'Enable' }}</button></form>
</div>
<hr style="border:none;border-top:1px solid var(--border);margin:20px 0;">
<div class="grid grid-2">
<div><strong>Provider:</strong> {{ $aiAgent->provider }}</div>
<div><strong>Model:</strong> {{ $aiAgent->model }}</div>
<div><strong>Created:</strong> {{ $aiAgent->created_at ? $aiAgent->created_at->format('M d, Y') : '—' }}</div>
<div><strong>Slug:</strong> {{ $aiAgent->slug }}</div>
</div>
@if($aiAgent->description)
<p style="margin-top:16px;"><strong>Description:</strong><br>{{ $aiAgent->description }}</p>
@endif
@if($aiAgent->instructions)
<div style="margin-top:16px;padding:16px;background:#f8fafc;border-left:4px solid var(--blue);border-radius:6px;">
<strong>Instructions (System Prompt):</strong>
<pre style="white-space:pre-wrap;font-family:inherit;margin:8px 0 0;color:var(--primary-text);">{{ $aiAgent->instructions }}</pre>
</div>
@endif
</div>

<div class="grid grid-2" style="gap:24px;">
<div style="background:white;border-radius:16px;padding:32px;box-shadow:var(--shadow);">
<h3>Execute Test Task</h3>
<form method="POST" action="{{ route('admin.ai.agents.execute', $aiAgent) }}">@csrf
<div class="form-group"><label>Input prompt</label><textarea name="input" rows="4" placeholder="Type a test prompt for this agent..." required></textarea></div>
<button type="submit" class="btn btn-primary"><i class="fas fa-play"></i> Execute</button>
<p style="margin-top:8px;font-size:0.85rem;color:var(--secondary-text);">Mode is <strong>{{ $aiAgent->mode }}</strong> — @if($aiAgent->mode=='approval')will create an approval request first.@elseif($aiAgent->mode=='manual')requires admin approval before execution.@else will execute autonomously (low-risk only).@endif</p>
</form>
</div>
<div style="background:white;border-radius:16px;padding:32px;box-shadow:var(--shadow);">
<h3>Memory</h3>
@if($aiAgent->memories->count())
@foreach($aiAgent->memories as $mem)
<div style="padding:8px 0;border-bottom:1px solid var(--border);">
<strong style="color:var(--blue);">{{ ucfirst($mem->type) }}</strong> — <small>{{ $mem->created_at ? $mem->created_at->diffForHumans() : '' }}</small>
<div>{{ \Illuminate\Support\Str::limit($mem->value, 200) }}</div>
</div>
@endforeach
@else
<p style="color:var(--secondary-text);">No memory entries.</p>
@endif
</div>
</div>

<div style="background:white;border-radius:16px;padding:32px;box-shadow:var(--shadow);margin-top:24px;">
<h3>Recent Executions ({{ $aiAgent->executions->count() }})</h3>
@if($aiAgent->executions->count())
<table class="table">
<thead><tr><th>Execution ID</th><th>Status</th><th>Input</th><th>Output</th><th>When</th></tr></thead>
<tbody>
@foreach($aiAgent->executions->take(10) as $exec)
<tr>
<td style="font-size:0.8rem;">{{ $exec->execution_id }}</td>
<td><span class="badge {{ $exec->status=='completed'?'badge-green':($exec->status=='failed'?'badge-red':'badge-blue') }}">{{ $exec->status }}</span></td>
<td>{{ \Illuminate\Support\Str::limit($exec->input, 50) }}</td>
<td>{{ \Illuminate\Support\Str::limit($exec->output, 50) }}</td>
<td>{{ $exec->created_at ? $exec->created_at->diffForHumans() : '—' }}</td>
</tr>
@endforeach
</tbody>
</table>
@else
<p style="color:var(--secondary-text);">No executions yet.</p>
@endif
</div>
</div></div>
@endsection
