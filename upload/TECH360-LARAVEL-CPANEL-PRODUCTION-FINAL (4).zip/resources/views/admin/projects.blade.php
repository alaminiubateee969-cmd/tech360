@extends('layouts.admin')
@section('title', 'Admin: Projects | TECH360 LLC')
@section('page-title', 'Projects')
@section('content')

<h2>Projects <span style="color:var(--secondary-text);font-size:1rem;">({{ $projects->total() }} total)</span></h2>
<a href="{{ route('admin.dashboard') }}" class="btn btn-outline btn-sm" style="margin:16px 0;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>

<div style="background:white;border-radius:12px;box-shadow:var(--shadow);overflow:hidden;">
<table class="table">
<thead><tr><th>Project ID</th><th>Name</th><th>Client</th><th>State</th><th>Budget</th><th>Created</th><th>Actions</th></tr></thead>
<tbody>
@if($projects->count())
@foreach($projects as $project)
<tr>
<td><code>{{ $project->project_id }}</code></td>
<td><strong>{{ $project->name }}</strong></td>
<td>{{ $project->client?->name ?? '—' }}</td>
<td><span class="badge badge-{{ str_starts_with($project->commercial_state, 'PAYMENT_PAID')?'green':($project->commercial_state==='SCOPE_APPROVED'?'blue':'navy') }}">{{ str_replace('_', ' ', $project->commercial_state) }}</span></td>
<td>${{ number_format((float)($project->budget ?? 0), 2) }}</td>
<td>{{ $project->created_at ? $project->created_at->format('M d, Y') : '—' }}</td>
<td>
@if($project->commercial_state === 'PAYMENT_PAID')
<form method="POST" action="{{ route('admin.handover.release', $project->id) }}" style="display:inline;">@csrf<button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Release handover for this project?')"><i class="fas fa-key"></i> Release Handover</button></form>
@else
<span style="color:var(--secondary-text);font-size:0.85rem;">—</span>
@endif
</td>
</tr>
@endforeach
@else
<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--secondary-text);">No projects yet.</td></tr>
@endif
</tbody>
</table>
</div>
{{ $projects->links() }}
@endsection
