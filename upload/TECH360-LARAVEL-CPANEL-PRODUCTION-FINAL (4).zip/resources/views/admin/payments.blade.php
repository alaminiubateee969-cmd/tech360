@extends('layouts.admin')
@section('title', 'Admin: Payments | TECH360 LLC')
@section('page-title', 'Payments')
@section('content')

<h2>Payments <span style="color:var(--secondary-text);font-size:1rem;">({{ $payments->total() }} total)</span></h2>
<a href="{{ route('admin.dashboard') }}" class="btn btn-outline btn-sm" style="margin:16px 0;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>

<div style="background:white;border-radius:12px;box-shadow:var(--shadow);overflow:hidden;">
<table class="table">
<thead><tr><th>Payment ID</th><th>Project</th><th>Client</th><th>Amount</th><th>Method</th><th>Status</th><th>Verified</th><th>Actions</th></tr></thead>
<tbody>
@if($payments->count())
@foreach($payments as $payment)
<tr>
<td><code>#{{ $payment->id }}</code></td>
<td>{{ $payment->project?->name ?? '—' }}</td>
<td>{{ $payment->client?->name ?? '—' }}</td>
<td><strong>${{ number_format((float)($payment->amount ?? 0), 2) }}</strong> {{ $payment->currency ?? 'USD' }}</td>
<td>{{ ucfirst($payment->provider ?? 'stripe') }}</td>
<td><span class="badge badge-{{ $payment->status==='paid'?'green':($payment->status==='pending'?'blue':'red') }}">{{ ucfirst($payment->status) }}</span></td>
<td>{{ $payment->verified_at ? $payment->verified_at->format('M d, Y H:i') : '—' }}</td>
<td>
@if($payment->status === 'pending')
<form method="POST" action="{{ route('admin.payment.verify', $payment->id) }}" style="display:inline;">@csrf<button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Verify this payment? This cannot be undone.')"><i class="fas fa-check"></i> Verify</button></form>
@else
<span style="color:var(--secondary-text);font-size:0.85rem;">—</span>
@endif
</td>
</tr>
@endforeach
@else
<tr><td colspan="8" style="text-align:center;padding:32px;color:var(--secondary-text);">No payments yet. Payments appear after clients initiate them.</td></tr>
@endif
</tbody>
</table>
</div>
{{ $payments->links() }}
@endsection
