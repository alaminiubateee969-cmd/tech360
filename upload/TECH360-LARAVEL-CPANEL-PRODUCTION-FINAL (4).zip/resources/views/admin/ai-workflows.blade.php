@extends('layouts.admin')
@section('title', 'AI Workflows | TECH360')
@section('page-title', 'AI Workflows')
@section('content')

<h2>AI Workflows</h2>
<button class="btn btn-primary btn-sm" style="margin:16px 0;" onclick="document.getElementById('newWfModal').style.display='block'"><i class="fas fa-plus"></i> Create Workflow</button>

<table class="table">
<thead><tr><th>Workflow ID</th><th>Name</th><th>Trigger</th><th>Schedule</th><th>Status</th></tr></thead>
<tbody>
@if($workflows->count())
@foreach($workflows as $wf)
<tr>
<td style="font-size:0.8rem;">{{ $wf->workflow_id }}</td>
<td><strong>{{ $wf->name }}</strong><br><small style="color:var(--secondary-text);">{{ $wf->description }}</small></td>
<td>{{ $wf->trigger_type ?? 'manual' }}</td>
<td>{{ $wf->schedule ?? '—' }}</td>
<td><span class="badge {{ $wf->status=='active'?'badge-green':'badge-blue' }}">{{ $wf->status }}</span></td>
</tr>
@endforeach
@else
<tr><td colspan="5" style="text-align:center;padding:32px;color:var(--secondary-text);">No workflows created yet.</td></tr>
@endif
</tbody>
</table>
{{ $workflows->links() }}

<div id="newWfModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:2000;align-items:center;justify-content:center;" onclick="if(event.target===this)this.style.display='none'">
<div style="background:white;border-radius:16px;padding:32px;max-width:600px;width:90%;max-height:90vh;overflow-y:auto;">
<h3 style="margin-bottom:16px;">Create Workflow</h3>
<form method="POST" action="{{ route('admin.ai.workflows.store') }}">@csrf
<div class="form-group"><label>Name *</label><input type="text" name="name" required></div>
<div class="form-group"><label>Description</label><textarea name="description" rows="2"></textarea></div>
<div class="grid grid-2">
<div class="form-group"><label>Trigger Type</label>
<select name="trigger_type">
<option value="manual">Manual</option>
<option value="schedule">Schedule</option>
<option value="event">Event</option>
<option value="webhook">Webhook</option>
</select>
</div>
<div class="form-group"><label>Schedule (cron)</label><input type="text" name="schedule" placeholder="0 9 * * *" pattern="[\d\*\/\,\- ]+"></div>
</div>
<div class="form-group"><label>Steps (JSON array)</label><textarea name="steps" rows="5" placeholder='[{"agent":"lead-management-agent","action":"classify"},{"agent":"crm-agent","action":"create_activity"}]'></textarea></div>
<button type="submit" class="btn btn-primary">Create Workflow</button>
<button type="button" onclick="document.getElementById('newWfModal').style.display='none'" class="btn btn-outline">Cancel</button>
</form>
</div>
</div>
@endsection
