@extends('layouts.admin')
@section('title', 'AI Execution Logs | TECH360')
@section('page-title', 'AI Execution Logs')
@section('content')

<h2>AI Execution Logs</h2>
<p style="color:var(--secondary-text);margin-bottom:24px;">Every execution records: agent, user, project, task, provider, model, start/end, duration, status, tool calls, error, result metadata. Secrets are never stored in logs.</p>

<table class="table">
<thead><tr><th>Time</th><th>Agent</th><th>Level</th><th>Action</th><th>Message</th></tr></thead>
<tbody>
@if($logs->count())
@foreach($logs as $log)
<tr>
<td style="font-size:0.8rem;">{{ $log->created_at ? $log->created_at->format('M d, Y H:i:s') : '—' }}</td>
<td>{{ $log->agent?->name ?? '—' }}</td>
<td><span class="badge {{ $log->level=='error'?'badge-red':($log->level=='warning'?'badge-blue':'badge-green') }}">{{ $log->level }}</span></td>
<td><strong>{{ $log->action }}</strong></td>
<td>{{ \Illuminate\Support\Str::limit($log->message, 100) }}</td>
</tr>
@endforeach
@else
<tr><td colspan="5" style="text-align:center;padding:32px;color:var(--secondary-text);">No logs yet.</td></tr>
@endif
</tbody>
</table>
{{ $logs->links() }}
@endsection
