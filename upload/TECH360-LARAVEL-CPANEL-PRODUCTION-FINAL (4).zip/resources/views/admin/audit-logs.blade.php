@extends('layouts.admin')
@section('title', 'Admin: Audit Logs | TECH360 LLC')
@section('page-title', 'Audit Logs')
@section('content')

<h2>Audit Logs <span style="color:var(--secondary-text);font-size:1rem;">({{ $logs->total() }} entries)</span></h2>
<a href="{{ route('admin.dashboard') }}" class="btn btn-outline btn-sm" style="margin:16px 0;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>

<p style="color:var(--secondary-text);margin-bottom:24px;">Every sensitive action is logged permanently: login, logout, payment, verification, refund, project status, source release, handover, AI execution, approval, CMS changes, settings.</p>

<div style="background:white;border-radius:12px;box-shadow:var(--shadow);overflow:hidden;">
<table class="table">
<thead><tr><th>Timestamp</th><th>Action</th><th>Actor</th><th>Client</th><th>Project</th><th>IP</th></tr></thead>
<tbody>
@if($logs->count())
@foreach($logs as $log)
<tr>
<td style="font-size:0.8rem;">{{ $log->timestamp ?? ($log->created_at ? $log->created_at->format('M d, Y H:i:s') : '—') }}</td>
<td><strong>{{ $log->action }}</strong><br><small style="color:var(--secondary-text);">{{ \Illuminate\Support\Str::limit($log->details ?? '', 60) }}</small></td>
<td><span class="badge badge-navy">{{ ucfirst($log->actor_type ?? 'system') }}</span> {{ $log->actor_id ?? '—' }}</td>
<td>{{ $log->client_id ?? '—' }}</td>
<td>{{ $log->project_id ?? '—' }}</td>
<td><code>{{ $log->ip_address ?? '—' }}</code></td>
</tr>
@endforeach
@else
<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--secondary-text);">No audit logs yet.</td></tr>
@endif
</tbody>
</table>
</div>
{{ $logs->links() }}
@endsection
