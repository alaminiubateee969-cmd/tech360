@extends('layouts.admin')
@section('title', 'AI Knowledge Base | TECH360')
@section('page-title', 'AI Knowledge Base')
@section('content')

<h2>AI Knowledge Base</h2>
<button class="btn btn-primary btn-sm" style="margin:16px 0;" onclick="document.getElementById('newDocModal').style.display='block'"><i class="fas fa-plus"></i> Add Document</button>

<table class="table">
<thead><tr><th>Title</th><th>Category</th><th>Active</th><th>Created</th></tr></thead>
<tbody>
@if($docs->count())
@foreach($docs as $doc)
<tr>
<td style="max-width:400px;"><strong>{{ $doc->title }}</strong><br><small style="color:var(--secondary-text);">{{ \Illuminate\Support\Str::limit($doc->content, 120) }}</small></td>
<td><span class="badge badge-blue">{{ ucfirst($doc->category) }}</span></td>
<td><span class="badge {{ $doc->is_active?'badge-green':'badge-red' }}">{{ $doc->is_active?'Active':'Inactive' }}</span></td>
<td>{{ $doc->created_at ? $doc->created_at->format('M d, Y') : '—' }}</td>
</tr>
@endforeach
@else
<tr><td colspan="4" style="text-align:center;padding:32px;color:var(--secondary-text);">No knowledge documents.</td></tr>
@endif
</tbody>
</table>
{{ $docs->links() }}

<div id="newDocModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:2000;align-items:center;justify-content:center;" onclick="if(event.target===this)this.style.display='none'">
<div style="background:white;border-radius:16px;padding:32px;max-width:560px;width:90%;max-height:90vh;overflow-y:auto;">
<h3 style="margin-bottom:16px;">Add Knowledge Document</h3>
<form method="POST" action="{{ route('admin.ai.knowledge.store') }}">@csrf
<div class="form-group"><label>Title *</label><input type="text" name="title" required></div>
<div class="form-group"><label>Category *</label>
<select name="category">
<option value="company">Company</option>
<option value="pricing">Pricing</option>
<option value="policy">Policy</option>
<option value="support">Support</option>
<option value="services">Services</option>
<option value="technical">Technical</option>
<option value="general">General</option>
</select>
</div>
<div class="form-group"><label>Content *</label><textarea name="content" rows="6" required></textarea></div>
<button type="submit" class="btn btn-primary">Save Document</button>
<button type="button" onclick="document.getElementById('newDocModal').style.display='none'" class="btn btn-outline">Cancel</button>
</form>
</div>
</div>
@endsection
