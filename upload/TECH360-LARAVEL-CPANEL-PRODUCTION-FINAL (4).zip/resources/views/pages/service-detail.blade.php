@extends('layouts.app')
@section('title', $service->title . ' | TECH360')
@section('content')
<section class="section"><div class="container">
<h1>{{ $service->title }}</h1>
<p style="font-size:1.2rem;color:var(--secondary-text);margin:16px 0 32px;">{{ $service->short_description }}</p>
@if($service->description)<div style="max-width:800px;">{!! nl2br(e($service->description)) !!}</div>@endif
@if($service->features)<h3 style="margin-top:32px;">Features</h3><ul style="margin:16px 0;padding-left:24px;">@foreach($service->features as $f)<li style="margin-bottom:8px;color:var(--secondary-text);">{{ $f }}</li>@endforeach</ul>@endif
<a href="{{ route('contact') }}" class="btn btn-primary" style="margin-top:32px;">Get Started</a>
</div></section>
@endsection
