@extends('layouts.app')
@section('title', 'Case Studies | TECH360')
@section('content')
<section class="section"><div class="container">
<div class="section-header"><h2>Case <span class="text-gradient">Studies</span></h2><p>Real solutions, real results</p></div>
<p style="text-align:center;color:var(--secondary-text);">Case studies coming soon. <a href="{{ route('contact') }}">Contact us</a> to discuss your project.</p>
</div></section>
@endsection
