@extends('layouts.app')
@section('title', 'About TECH360 LLC — Connect • Innovate • Grow')
@section('description', 'TECH360 LLC is an enterprise technology company based in Harrisonville, MO delivering web, cloud, CRM, automation, and software development with a strict scope-to-delivery workflow.')
@section('content')
<section class="hero" style="padding:60px 0;">
<div class="container">
<div class="hero-grid">
<div>
<h1>About <span class="text-gradient">TECH360</span></h1>
<p style="font-size:1.15rem;color:var(--secondary-text);">Smart Technology Solutions for a Digital Tomorrow. TECH360 LLC is a US-based enterprise technology company delivering web, cloud, software, CRM, automation, and data systems — with a strict scope-to-delivery workflow that protects both your budget and your timeline.</p>
<div style="margin-top:24px;display:flex;gap:24px;flex-wrap:wrap;">
<div><div style="font-size:2rem;font-weight:800;color:var(--navy);">2024</div><div style="font-size:0.85rem;color:var(--secondary-text);">Founded</div></div>
<div><div style="font-size:2rem;font-weight:800;color:var(--blue);">100+</div><div style="font-size:0.85rem;color:var(--secondary-text);">Projects Delivered</div></div>
<div><div style="font-size:2rem;font-weight:800;color:var(--green);">11</div><div style="font-size:0.85rem;color:var(--secondary-text);">AI Agents</div></div>
</div>
</div>
<div class="hero-visual"><img src="{{ asset('images/admin-dashboard.png') }}" alt="TECH360 Platform Dashboard" style="max-width:100%;border-radius:16px;box-shadow:0 12px 40px rgba(6,59,143,0.12);"></div>
</div>
</div>
</section>

<section class="section">
<div class="container">
<div class="grid grid-2">
<div class="card">
<div class="card-icon blue"><i class="fas fa-bullseye"></i></div>
<h2>Our Mission</h2>
<p style="font-size:1.05rem;color:var(--secondary-text);">To empower businesses with smart technology solutions that connect innovation, automation, and growth. We build production-grade systems — not prototypeware — that help organizations scale efficiently in the digital age. Every project we deliver runs the same controlled workflow: documented scope, client approval, verified payment, quality assurance, and gated source-code release. This isn't just process for the sake of process; it's how we ensure the dollar you invest today produces measurable value tomorrow.</p>
</div>
<div class="card">
<div class="card-icon navy"><i class="fas fa-eye"></i></div>
<h2>Our Vision</h2>
<p style="font-size:1.05rem;color:var(--secondary-text);">To be the trusted technology partner for businesses worldwide, delivering Web, Cloud, Data, and Software solutions that transform operations and drive measurable growth. We believe trust is built on transparency — which is why every payment, scope change, refund decision, source-code release, and audit action is logged permanently. Clients don't have to take our word; they can verify every step in their portal and audit trail.</p>
</div>
</div>
</div>
</section>

<section class="section section-light">
<div class="container">
<div class="section-header"><h2>Our <span class="text-gradient">Values</span></h2><p>The principles that govern every project, every payment, and every handover.</p></div>
<div class="grid grid-4">
<div class="card"><div class="card-icon blue"><i class="fas fa-handshake"></i></div><h3>Trust</h3><p>Transparent processes, clear scope, honest delivery. Every action is auditable, every payment is traceable, every promise is documented.</p></div>
<div class="card"><div class="card-icon navy"><i class="fas fa-lightbulb"></i></div><h3>Innovation</h3><p>Cutting-edge technology and creative solutions. We use Laravel 11, PHP 8.2+, MySQL 8, and modern AI agents — but we deploy on standard cPanel, no Docker required.</p></div>
<div class="card"><div class="card-icon cyan"><i class="fas fa-shield-alt"></i></div><h3>Quality</h3><p>Production-grade systems, tested and reliable. Source code is gated until QA passes. Refunds are reviewed, not auto-approved. No fake dashboards.</p></div>
<div class="card"><div class="card-icon green"><i class="fas fa-chart-line"></i></div><h3>Growth</h3><p>Solutions designed to scale. From a Starter website at $750 to a multi-server enterprise automation platform, the same workflow applies.</p></div>
</div>
</div>
</section>

<section class="section">
<div class="container">
<div class="section-header"><h2>What Makes Us <span class="text-gradient">Different</span></h2><p>Three things set TECH360 apart from typical agencies.</p></div>
<div class="grid grid-3">
<div class="card">
<div class="card-icon blue"><i class="fas fa-file-signature"></i></div>
<h3>Scope-First Workflow</h3>
<p>We refuse to start work without an approved Scope of Work. This protects your budget (no scope creep), protects our team (no endless revisions), and protects the relationship (no surprises). The scope document becomes the binding reference for what is delivered — and what is a separate change request.</p>
</div>
<div class="card">
<div class="card-icon navy"><i class="fas fa-lock"></i></div>
<h3>Source-Code Protection</h3>
<p>Source code is never exposed before payment is verified, QA passes, admin approves, and credentials are rotated. This isn't distrust — it's standard commercial practice. You receive the full source package at handover, with documentation and deployment guide. Until then, the work stays in TECH360-controlled storage.</p>
</div>
<div class="card">
<div class="card-icon cyan"><i class="fas fa-robot"></i></div>
<h3>Built-In AI Agents</h3>
<p>11 named AI agents operate inside the platform — Lead Management, CRM, Sales, Customer Communication, Support, Marketing, Reporting, Security Monitoring, and more. Every agent has a defined mode (manual / approval / autonomous), tools it can call, and an audit log of every execution. AI never bypasses approval rules.</p>
</div>
</div>
</div>
</section>

<section class="section section-light">
<div class="container">
<div class="section-header"><h2>Company <span class="text-gradient">Information</span></h2><p>TECH360 LLC — registered US business.</p></div>
<div class="grid grid-2">
<div class="card">
<h3>Business Details</h3>
<p style="margin-top:12px;"><strong>Legal Name:</strong> TECH360 LLC</p>
<p><strong>Headquarters:</strong> 117 S Lexington St, Ste 100, Harrisonville, MO 64701</p>
<p><strong>Email:</strong> <a href="mailto:support@tech360.io">support@tech360.io</a></p>
<p><strong>Phone:</strong> <a href="tel:+18003600199">+1 (800) 360-0199</a></p>
<p><strong>Slogan:</strong> Connect • Innovate • Grow</p>
</div>
<div class="card">
<h3>Legal & Policies</h3>
<p style="margin-top:12px;">We operate under a strict legal framework to protect both parties:</p>
<ul style="list-style:none;padding:0;margin:12px 0;">
<li style="padding:8px 0;"><a href="{{ route('terms') }}"><i class="fas fa-file-contract"></i> Terms & Conditions</a></li>
<li style="padding:8px 0;"><a href="{{ route('refund-policy') }}"><i class="fas fa-undo-alt"></i> Refund Policy</a></li>
<li style="padding:8px 0;"><a href="{{ route('privacy-policy') }}"><i class="fas fa-user-shield"></i> Privacy Policy</a></li>
<li style="padding:8px 0;"><a href="{{ route('cookie-policy') }}"><i class="fas fa-cookie-bite"></i> Cookie Policy</a></li>
</ul>
</div>
</div>
</div>
</section>

<section class="section">
<div class="container" style="text-align:center;">
<h2>Your Vision. Our Technology. <span class="text-gradient">Limitless Possibilities.</span></h2>
<p style="color:var(--secondary-text);max-width:600px;margin:16px auto 32px;">Let's build something that lasts. Submit your project inquiry today and receive a structured Scope of Work within 24 business hours.</p>
<a href="{{ route('contact') }}" class="btn btn-gradient" style="font-size:1.1rem;padding:16px 32px;"><i class="fas fa-rocket"></i> Get Started Today</a>
</div>
</section>
@endsection
