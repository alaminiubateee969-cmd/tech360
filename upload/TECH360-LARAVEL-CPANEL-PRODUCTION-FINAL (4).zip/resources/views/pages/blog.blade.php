@extends('layouts.app')
@section('title', 'Blog | TECH360')
@section('content')
<section class="section"><div class="container">
<div class="section-header"><h2>TECH360 <span class="text-gradient">Blog</span></h2><p>Insights on technology, innovation, and growth</p></div>
@if($posts->isEmpty())
<p style="text-align:center;color:var(--secondary-text);">Articles coming soon.</p>
@else
<div class="grid grid-3">
@foreach($posts as $post)
<div class="card">
@if($post->featured_image)<img src="{{ $post->featured_image }}" alt="{{ $post->title }}" class="card-img">@endif
<span class="badge badge-blue">{{ $post->category ?? 'Technology' }}</span>
<h3 style="margin-top:12px;">{{ $post->title }}</h3>
<p>{{ $post->excerpt ?? mb_substr($post->content, 0, 150) }}...</p>
<a href="{{ route('blog.post', $post->slug) }}" class="btn btn-sm btn-outline" style="margin-top:12px;">Read More</a>
</div>
@endforeach
</div>
{{ $posts->links() }}
@endif
</div></section>
@endsection
