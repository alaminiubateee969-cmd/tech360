@extends('layouts.app')
@section('title', 'Portfolio | TECH360')
@section('content')
<section class="section"><div class="container">
<div class="section-header"><h2>Our <span class="text-gradient">Portfolio</span></h2><p>Technology solutions we've built</p></div>
@if($items->isEmpty())
<p style="text-align:center;color:var(--secondary-text);">Portfolio items will be displayed here. <a href="{{ route('contact') }}">Start your project</a> to be featured.</p>
@else
<div class="grid grid-3">
@foreach($items as $item)
<div class="card">
@if($item->image)<img src="{{ $item->image }}" alt="{{ $item->title }}" class="card-img">@endif
<h3>{{ $item->title }}</h3>
<p>{{ $item->industry ?? 'Technology' }}</p>
<a href="{{ route('portfolio.detail', $item->slug) }}" class="btn btn-sm btn-outline" style="margin-top:12px;">View Details</a>
</div>
@endforeach
</div>
@endif
</div></section>
@endsection
