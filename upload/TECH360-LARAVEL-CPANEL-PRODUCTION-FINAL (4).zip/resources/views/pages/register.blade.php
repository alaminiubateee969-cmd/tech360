@extends('layouts.app')
@section('title', 'Register | TECH360 LLC')
@section('content')
<section class="section"><div class="container" style="max-width:400px;">
<h2>Create Account</h2>
<form method="POST" action="{{ route('register.post') }}">@csrf
<div class="form-group"><label>Name</label><input type="text" name="name" required></div>
<div class="form-group"><label>Email</label><input type="email" name="email" required></div>
<div class="form-group"><label>Password (min 6 chars)</label><input type="password" name="password" required></div>
<div class="form-group"><label>Confirm Password</label><input type="password" name="password_confirmation" required></div>
<button type="submit" class="btn btn-primary">Register</button>
</form>
</div></section>
@endsection
