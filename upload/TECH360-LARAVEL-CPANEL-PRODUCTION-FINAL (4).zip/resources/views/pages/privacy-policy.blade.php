@extends('layouts.app')
@section('title', 'Privacy Policy | TECH360 LLC')
@section('content')
<div class="legal-content">
<h1>Privacy Policy</h1>
<p><strong>Effective Date: May 19, 2026</strong></p>
<h2>Information We Collect</h2>
<p>We collect account information (name, email), contact information (phone, company), project information, payment information (invoice records, payment status), and technical information (IP address, browser type, usage logs).</p>
<h2>Data Security</h2>
<p>We implement password hashing (bcrypt), HTTPS encryption, role-based access control, protected API endpoints, environment-based secret management, and audit logging. We do not claim "bank-level security" or "100% secure" systems.</p>
<h2>Data Retention</h2>
<p>Personal data is retained for the duration of the business relationship and for 7 years thereafter for legal compliance, unless you request earlier deletion.</p>
<h2>Your Rights</h2>
<p>You have the right to access, correct, delete, object to processing, and request data portability. Contact info@bdtech360.com to exercise these rights.</p>
<h2>Contact</h2>
<p>TECH360 LLC<br>117 S Lexington St, Ste 100<br>Harrisonville, MO 64701<br>United States<br>Email: info@bdtech360.com<br>WhatsApp: +880 1327-100-297</p>
</div>
@endsection
