@extends('layouts.app')
@section('title', 'Login | TECH360 LLC')
@section('content')
<section class="section"><div class="container" style="max-width:400px;">
<h2>Sign In</h2>
<form method="POST" action="{{ route('login.post') }}">@csrf
<div class="form-group"><label>Email</label><input type="email" name="email" required></div>
<div class="form-group"><label>Password</label><input type="password" name="password" required></div>
<div class="form-group"><label><input type="checkbox" name="remember"> Remember me</label></div>
<button type="submit" class="btn btn-primary">Sign In</button>
</form>
<p style="margin-top:16px;">Don't have an account? <a href="{{ route('register') }}">Register</a></p>
</div></section>
@endsection
