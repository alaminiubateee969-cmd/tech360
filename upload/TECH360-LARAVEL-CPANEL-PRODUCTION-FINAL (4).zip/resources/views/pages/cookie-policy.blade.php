@extends('layouts.app')
@section('title', 'Cookie Policy | TECH360 LLC')
@section('content')
<div class="legal-content">
<h1>Cookie Policy</h1>
<p><strong>Effective Date: May 19, 2026</strong></p>
<h2>Cookies Used by bdtech360.com</h2>
<h3>Essential Cookies</h3>
<p>Authentication session (required for login) and CSRF token (protects against cross-site request forgery).</p>
<h3>Preference Cookies</h3>
<p>Theme preference (remembers your light/dark mode choice).</p>
<h3>Analytics Cookies</h3>
<p>We do not currently use third-party analytics cookies.</p>
<h2>Managing Cookies</h2>
<p>You can manage cookies through your browser settings. Disabling essential cookies will prevent login and authenticated functionality.</p>
</div>
@endsection
