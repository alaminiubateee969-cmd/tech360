@extends('layouts.app')
@section('title', 'Pricing | TECH360 LLC — Transparent Project Pricing')
@section('description', 'TECH360 LLC pricing tiers: Starter, Professional, Business Systems, Custom Software, Enterprise. Transparent scope-based pricing with no surprises.')
@section('content')
<section class="hero" style="padding:60px 0;">
<div class="container" style="text-align:center;">
<h1>Transparent <span class="text-gradient">Project Pricing</span></h1>
<p style="font-size:1.1rem;color:var(--secondary-text);max-width:720px;margin:24px auto 0;">Final pricing is based on the approved Scope of Work — estimated engineering hours, integrations, infrastructure, and delivery timeline. No hidden fees, no surprise invoices, no work begins before scope approval.</p>
</div>
</section>

<section class="section">
<div class="container">
<div class="grid grid-3" style="gap:24px;">

<div class="card" style="display:flex;flex-direction:column;">
<div class="card-icon blue"><i class="fas fa-rocket"></i></div>
<h3>Starter</h3>
<p style="font-size:2rem;color:var(--blue);font-weight:800;margin:12px 0;">From $750</p>
<p style="color:var(--secondary-text);">Business websites and landing pages.</p>
<ul style="list-style:none;padding:0;margin:16px 0;">
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> Up to 5 pages</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> Mobile responsive</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> Contact form + CRM lead capture</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> SEO basics + sitemap</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> 2 rounds of revisions</li>
<li style="padding:6px 0;"><i class="fas fa-check" style="color:var(--green);"></i> 30-day bug-fix support</li>
</ul>
<a href="{{ route('contact') }}" class="btn btn-outline" style="margin-top:auto;">Request Quote</a>
</div>

<div class="card" style="display:flex;flex-direction:column;border:2px solid var(--blue);position:relative;">
<span style="position:absolute;top:-12px;left:50%;transform:translateX(-50%);background:linear-gradient(90deg,var(--blue),var(--cyan));color:white;padding:4px 16px;border-radius:20px;font-size:0.75rem;font-weight:700;">POPULAR</span>
<div class="card-icon navy"><i class="fas fa-briefcase"></i></div>
<h3>Professional</h3>
<p style="font-size:2rem;color:var(--navy);font-weight:800;margin:12px 0;">From $2,500</p>
<p style="color:var(--secondary-text);">Premium corporate websites with admin CMS.</p>
<ul style="list-style:none;padding:0;margin:16px 0;">
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> Up to 15 pages</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> Custom admin dashboard</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> CMS for blog/services/portfolio</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> SEO Pro + structured data</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> 5 rounds of revisions</li>
<li style="padding:6px 0;"><i class="fas fa-check" style="color:var(--green);"></i> 30-day bug-fix support</li>
</ul>
<a href="{{ route('contact') }}" class="btn btn-primary" style="margin-top:auto;">Request Quote</a>
</div>

<div class="card" style="display:flex;flex-direction:column;">
<div class="card-icon cyan"><i class="fas fa-server"></i></div>
<h3>Business Systems</h3>
<p style="font-size:2rem;color:var(--cyan);font-weight:800;margin:12px 0;">From $5,000</p>
<p style="color:var(--secondary-text);">CRM, automation, and dashboards.</p>
<ul style="list-style:none;padding:0;margin:16px 0;">
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> Custom CRM with leads/deals/tasks</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> Workflow automation</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> Admin dashboard with real metrics</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> API endpoints (REST)</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> 3rd-party integrations</li>
<li style="padding:6px 0;"><i class="fas fa-check" style="color:var(--green);"></i> 90-day support</li>
</ul>
<a href="{{ route('contact') }}" class="btn btn-outline" style="margin-top:auto;">Request Quote</a>
</div>

<div class="card" style="display:flex;flex-direction:column;">
<div class="card-icon green"><i class="fas fa-cube"></i></div>
<h3>Custom Software</h3>
<p style="font-size:2rem;color:var(--green);font-weight:800;margin:12px 0;">From $10,000</p>
<p style="color:var(--secondary-text);">Enterprise applications.</p>
<ul style="list-style:none;padding:0;margin:16px 0;">
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> Multi-role access (RBAC)</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> Full source code handover</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> Documentation + deployment guide</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> Production deployment on cPanel</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> HMAC webhooks + audit logs</li>
<li style="padding:6px 0;"><i class="fas fa-check" style="color:var(--green);"></i> 1-year priority support</li>
</ul>
<a href="{{ route('contact') }}" class="btn btn-outline" style="margin-top:auto;">Request Quote</a>
</div>

<div class="card" style="display:flex;flex-direction:column;">
<div class="card-icon blue"><i class="fas fa-building"></i></div>
<h3>Enterprise / Automation</h3>
<p style="font-size:2rem;color:var(--navy);font-weight:800;margin:12px 0;">Custom Estimate</p>
<p style="color:var(--secondary-text);">Large-scale systems.</p>
<ul style="list-style:none;padding:0;margin:16px 0;">
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> Unlimited scope tiers</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> Multi-server deployment</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> Dedicated project manager</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> SLA + escalation path</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> Source code escrow</li>
<li style="padding:6px 0;"><i class="fas fa-check" style="color:var(--green);"></i> Annual support contract</li>
</ul>
<a href="{{ route('contact') }}" class="btn btn-outline" style="margin-top:auto;">Request Quote</a>
</div>

<div class="card" style="display:flex;flex-direction:column;background:linear-gradient(135deg,var(--light-blue),var(--light-green));border:2px dashed var(--cyan);">
<div class="card-icon cyan"><i class="fas fa-question-circle"></i></div>
<h3>Not Sure?</h3>
<p style="font-size:1.5rem;color:var(--cyan);font-weight:800;margin:12px 0;">Talk to Us</p>
<p style="color:var(--secondary-text);">We'll review your requirements and recommend the right tier — or build a custom scope.</p>
<ul style="list-style:none;padding:0;margin:16px 0;">
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> Free 30-min consultation</li>
<li style="padding:6px 0;border-bottom:1px solid var(--border);"><i class="fas fa-check" style="color:var(--green);"></i> Honest tier recommendation</li>
<li style="padding:6px 0;"><i class="fas fa-check" style="color:var(--green);"></i> No-pressure quote</li>
</ul>
<a href="{{ route('contact') }}" class="btn btn-gradient" style="margin-top:auto;">Book a Call</a>
</div>

</div>
</div>
</section>

<section class="section section-light">
<div class="container">
<div class="section-header"><h2>Pricing <span class="text-gradient">FAQ</span></h2><p>Common questions about how TECH360 pricing works.</p></div>
<div style="max-width:800px;margin:0 auto;">
<div style="background:white;border-radius:12px;padding:24px;margin-bottom:16px;box-shadow:var(--shadow);">
<h4>Is the starting price the final price?</h4>
<p style="color:var(--secondary-text);">No — the listed price is a starting estimate. The final price is locked in the approved Scope of Work before any payment is collected. There are no surprise invoices.</p>
</div>
<div style="background:white;border-radius:12px;padding:24px;margin-bottom:16px;box-shadow:var(--shadow);">
<h4>When is payment collected?</h4>
<p style="color:var(--secondary-text);">After you approve the scope. Development does not begin until payment is verified. Source code is gated until QA passes and admin approves the handover.</p>
</div>
<div style="background:white;border-radius:12px;padding:24px;margin-bottom:16px;box-shadow:var(--shadow);">
<h4>What if I need changes after scope approval?</h4>
<p style="color:var(--secondary-text);">Change requests are processed via the Change Request system. Each change is documented, priced, and added to the project timeline — never informally.</p>
</div>
<div style="background:white;border-radius:12px;padding:24px;box-shadow:var(--shadow);">
<h4>What is the refund policy?</h4>
<p style="color:var(--secondary-text);">After Scope of Work approval, payments are non-refundable except where required by law or agreed in writing. Read our full <a href="{{ route('refund-policy') }}">Refund Policy</a>.</p>
</div>
</div>
</div>
</section>
@endsection
