@extends('layouts.app')
@section('title', 'Contact TECH360 LLC — Get a Free Quote')
@section('description', 'Contact TECH360 LLC for website, software, CRM, cloud, and automation projects. Response within 24 business hours. Harrisonville, MO. +1 (800) 360-0199.')
@section('content')
<section class="hero" style="padding:60px 0;">
<div class="container">
<div class="hero-grid">
<div>
<h1>Let's <span class="text-gradient">Build Together</span></h1>
<p>Tell us about your project. We'll respond within 24 business hours with a structured Scope of Work — milestones, deliverables, pricing, and timeline. No call required to start, no obligation until you approve the scope.</p>
<div style="margin-top:32px;display:flex;flex-direction:column;gap:16px;">
<div style="display:flex;align-items:center;gap:16px;">
<div style="width:48px;height:48px;background:rgba(0,159,227,0.1);color:var(--blue);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;"><i class="fas fa-envelope"></i></div>
<div><strong>Email</strong><br><a href="mailto:support@tech360.io">support@tech360.io</a></div>
</div>
<div style="display:flex;align-items:center;gap:16px;">
<div style="width:48px;height:48px;background:rgba(6,59,143,0.1);color:var(--navy);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;"><i class="fas fa-phone"></i></div>
<div><strong>Phone</strong><br><a href="tel:+18003600199">+1 (800) 360-0199</a></div>
</div>
<div style="display:flex;align-items:center;gap:16px;">
<div style="width:48px;height:48px;background:rgba(0,168,168,0.1);color:var(--cyan);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;"><i class="fas fa-map-marker-alt"></i></div>
<div><strong>Address</strong><br>TECH360 LLC<br>117 S Lexington St, Ste 100<br>Harrisonville, MO 64701</div>
</div>
</div>
</div>
<div>
<div style="background:white;border-radius:16px;padding:32px;box-shadow:0 12px 40px rgba(6,59,143,0.12);">
<h3 style="margin-bottom:24px;">Project Inquiry</h3>
<form method="POST" action="{{ route('contact.submit') }}">@csrf
<div class="grid grid-2">
<div class="form-group"><label>Full Name *</label><input type="text" name="name" required value="{{ old('name') }}"></div>
<div class="form-group"><label>Email *</label><input type="email" name="email" required value="{{ old('email') }}"></div>
</div>
<div class="grid grid-2">
<div class="form-group"><label>Phone</label><input type="text" name="phone" value="{{ old('phone') }}"></div>
<div class="form-group"><label>Company</label><input type="text" name="company" value="{{ old('company') }}"></div>
</div>
<div class="form-group"><label>Project Type</label>
<select name="project_type">
<option value="">Select...</option>
<option value="website">Website Development</option>
<option value="software">Custom Software</option>
<option value="crm">CRM System</option>
<option value="ecommerce">eCommerce</option>
<option value="cloud">Cloud / Server</option>
<option value="automation">Business Automation</option>
<option value="api">API Development</option>
<option value="other">Other</option>
</select>
</div>
<div class="form-group"><label>Budget Range</label>
<select name="budget">
<option value="">Select...</option>
<option value="500-2000">$500 - $2,000</option>
<option value="2000-5000">$2,000 - $5,000</option>
<option value="5000-10000">$5,000 - $10,000</option>
<option value="10000+">$10,000+</option>
</select>
</div>
<div class="form-group"><label>Project Details *</label><textarea name="message" rows="5" required placeholder="Describe your project goals, timeline, and any specific requirements...">{{ old('message') }}</textarea></div>
<button type="submit" class="btn btn-gradient" style="width:100%;"><i class="fas fa-paper-plane"></i> Send Inquiry</button>
<p style="font-size:0.85rem;color:var(--secondary-text);margin-top:12px;text-align:center;">By submitting, you agree to our <a href="{{ route('terms') }}">Terms</a> and <a href="{{ route('privacy-policy') }}">Privacy Policy</a>.</p>
</form>
</div>
</div>
</div>
</div>
</section>

<section class="section section-light">
<div class="container">
<div class="section-header"><h2>What <span class="text-gradient">Happens Next</span></h2><p>Our structured response process — no pressure, no surprises.</p></div>
<div class="grid grid-4">
<div class="card"><div class="card-icon blue"><i class="fas fa-inbox"></i></div><h3>1. Submission</h3><p>Your inquiry is logged into our CRM as a tracked lead with a unique ID.</p></div>
<div class="card"><div class="card-icon navy"><i class="fas fa-user-check"></i></div><h3>2. Assignment</h3><p>A Business Development Manager is assigned within 24 business hours.</p></div>
<div class="card"><div class="card-icon cyan"><i class="fas fa-file-alt"></i></div><h3>3. Scope</h3><p>We prepare a formal Scope of Work with milestones, deliverables, and pricing.</p></div>
<div class="card"><div class="card-icon green"><i class="fas fa-handshake"></i></div><h3>4. Approval</h3><p>You approve the scope. Development begins after payment — never before.</p></div>
</div>
</div>
</section>
@endsection
