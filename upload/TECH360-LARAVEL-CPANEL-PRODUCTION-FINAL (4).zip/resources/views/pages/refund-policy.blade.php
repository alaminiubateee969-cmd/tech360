@extends('layouts.app')
@section('title', 'TECH360 LLC Refund Policy | Project Payments & Delivery')
@section('description', 'Refund and cancellation policy for TECH360 LLC software development and digital services.')
@section('content')
<div class="legal-content">
<h1>TECH360 LLC — Refund Policy</h1>
<p><strong>Effective Date: May 19, 2026</strong></p>

<h2>1. General Policy</h2>
<p>TECH360 LLC provides customized software, website, eCommerce, CRM, automation, AI, integration, consulting, and related digital services. Because these services involve project-specific planning, design, development, resources, and customized deliverables, refunds are governed by the applicable Scope of Work, quotation, invoice, project agreement, and this Refund Policy.</p>

<h2>2. Scope of Work and HTML Preview</h2>
<p>Before full project payment, TECH360 may provide a Scope of Work describing the proposed project and an applicable HTML or project preview for client review. The client has the opportunity to review the proposed scope and applicable preview before approving the project.</p>

<h2>3. Scope Approval</h2>
<p>When the client approves the Scope of Work, the client confirms that they have reviewed and accepted the applicable project requirements, deliverables, exclusions, pricing, timeline, HTML preview, payment terms, and delivery process. Approval may be recorded through the client portal, CRM, email, WhatsApp, electronic signature, or another documented method.</p>

<h2>4. No Refund After Scope Approval</h2>
<p>Once the client approves the Scope of Work, project payments are non-refundable, except where:</p>
<ul>
<li>A refund is required by applicable law;</li>
<li>The applicable written project agreement expressly provides otherwise; or</li>
<li>TECH360 LLC voluntarily agrees to a refund in writing.</li>
</ul>
<p>Scope approval authorizes TECH360 to allocate resources, schedule work, prepare project infrastructure, and commit project-specific resources.</p>

<h2>5. Before Scope Approval</h2>
<p>If a payment has been made before Scope approval, refund eligibility will depend on work already performed, project-specific expenses, the applicable quotation or agreement, third-party costs, and applicable law. A refund is not automatically guaranteed simply because Scope approval has not yet occurred.</p>

<h2>6. HTML Preview</h2>
<p>The HTML preview is provided to allow the client to review the proposed project direction before the applicable full payment. The preview may include layout, visual design, page structure, interface elements, sample functionality, and approved project concepts. The HTML preview does not constitute final source-code delivery unless expressly agreed in writing.</p>

<h2>7. Full Payment</h2>
<p>After Scope of Work and applicable HTML preview approval, the client must complete the required full project payment. After payment is confirmed, TECH360 may proceed with final development, production implementation, testing, and final project handover according to the approved Scope of Work.</p>

<h2>8. Source Code</h2>
<p>Unless otherwise agreed in writing, final source code and agreed project files are released after applicable full payment. Third-party software, libraries, APIs, hosting, domains, subscriptions, and external services remain subject to their respective licenses and terms.</p>

<h2>9. Changes After Approval</h2>
<p>Changes outside the approved Scope of Work are not grounds for a refund. Additional requirements may require additional fees, additional development time, change order, revised Scope of Work, or separate quotation.</p>

<h2>10. Client Delays</h2>
<p>A refund is not automatically available because of delays caused by the client, including failure to provide content, credentials, access, approvals, feedback, required information, or third-party access.</p>

<h2>11. Third-Party Costs</h2>
<p>Third-party payments may be non-refundable according to the third-party provider's terms. Examples include domain registration, hosting, cloud services, Meta/WhatsApp services, SMS, email, payment gateways, AI providers, premium software, plugins, APIs, and external subscriptions. TECH360 cannot guarantee refunds from third-party providers.</p>

<h2>12. TECH360 Failure to Deliver</h2>
<p>If TECH360 materially fails to provide an expressly agreed deliverable included in the approved Scope of Work, the parties should first attempt to resolve the issue through correction, revision, replacement, additional delivery time, or another mutually agreed remedy. If the issue cannot reasonably be corrected, any refund or other remedy will be determined according to the applicable agreement, circumstances, and applicable law.</p>

<h2>13. Refund Requests</h2>
<p>Refund requests should be submitted to info@bdtech360.com. The request should include client name, Client ID (if applicable), project name, invoice/payment reference, payment date, reason for the request, and supporting information. TECH360 may review the applicable Scope of Work, approvals, communications, payment records, preview records, and delivery records.</p>

<h2>14. No Automatic Refund Through Silence</h2>
<p>Failure to respond to a message, attend a meeting, or provide feedback does not automatically cancel the project or create a refund entitlement.</p>

<h2>15. Promotional Services</h2>
<p>Promotional offers may have additional terms. Where a promotion contains specific refund or cancellation conditions, those conditions will apply to that promotion.</p>

<h2>16. Legal Rights</h2>
<p>Nothing in this Refund Policy is intended to remove or restrict any consumer or other legal rights that cannot legally be excluded or waived.</p>

<h2>17. Contact</h2>
<p>TECH360 LLC<br>117 S Lexington St, Ste 100<br>Harrisonville, MO 64701<br>United States<br>Email: info@bdtech360.com<br>Website: https://bdtech360.com<br>WhatsApp: +880 1327-100-297</p>
</div>
@endsection
