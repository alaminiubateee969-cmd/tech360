@extends('layouts.app')
@section('title', 'Industries | TECH360 LLC')
@section('content')
<section class="section"><div class="container"><h2>Industries We Serve</h2><div class="grid">
<div class="card"><h3>eCommerce</h3><p>Online stores, marketplaces, and retail platforms.</p></div>
<div class="card"><h3>Education</h3><p>Student management, course platforms, and LMS systems.</p></div>
<div class="card"><h3>Healthcare</h3><p>Clinic management, appointments, and patient records.</p></div>
<div class="card"><h3>Real Estate</h3><p>Property listings, agent management, and inquiries.</p></div>
<div class="card"><h3>Restaurants</h3><p>Order management, menus, and delivery systems.</p></div>
<div class="card"><h3>Agencies</h3><p>Client management, project tracking, and invoicing.</p></div>
<div class="card"><h3>Schools</h3><p>Attendance, grades, parent communication.</p></div>
<div class="card"><h3>Professional Services</h3><p>Appointment, billing, and document management.</p></div>
</div></div></section>
@endsection
