@extends('layouts.app')
@section('title', $item->title . ' | TECH360 Portfolio')
@section('content')
<section class="section"><div class="container" style="max-width:900px;">
<h1>{{ $item->title }}</h1>
@if($item->client_name)<p style="color:var(--secondary-text);">Client: {{ $item->client_name }}</p>@endif
@if($item->industry)<span class="badge badge-blue">{{ $item->industry }}</span>@endif
@if($item->technology)<p style="margin-top:16px;"><strong>Technology:</strong> {{ $item->technology }}</p>@endif
@if($item->description)<div style="margin-top:24px;">{!! nl2br(e($item->description)) !!}</div>@endif
@if($item->results)<div style="margin-top:24px;"><h3>Results</h3>{!! nl2br(e($item->results)) !!}</div>@endif
<a href="{{ route('contact') }}" class="btn btn-primary" style="margin-top:32px;">Start Your Project</a>
</div></section>
@endsection
