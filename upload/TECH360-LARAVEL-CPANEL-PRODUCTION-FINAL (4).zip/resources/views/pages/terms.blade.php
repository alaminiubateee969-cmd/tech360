@extends('layouts.app')
@section('title', 'TECH360 LLC Terms & Conditions | Software & Digital Services')
@section('description', 'Terms and Conditions governing TECH360 LLC software development, website, eCommerce, CRM, automation, and digital services.')
@section('content')
<div class="legal-content">
<h1>TECH360 LLC — Terms &amp; Conditions</h1>
<p><strong>Effective Date: May 19, 2026</strong></p>

<h2>1. Agreement</h2>
<p>These Terms & Conditions govern the use of the TECH360 LLC website and the purchase of software development, website development, eCommerce, CRM, automation, AI, integration, consulting, maintenance, and related digital services.</p>
<p>By requesting a quotation, approving a Scope of Work, making a payment, or using a delivered service, the client agrees to these Terms, subject to applicable law and any project-specific written agreement.</p>

<h2>2. Company Information</h2>
<p>TECH360 LLC<br>117 S Lexington St, Ste 100<br>Harrisonville, MO 64701<br>United States</p>
<p>Website: https://bdtech360.com<br>Email: info@bdtech360.com<br>WhatsApp: +880 1327-100-297</p>

<h2>3. Services</h2>
<p>TECH360 LLC may provide: Custom software development, Website development, eCommerce development, CRM systems, Client portals, Business dashboards, AI solutions, AI-assisted automation, WhatsApp automation, n8n workflow automation, API integrations, Database systems, Cloud deployment, Hosting and infrastructure services, Maintenance and technical support, Consulting and related technology services.</p>

<h2>4. Scope of Work</h2>
<p>Before a project proceeds, TECH360 may provide a Scope of Work describing project objectives, features, deliverables, exclusions, technology requirements, integrations, estimated timeline, client responsibilities, pricing, payment requirements, and delivery requirements. The approved Scope of Work becomes the controlling project specification.</p>

<h2>5. HTML Preview Before Payment</h2>
<p>Where applicable, TECH360 may provide an HTML, design, demonstration, or working preview before the client makes the applicable full project payment. The preview may allow the client to review design, layout, user interface, page structure, agreed functionality, and project presentation. The HTML preview does not constitute final source-code or complete production handover unless expressly agreed in writing.</p>

<h2>6. Client Approval</h2>
<p>The client is responsible for reviewing the Scope of Work and applicable HTML preview before approval. Once approved, the Scope of Work represents the client's acceptance of the agreed project requirements.</p>

<h2>7. Payment After Approval</h2>
<p>After approval of the Scope of Work and applicable HTML preview, the client must complete the applicable full project payment. Unless otherwise agreed in writing, TECH360 proceeds with final development after the required full payment has been received.</p>

<h2>8. Source Code and Project Handover</h2>
<p>Unless otherwise agreed in writing, final source code and agreed project files are released after applicable full payment. Final handover may include source code, website/application files, database export, documentation, deployment files, administrative access, and deployment assistance. Third-party software and services remain subject to their own licenses and terms.</p>

<h2>9. Changes After Scope Approval</h2>
<p>Requests outside the approved Scope of Work may require additional fees, additional development time, a change order, revised Scope of Work, or separate quotation. Additional requests do not automatically create a refund right.</p>

<h2>10. Client Responsibilities</h2>
<p>The client must provide business information, content, logos, images, product information, domain access, hosting access, API credentials, third-party account access, required approvals, and timely feedback. Client delays may affect project timelines.</p>

<h2>11. Project Timeline</h2>
<p>Unless expressly guaranteed in writing, project timelines are estimates. Delays may occur because of client delays, missing information, scope changes, third-party services, API limitations, hosting issues, payment delays, or other circumstances outside TECH360's reasonable control.</p>

<h2>12. Third-Party Services and Costs</h2>
<p>Unless expressly included in the Scope of Work, the client may be responsible for third-party costs including domains, hosting, cloud services, WhatsApp/Meta services, SMS, email services, payment gateways, AI API usage, premium software, plugins, third-party APIs, and SaaS subscriptions. TECH360 does not control third-party pricing, availability, policies, or uptime.</p>

<h2>13. Intellectual Property</h2>
<p>Customer-provided materials remain the customer's property. TECH360 retains rights in its pre-existing and reusable frameworks, libraries, generic components, templates, development tools, internal systems, know-how, and reusable technology. Custom deliverables and source-code ownership are governed by the applicable Scope of Work or project agreement and payment status. Third-party components remain subject to their respective licenses.</p>

<h2>14. Security</h2>
<p>TECH360 takes reasonable measures to protect project information and systems. However, no internet-connected system can be guaranteed completely secure. After handover, the client is responsible for securing credentials and administrative access under its control.</p>

<h2>15. Acceptable Use</h2>
<p>Clients may not use TECH360 services for unlawful or malicious activities, including fraud, malware, phishing, unauthorized access, cyberattacks, illegal surveillance, or intellectual-property infringement. TECH360 may suspend or terminate services where reasonably necessary and permitted by applicable law.</p>

<h2>16. Communication and Records</h2>
<p>TECH360 may communicate through email, WhatsApp, telephone, CRM, client portals, meetings, or other agreed channels. Project records may include requirements, scope versions, approvals, communications, payments, preview deliveries, revision requests, and delivery records. Such records may be maintained for project management, delivery verification, security, accounting, and dispute resolution.</p>

<h2>17. Termination</h2>
<p>Either party may terminate a project where permitted by the applicable agreement or law. Termination does not automatically create a refund right. Amounts owed for completed work, approved project stages, committed third-party costs, or other applicable obligations remain subject to the applicable agreement and Refund Policy.</p>

<h2>18. Disclaimer</h2>
<p>Website information is provided for general informational and commercial purposes. TECH360 does not guarantee specific business results, revenue, rankings, customer acquisition, or other commercial outcomes unless expressly guaranteed in a written agreement.</p>

<h2>19. Limitation of Liability</h2>
<p>To the extent permitted by applicable law, TECH360 LLC will not be liable for indirect, incidental, consequential, special, or unforeseeable losses. Nothing in these Terms excludes liability that cannot legally be excluded.</p>

<h2>20. Force Majeure</h2>
<p>TECH360 will not be responsible for delays caused by circumstances beyond its reasonable control, including major infrastructure failures, natural disasters, government actions, widespread internet outages, third-party failures, war, or other extraordinary events.</p>

<h2>21. Governing Law</h2>
<p>TECH360 LLC is organized in the State of Missouri. These Terms are subject to applicable laws of the State of Missouri and the United States, except where applicable law requires otherwise.</p>

<h2>22. Changes to These Terms</h2>
<p>TECH360 may update these Terms from time to time. Updated versions will display an updated effective date.</p>

<h2>23. Contact</h2>
<p>TECH360 LLC<br>117 S Lexington St, Ste 100<br>Harrisonville, MO 64701<br>United States<br>Email: info@bdtech360.com<br>WhatsApp: +880 1327-100-297</p>
</div>
@endsection
