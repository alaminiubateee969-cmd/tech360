@extends('layouts.app')
@section('title', $post->title . ' | TECH360 Blog')
@section('content')
<section class="section"><div class="container" style="max-width:800px;">
<span class="badge badge-blue">{{ $post->category ?? 'Technology' }}</span>
<h1 style="margin:16px 0;">{{ $post->title }}</h1>
<p style="color:var(--secondary-text);">By {{ $post->author }} · {{ $post->created_at->format('M d, Y') }}</p>
@if($post->featured_image)<img src="{{ $post->featured_image }}" alt="{{ $post->title }}" style="width:100%;border-radius:12px;margin:24px 0;">@endif
<div style="line-height:1.8;">{!! nl2br(e($post->content)) !!}</div>
<a href="{{ route('blog') }}" class="btn btn-outline" style="margin-top:32px;">← Back to Blog</a>
</div></section>
@endsection
