@extends('layouts.app')
@section('title', 'Services | TECH360 LLC')
@section('description', 'TECH360 LLC service catalog: Website, Software, Cloud, CRM, Automation, Data Analytics, AI Solutions, Digital Transformation.')
@section('content')
<section class="hero" style="padding:60px 0;">
<div class="container">
<div class="hero-grid">
<div>
<h1>Our <span class="text-gradient">Services</span></h1>
<p>TECH360 delivers end-to-end technology solutions for businesses of every size. From custom websites and CRMs to enterprise cloud infrastructure and AI-powered automation, we build the systems that move your business forward — with a strict scope-to-delivery workflow that protects every dollar you invest.</p>
<div class="hero-cta">
<a href="{{ route('contact') }}" class="btn btn-gradient"><i class="fas fa-rocket"></i> Request a Quote</a>
<a href="{{ route('pricing') }}" class="btn btn-outline"><i class="fas fa-tag"></i> View Pricing</a>
</div>
</div>
<div class="hero-visual"><img src="{{ asset('images/tech-stack.png') }}" alt="TECH360 tech stack" style="max-width:100%;border-radius:16px;box-shadow:0 12px 40px rgba(6,59,143,0.12);"></div>
</div>
</div>
</section>

<section class="section">
<div class="container">
<div class="section-header"><h2>What We <span class="text-gradient">Build</span></h2><p>Nine core service lines, each with a defined delivery workflow, QA stage, and source-code protection.</p></div>

<div class="grid grid-3">
<div class="card">
<div class="card-icon blue"><i class="fas fa-code"></i></div>
<h3>Custom Software Development</h3>
<p>Enterprise applications, internal tools, customer portals, REST APIs, and integrations with third-party systems. Built on Laravel 11 / PHP 8.2+ with MySQL 8 — production-grade, not prototypeware.</p>
<a href="{{ route('contact') }}" class="btn btn-sm btn-outline" style="margin-top:16px;">Get Quote</a>
</div>
<div class="card">
<div class="card-icon navy"><i class="fas fa-globe"></i></div>
<h3>Website Development</h3>
<p>Responsive, SEO-ready websites with proper meta tags, canonical URLs, sitemap, robots.txt, Open Graph, and Twitter Card metadata. Hosted on standard cPanel — no Node.js, no Docker required.</p>
<a href="{{ route('contact') }}" class="btn btn-sm btn-outline" style="margin-top:16px;">Get Quote</a>
</div>
<div class="card">
<div class="card-icon cyan"><i class="fas fa-shopping-cart"></i></div>
<h3>eCommerce Development</h3>
<p>Online stores with product catalogs, secure checkout (Stripe / PayPal), inventory, order tracking, and shipment integrations. HMAC-signed webhooks with idempotent processing and audit logging.</p>
<a href="{{ route('contact') }}" class="btn btn-sm btn-outline" style="margin-top:16px;">Get Quote</a>
</div>
<div class="card">
<div class="card-icon green"><i class="fas fa-users-cog"></i></div>
<h3>CRM Development</h3>
<p>Custom CRM systems with contacts, leads, deals, tasks, communications, and activities — every metric pulled from the real database, no fake counters. Includes pipeline, scoring, and assignment.</p>
<a href="{{ route('contact') }}" class="btn btn-sm btn-outline" style="margin-top:16px;">Get Quote</a>
</div>
<div class="card">
<div class="card-icon blue"><i class="fas fa-cogs"></i></div>
<h3>Business Automation</h3>
<p>Workflow automation, scheduled jobs, notifications, and integrations. Includes Laravel scheduler with documented cPanel cron commands — no Supervisor or Redis required.</p>
<a href="{{ route('contact') }}" class="btn btn-sm btn-outline" style="margin-top:16px;">Get Quote</a>
</div>
<div class="card">
<div class="card-icon navy"><i class="fas fa-cloud"></i></div>
<h3>Cloud & Server Solutions</h3>
<p>Cloud deployment, infrastructure, monitoring, and security hardening. Compatible with standard cPanel hosting, AWS, DigitalOcean, and Linode. Includes health checks and error monitoring.</p>
<a href="{{ route('contact') }}" class="btn btn-sm btn-outline" style="margin-top:16px;">Get Quote</a>
</div>
<div class="card">
<div class="card-icon cyan"><i class="fas fa-chart-line"></i></div>
<h3>Business Intelligence</h3>
<p>Dashboards, analytics, and reporting systems with real-time metrics. Built with paginated queries, eager loading, and indexed tables — no N+1, no memory blowouts.</p>
<a href="{{ route('contact') }}" class="btn btn-sm btn-outline" style="margin-top:16px;">Get Quote</a>
</div>
<div class="card">
<div class="card-icon green"><i class="fas fa-plug"></i></div>
<h3>API Development</h3>
<p>Custom APIs, REST endpoints, third-party integrations, HMAC-signed webhooks, and rate-limited routes. Includes API key management and audit trails.</p>
<a href="{{ route('contact') }}" class="btn btn-sm btn-outline" style="margin-top:16px;">Get Quote</a>
</div>
<div class="card">
<div class="card-icon blue"><i class="fas fa-lightbulb"></i></div>
<h3>Digital Transformation</h3>
<p>Complete technology modernization and consulting. Includes current-state audit, gap analysis, roadmap, migration plan, and post-launch support with 30-day bug-fix coverage.</p>
<a href="{{ route('contact') }}" class="btn btn-sm btn-outline" style="margin-top:16px;">Get Quote</a>
</div>
</div>
</div>
</section>

<section class="section section-light">
<div class="container">
<div class="section-header"><h2>How <span class="text-gradient">Delivery Works</span></h2><p>Every engagement follows the same controlled workflow. No shortcuts, no surprises.</p></div>
<div class="grid grid-4">
<div class="card"><div class="card-icon blue"><i class="fas fa-file-signature"></i></div><h3>1. Scope</h3><p>Documented Scope of Work with milestones, deliverables, and acceptance criteria.</p></div>
<div class="card"><div class="card-icon navy"><i class="fas fa-check-circle"></i></div><h3>2. Approval</h3><p>Client signs off scope. Refund policy changes after this step — by design.</p></div>
<div class="card"><div class="card-icon cyan"><i class="fas fa-credit-card"></i></div><h3>3. Payment</h3><p>Invoice issued, payment processed via Stripe/PayPal, verified server-side.</p></div>
<div class="card"><div class="card-icon green"><i class="fas fa-code-branch"></i></div><h3>4. Build</h3><p>Development begins after verified payment. Source code gated until QA passes.</p></div>
<div class="card"><div class="card-icon blue"><i class="fas fa-shield-alt"></i></div><h3>5. QA</h3><p>Quality assurance pass — automated tests, security review, performance check.</p></div>
<div class="card"><div class="card-icon navy"><i class="fas fa-eye"></i></div><h3>6. Preview</h3><p>Client previews staging build, signs off acceptance criteria.</p></div>
<div class="card"><div class="card-icon cyan"><i class="fas fa-key"></i></div><h3>7. Handover</h3><p>Source code released only after admin approval + credential rotation.</p></div>
<div class="card"><div class="card-icon green"><i class="fas fa-headset"></i></div><h3>8. Support</h3><p>30-day bug-fix support included. New features are separate engagements.</p></div>
</div>
</div>
</section>

<section class="section">
<div class="container" style="text-align:center;">
<h2>Ready to <span class="text-gradient">Start?</span></h2>
<p style="color:var(--secondary-text);max-width:600px;margin:16px auto 32px;">Tell us what you need. We'll prepare a formal Scope of Work with milestones, deliverables, and pricing — no obligation until you approve.</p>
<a href="{{ route('contact') }}" class="btn btn-gradient" style="font-size:1.1rem;padding:16px 32px;"><i class="fas fa-paper-plane"></i> Request a Quote</a>
</div>
</section>
@endsection
