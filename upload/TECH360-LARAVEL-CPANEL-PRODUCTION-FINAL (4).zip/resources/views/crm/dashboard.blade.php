@extends('layouts.admin')
@section('title', 'CRM Dashboard | TECH360 LLC')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;">
<h2 style="margin:0;">CRM Dashboard</h2>
<div>
<a href="{{ route('crm.contacts') }}" class="btn btn-primary btn-sm">Contacts</a>
<a href="{{ route('crm.leads') }}" class="btn btn-primary btn-sm">Leads</a>
<a href="{{ route('crm.deals') }}" class="btn btn-primary btn-sm">Deals</a>
<a href="{{ route('crm.tasks') }}" class="btn btn-primary btn-sm">Tasks</a>
<a href="{{ route('admin.ai.dashboard') }}" class="btn btn-outline btn-sm">AI Agents</a>
</div>
</div>

<div class="grid grid-4">
<div class="stat-card"><div class="label">Total Contacts</div><div class="number">{{ $stats['total_contacts'] }}</div></div>
<div class="stat-card"><div class="label">New Leads</div><div class="number" style="color:var(--blue);">{{ $stats['new_leads'] }}</div></div>
<div class="stat-card"><div class="label">Qualified Leads</div><div class="number" style="color:var(--cyan);">{{ $stats['qualified_leads'] }}</div></div>
<div class="stat-card"><div class="label">Customers</div><div class="number" style="color:var(--green);">{{ $stats['customers'] }}</div></div>
<div class="stat-card"><div class="label">Open Deals</div><div class="number">{{ $stats['open_deals'] }}</div></div>
<div class="stat-card"><div class="label">Won Deals</div><div class="number" style="color:var(--green);">{{ $stats['won_deals'] }}</div></div>
<div class="stat-card"><div class="label">Pipeline Value</div><div class="number" style="color:var(--navy);">${{ number_format($stats['pipeline_value'] ?? 0) }}</div></div>
<div class="stat-card"><div class="label">Won Value</div><div class="number" style="color:var(--green);">${{ number_format($stats['won_value'] ?? 0) }}</div></div>
</div>

<div class="grid grid-2" style="margin-top:32px;">
<div>
<h3 style="margin-bottom:16px;">Recent Leads</h3>
<div style="background:white;border-radius:12px;box-shadow:var(--shadow);overflow:hidden;">
@if($stats['recent_leads']->count())
<table class="table">
<thead><tr><th>Lead ID</th><th>Contact</th><th>Source</th><th>Status</th></tr></thead>
<tbody>
@foreach($stats['recent_leads'] as $lead)
<tr>
<td>{{ $lead->lead_id }}</td>
<td>{{ $lead->contact ? $lead->contact->first_name . ' ' . ($lead->contact->last_name ?? '') : '—' }}</td>
<td>{{ ucfirst($lead->source ?? 'website') }}</td>
<td><span class="badge badge-blue">{{ ucfirst($lead->status) }}</span></td>
</tr>
@endforeach
</tbody>
</table>
@else
<p style="padding:24px;color:var(--secondary-text);text-align:center;">No leads yet.</p>
@endif
</div>
</div>
<div>
<h3 style="margin-bottom:16px;">Recent Activities</h3>
<div style="background:white;border-radius:12px;box-shadow:var(--shadow);overflow:hidden;">
@if($stats['recent_activities']->count())
<table class="table">
<thead><tr><th>Type</th><th>Description</th><th>When</th></tr></thead>
<tbody>
@foreach($stats['recent_activities'] as $activity)
<tr>
<td><span class="badge badge-navy">{{ ucfirst($activity->type) }}</span></td>
<td>{{ \Illuminate\Support\Str::limit($activity->description, 50) }}</td>
<td>{{ $activity->created_at ? $activity->created_at->diffForHumans() : '—' }}</td>
</tr>
@endforeach
</tbody>
</table>
@else
<p style="padding:24px;color:var(--secondary-text);text-align:center;">No activities yet.</p>
@endif
</div>
</div>
</div>

@if($leads_by_source && $leads_by_source->count())
<div style="margin-top:32px;">
<h3 style="margin-bottom:16px;">Leads by Source</h3>
<div style="background:white;border-radius:12px;padding:24px;box-shadow:var(--shadow);">
<div style="display:flex;gap:16px;flex-wrap:wrap;">
@foreach($leads_by_source as $source => $count)
<div style="text-align:center;padding:16px;border:1px solid var(--border);border-radius:8px;min-width:120px;">
<div style="font-size:1.6rem;font-weight:700;color:var(--navy);">{{ $count }}</div>
<div style="font-size:0.85rem;color:var(--secondary-text);">{{ ucfirst($source) }}</div>
</div>
@endforeach
</div>
</div>
</div>
@endif
</div>
</section>
@endsection
