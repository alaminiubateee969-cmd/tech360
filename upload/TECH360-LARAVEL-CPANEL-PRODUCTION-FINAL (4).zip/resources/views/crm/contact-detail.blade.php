@extends('layouts.admin')
@section('title', $contact->first_name . ' ' . ($contact->last_name ?? '') . ' | TECH360 CRM')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container">
<a href="{{ route('crm.contacts') }}" class="btn btn-outline btn-sm" style="margin-bottom:16px;"><i class="fas fa-arrow-left"></i> Back to Contacts</a>

<div class="grid grid-3" style="grid-template-columns:2fr 1fr;gap:24px;align-items:start;">
<div>
<div style="background:white;border-radius:16px;padding:32px;box-shadow:var(--shadow);margin-bottom:24px;">
<div style="display:flex;justify-content:space-between;align-items:start;">
<div>
<h2 style="margin:0;">{{ $contact->first_name }} {{ $contact->last_name ?? '' }}</h2>
<p style="color:var(--secondary-text);">{{ $contact->contact_id }} • <span class="badge badge-{{ $contact->status==='customer'?'green':'blue' }}">{{ ucfirst($contact->status) }}</span></p>
</div>
</div>
<hr style="border:none;border-top:1px solid var(--border);margin:20px 0;">
<div class="grid grid-2">
<div><strong>Email:</strong><br>{{ $contact->email ?? '—' }}</div>
<div><strong>Phone:</strong><br>{{ $contact->phone ?? '—' }}</div>
<div><strong>Source:</strong><br>{{ ucfirst($contact->source ?? 'manual') }}</div>
<div><strong>Company:</strong><br>{{ $contact->company ? $contact->company->name : '—' }}</div>
<div><strong>Created:</strong><br>{{ $contact->created_at ? $contact->created_at->format('M d, Y') : '—' }}</div>
<div><strong>Owner:</strong><br>{{ $contact->assignedTo ? $contact->assignedTo->name : 'Unassigned' }}</div>
</div>
</div>

<div style="background:white;border-radius:16px;padding:32px;box-shadow:var(--shadow);margin-bottom:24px;">
<h3 style="margin-bottom:16px;">Add Communication</h3>
<form method="POST" action="{{ route('crm.communication.add', $contact->id) }}">
@csrf
<div class="grid grid-3">
<div class="form-group"><label>Channel</label>
<select name="channel"><option value="email">Email</option><option value="phone">Phone</option><option value="whatsapp">WhatsApp</option><option value="sms">SMS</option><option value="meeting">Meeting</option></select>
</div>
<div class="form-group"><label>Direction</label>
<select name="direction"><option value="inbound">Inbound</option><option value="outbound">Outbound</option></select>
</div>
<div class="form-group"><label>Status</label>
<select name="status"><option value="completed">Completed</option><option value="missed">Missed</option><option value="scheduled">Scheduled</option></select>
</div>
</div>
<div class="form-group"><label>Subject/Summary</label><input type="text" name="subject" placeholder="Subject or summary"></div>
<div class="form-group"><label>Content</label><textarea name="content" rows="3" placeholder="Communication details..."></textarea></div>
<button type="submit" class="btn btn-primary btn-sm">Add Communication</button>
</form>
</div>

<div style="background:white;border-radius:16px;padding:32px;box-shadow:var(--shadow);">
<h3 style="margin-bottom:16px;">Communications Timeline</h3>
@if($contact->communications->count())
<div style="border-left:3px solid var(--blue);padding-left:16px;">
@foreach($contact->communications as $comm)
<div style="margin-bottom:20px;">
<div style="display:flex;justify-content:space-between;">
<strong>{{ $comm->subject ?? ucfirst($comm->channel) }}</strong>
<span class="badge badge-blue">{{ ucfirst($comm->direction) }}</span>
</div>
<p style="color:var(--secondary-text);font-size:0.9rem;">{{ $comm->content }}</p>
<small style="color:var(--secondary-text);">{{ $comm->created_at ? $comm->created_at->format('M d, Y H:i') : '' }} • {{ ucfirst($comm->status) }}</small>
</div>
@endforeach
</div>
@else
<p style="color:var(--secondary-text);">No communications yet.</p>
@endif
</div>
</div>

<div>
<div style="background:white;border-radius:16px;padding:24px;box-shadow:var(--shadow);margin-bottom:24px;">
<h3 style="margin-bottom:16px;">Leads</h3>
@if($contact->leads->count())
@foreach($contact->leads as $lead)
<div style="padding:12px;border:1px solid var(--border);border-radius:8px;margin-bottom:8px;">
<div style="font-weight:600;">{{ $lead->lead_id }}</div>
<small style="color:var(--secondary-text);">{{ ucfirst($lead->status) }} • {{ ucfirst($lead->source) }}</small>
</div>
@endforeach
@else
<p style="color:var(--secondary-text);font-size:0.9rem;">No leads.</p>
@endif
</div>

<div style="background:white;border-radius:16px;padding:24px;box-shadow:var(--shadow);margin-bottom:24px;">
<h3 style="margin-bottom:16px;">Deals</h3>
@if($contact->deals->count())
@foreach($contact->deals as $deal)
<div style="padding:12px;border:1px solid var(--border);border-radius:8px;margin-bottom:8px;">
<div style="font-weight:600;">{{ $deal->title }}</div>
<small style="color:var(--secondary-text);">${{ number_format($deal->value) }} • {{ ucfirst($deal->stage) }}</small>
</div>
@endforeach
@else
<p style="color:var(--secondary-text);font-size:0.9rem;">No deals.</p>
@endif
</div>

<div style="background:white;border-radius:16px;padding:24px;box-shadow:var(--shadow);margin-bottom:24px;">
<h3 style="margin-bottom:16px;">Tasks</h3>
@if($contact->tasks->count())
@foreach($contact->tasks as $task)
<div style="padding:12px;border:1px solid var(--border);border-radius:8px;margin-bottom:8px;">
<div style="font-weight:600;">{{ $task->title }}</div>
<small style="color:var(--secondary-text);">{{ ucfirst($task->priority) }} • {{ ucfirst($task->status) }} • Due: {{ $task->due_date ?? '—' }}</small>
</div>
@endforeach
@else
<p style="color:var(--secondary-text);font-size:0.9rem;">No tasks.</p>
@endif
</div>

<div style="background:white;border-radius:16px;padding:24px;box-shadow:var(--shadow);">
<h3 style="margin-bottom:16px;">Activities</h3>
@if($contact->activities->count())
@foreach($contact->activities as $activity)
<div style="padding:8px 0;border-bottom:1px solid var(--border);">
<small style="color:var(--secondary-text);">{{ ucfirst($activity->type) }}</small>
<div>{{ $activity->description }}</div>
</div>
@endforeach
@else
<p style="color:var(--secondary-text);font-size:0.9rem;">No activities.</p>
@endif
</div>
</div>
</div>
</div>
</section>
@endsection
