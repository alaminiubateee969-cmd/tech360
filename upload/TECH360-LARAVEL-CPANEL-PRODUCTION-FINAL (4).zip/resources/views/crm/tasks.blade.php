@extends('layouts.admin')
@section('title', 'Tasks | TECH360 CRM')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;">
<h2 style="margin:0;">Tasks <span style="color:var(--secondary-text);font-size:1rem;">({{ $tasks->total() }} total)</span></h2>
<button class="btn btn-primary btn-sm" onclick="document.getElementById('newTaskModal').style.display='block'"><i class="fas fa-plus"></i> New Task</button>
</div>

<div style="background:white;border-radius:12px;box-shadow:var(--shadow);overflow:hidden;">
<table class="table">
<thead><tr><th>Title</th><th>Contact</th><th>Priority</th><th>Status</th><th>Due</th><th>Assigned To</th></tr></thead>
<tbody>
@if($tasks->count())
@foreach($tasks as $task)
<tr>
<td>{{ $task->title }}</td>
<td>{{ $task->contact ? $task->contact->first_name . ' ' . ($task->contact->last_name ?? '') : '—' }}</td>
<td><span class="badge badge-{{ $task->priority==='high'?'red':($task->priority==='medium'?'blue':'navy') }}">{{ ucfirst($task->priority) }}</span></td>
<td><span class="badge badge-{{ $task->status==='completed'?'green':'blue' }}">{{ ucfirst($task->status) }}</span></td>
<td>{{ $task->due_date ?? '—' }}</td>
<td>{{ $task->assignedTo ? $task->assignedTo->name : '—' }}</td>
</tr>
@endforeach
@else
<tr><td colspan="6" style="text-align:center;padding:48px;color:var(--secondary-text);">No tasks found.</td></tr>
@endif
</tbody>
</table>
</div>
{{ $tasks->links() }}
</div>
</section>

<div id="newTaskModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:2000;align-items:center;justify-content:center;" onclick="if(event.target===this)this.style.display='none'">
<div style="background:white;border-radius:16px;padding:32px;max-width:500px;width:90%;">
<h3 style="margin-bottom:16px;">New Task</h3>
<form method="POST" action="{{ route('crm.tasks.store') }}">
@csrf
<div class="form-group"><label>Title *</label><input type="text" name="title" required></div>
<div class="form-group"><label>Description</label><textarea name="description" rows="3"></textarea></div>
<div class="form-group"><label>Contact</label>
<select name="contact_id">
<option value="">—</option>
@foreach(\App\Models\Contact::orderBy('first_name')->get() as $c)
<option value="{{ $c->id }}">{{ $c->first_name }} {{ $c->last_name ?? '' }}</option>
@endforeach
</select>
</div>
<div class="grid grid-2">
<div class="form-group"><label>Priority</label>
<select name="priority"><option value="low">Low</option><option value="medium" selected>Medium</option><option value="high">High</option></select>
</div>
<div class="form-group"><label>Due Date</label><input type="date" name="due_date"></div>
</div>
<button type="submit" class="btn btn-primary">Create Task</button>
<button type="button" onclick="document.getElementById('newTaskModal').style.display='none'" class="btn btn-outline">Cancel</button>
</form>
</div>
</div>
@endsection
