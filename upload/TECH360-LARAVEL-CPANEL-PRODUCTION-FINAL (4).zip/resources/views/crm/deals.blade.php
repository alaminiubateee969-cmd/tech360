@extends('layouts.admin')
@section('title', 'Deals | TECH360 CRM')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;">
<h2 style="margin:0;">Deals <span style="color:var(--secondary-text);font-size:1rem;">({{ $deals->total() }} total)</span></h2>
<button class="btn btn-primary btn-sm" onclick="document.getElementById('newDealModal').style.display='block'"><i class="fas fa-plus"></i> New Deal</button>
</div>

<form method="GET" action="{{ route('crm.deals') }}" style="display:flex;gap:12px;margin-bottom:24px;">
<select name="stage" style="padding:10px 14px;border:1px solid var(--border);border-radius:8px;">
<option value="">All Stages</option>
@foreach(['lead','qualified','proposal','negotiation','won','lost'] as $stage)
<option value="{{ $stage }}" @if(request('stage')===$stage) selected @endif>{{ ucfirst($stage) }}</option>
@endforeach
</select>
<button type="submit" class="btn btn-outline btn-sm"><i class="fas fa-filter"></i> Filter</button>
</form>

<div style="background:white;border-radius:12px;box-shadow:var(--shadow);overflow:hidden;">
<table class="table">
<thead><tr><th>Deal</th><th>Contact</th><th>Value</th><th>Probability</th><th>Stage</th><th>Expected Close</th></tr></thead>
<tbody>
@if($deals->count())
@foreach($deals as $deal)
<tr>
<td>{{ $deal->title }}</td>
<td>{{ $deal->contact ? $deal->contact->first_name . ' ' . ($deal->contact->last_name ?? '') : '—' }}</td>
<td>${{ number_format($deal->value ?? 0) }}</td>
<td>{{ $deal->probability ?? 0 }}%</td>
<td><span class="badge badge-{{ $deal->stage==='won'?'green':($deal->stage==='lost'?'red':'blue') }}">{{ ucfirst($deal->stage) }}</span></td>
<td>{{ $deal->expected_close_date ?? '—' }}</td>
</tr>
@endforeach
@else
<tr><td colspan="6" style="text-align:center;padding:48px;color:var(--secondary-text);">No deals found.</td></tr>
@endif
</tbody>
</table>
</div>
{{ $deals->links() }}
</div>
</section>

<div id="newDealModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:2000;align-items:center;justify-content:center;" onclick="if(event.target===this)this.style.display='none'">
<div style="background:white;border-radius:16px;padding:32px;max-width:500px;width:90%;">
<h3 style="margin-bottom:16px;">New Deal</h3>
<form method="POST" action="{{ route('crm.deals.store') }}">
@csrf
<div class="form-group"><label>Deal Title *</label><input type="text" name="title" required></div>
<div class="form-group"><label>Contact</label>
<select name="contact_id">
<option value="">—</option>
@foreach(\App\Models\Contact::orderBy('first_name')->get() as $c)
<option value="{{ $c->id }}">{{ $c->first_name }} {{ $c->last_name ?? '' }}</option>
@endforeach
</select>
</div>
<div class="form-group"><label>Value ($) *</label><input type="number" name="value" step="0.01" required></div>
<div class="form-group"><label>Probability (%)</label><input type="number" name="probability" min="0" max="100" value="50"></div>
<div class="form-group"><label>Stage</label>
<select name="stage"><option value="lead">Lead</option><option value="qualified">Qualified</option><option value="proposal">Proposal</option><option value="negotiation">Negotiation</option></select>
</div>
<div class="form-group"><label>Expected Close Date</label><input type="date" name="expected_close_date"></div>
<button type="submit" class="btn btn-primary">Create Deal</button>
<button type="button" onclick="document.getElementById('newDealModal').style.display='none'" class="btn btn-outline">Cancel</button>
</form>
</div>
</div>
@endsection
