@extends('layouts.admin')
@section('title', 'Leads | TECH360 CRM')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;">
<h2 style="margin:0;">Leads <span style="color:var(--secondary-text);font-size:1rem;">({{ $leads->total() }} total)</span></h2>
<button class="btn btn-primary btn-sm" onclick="document.getElementById('newLeadModal').style.display='block'"><i class="fas fa-plus"></i> New Lead</button>
</div>

<form method="GET" action="{{ route('crm.leads') }}" style="display:flex;gap:12px;margin-bottom:24px;">
<select name="status" style="padding:10px 14px;border:1px solid var(--border);border-radius:8px;">
<option value="">All Statuses</option>
@foreach(['new','contacted','qualified','proposal','negotiation','won','lost'] as $status)
<option value="{{ $status }}" @if(request('status')===$status) selected @endif>{{ ucfirst($status) }}</option>
@endforeach
</select>
<button type="submit" class="btn btn-outline btn-sm"><i class="fas fa-filter"></i> Filter</button>
</form>

<div style="background:white;border-radius:12px;box-shadow:var(--shadow);overflow:hidden;">
<table class="table">
<thead><tr><th>Lead ID</th><th>Contact</th><th>Source</th><th>Service Interest</th><th>Status</th><th>Created</th></tr></thead>
<tbody>
@if($leads->count())
@foreach($leads as $lead)
<tr>
<td>{{ $lead->lead_id }}</td>
<td>{{ $lead->contact ? $lead->contact->first_name . ' ' . ($lead->contact->last_name ?? '') : '—' }}</td>
<td>{{ ucfirst($lead->source ?? 'website') }}</td>
<td>{{ $lead->service_interest ?? '—' }}</td>
<td><span class="badge badge-{{ $lead->status==='won'?'green':($lead->status==='lost'?'red':'blue') }}">{{ ucfirst($lead->status) }}</span></td>
<td>{{ $lead->created_at ? $lead->created_at->format('M d, Y') : '—' }}</td>
</tr>
@endforeach
@else
<tr><td colspan="6" style="text-align:center;padding:48px;color:var(--secondary-text);">No leads found.</td></tr>
@endif
</tbody>
</table>
</div>
{{ $leads->links() }}
</div>
</section>

<div id="newLeadModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:2000;align-items:center;justify-content:center;" onclick="if(event.target===this)this.style.display='none'">
<div style="background:white;border-radius:16px;padding:32px;max-width:500px;width:90%;">
<h3 style="margin-bottom:16px;">New Lead</h3>
<form method="POST" action="{{ route('crm.leads.store') }}">
@csrf
<div class="form-group"><label>Contact *</label>
<select name="contact_id" required>
@foreach(\App\Models\Contact::orderBy('first_name')->get() as $c)
<option value="{{ $c->id }}">{{ $c->contact_id }} — {{ $c->first_name }} {{ $c->last_name ?? '' }}</option>
@endforeach
</select>
</div>
<div class="form-group"><label>Service Interest</label><input type="text" name="service_interest" placeholder="e.g. Website Development"></div>
<div class="form-group"><label>Source</label><input type="text" name="source" value="manual"></div>
<div class="form-group"><label>Status</label>
<select name="status"><option value="new">New</option><option value="contacted">Contacted</option><option value="qualified">Qualified</option></select>
</div>
<button type="submit" class="btn btn-primary">Create Lead</button>
<button type="button" onclick="document.getElementById('newLeadModal').style.display='none'" class="btn btn-outline">Cancel</button>
</form>
</div>
</div>
@endsection
