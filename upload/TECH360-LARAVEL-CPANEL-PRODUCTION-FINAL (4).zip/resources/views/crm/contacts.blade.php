@extends('layouts.admin')
@section('title', 'Contacts | TECH360 CRM')
@section('content')
<section class="section" style="padding-top:32px;">
<div class="container">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;">
<h2 style="margin:0;">Contacts <span style="color:var(--secondary-text);font-size:1rem;">({{ $contacts->total() }} total)</span></h2>
<button class="btn btn-primary btn-sm" onclick="document.getElementById('newContactModal').style.display='block'"><i class="fas fa-plus"></i> New Contact</button>
</div>

<form method="GET" action="{{ route('crm.contacts') }}" style="display:flex;gap:12px;margin-bottom:24px;flex-wrap:wrap;">
<input type="text" name="search" placeholder="Search name, email, phone..." value="{{ request('search') }}" style="flex:1;min-width:200px;padding:10px 14px;border:1px solid var(--border);border-radius:8px;">
<select name="status" style="padding:10px 14px;border:1px solid var(--border);border-radius:8px;">
<option value="">All Statuses</option>
@foreach(['lead','qualified','customer','inactive'] as $status)
<option value="{{ $status }}" @if(request('status')===$status) selected @endif>{{ ucfirst($status) }}</option>
@endforeach
</select>
<button type="submit" class="btn btn-outline btn-sm"><i class="fas fa-search"></i> Filter</button>
<a href="{{ route('crm.contacts') }}" class="btn btn-outline btn-sm">Clear</a>
</form>

<div style="background:white;border-radius:12px;box-shadow:var(--shadow);overflow:hidden;">
<table class="table">
<thead><tr><th>Contact ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Status</th><th>Source</th><th>Actions</th></tr></thead>
<tbody>
@if($contacts->count())
@foreach($contacts as $contact)
<tr>
<td>{{ $contact->contact_id }}</td>
<td>{{ $contact->first_name }} {{ $contact->last_name ?? '' }}</td>
<td>{{ $contact->email ?? '—' }}</td>
<td>{{ $contact->phone ?? '—' }}</td>
<td><span class="badge badge-{{ $contact->status==='customer'?'green':'blue' }}">{{ ucfirst($contact->status) }}</span></td>
<td>{{ ucfirst($contact->source ?? 'manual') }}</td>
<td><a href="{{ route('crm.contacts.show', $contact->id) }}" class="btn btn-sm btn-outline">View</a></td>
</tr>
@endforeach
@else
<tr><td colspan="7" style="text-align:center;padding:48px;color:var(--secondary-text);">No contacts found.</td></tr>
@endif
</tbody>
</table>
</div>

<div style="margin-top:16px;">
{{ $contacts->links() }}
</div>
</div>
</section>

<div id="newContactModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:2000;align-items:center;justify-content:center;" onclick="if(event.target===this)this.style.display='none'">
<div style="background:white;border-radius:16px;padding:32px;max-width:500px;width:90%;max-height:90vh;overflow-y:auto;">
<h3 style="margin-bottom:16px;">New Contact</h3>
<form method="POST" action="{{ route('crm.contacts.store') }}">
@csrf
<div class="form-group"><label>First Name *</label><input type="text" name="first_name" required></div>
<div class="form-group"><label>Last Name</label><input type="text" name="last_name"></div>
<div class="form-group"><label>Email</label><input type="email" name="email"></div>
<div class="form-group"><label>Phone</label><input type="text" name="phone"></div>
<div class="form-group"><label>Source</label><input type="text" name="source" value="manual"></div>
<div class="form-group"><label>Status</label>
<select name="status"><option value="lead">Lead</option><option value="qualified">Qualified</option><option value="customer">Customer</option><option value="inactive">Inactive</option></select>
</div>
<button type="submit" class="btn btn-primary">Create Contact</button>
<button type="button" onclick="document.getElementById('newContactModal').style.display='none'" class="btn btn-outline">Cancel</button>
</form>
</div>
</div>
@endsection
